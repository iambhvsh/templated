// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyCe0smNDarFfr691ilYocSc5ou5ihWBrjM",
  authDomain: "chat-app-1b1c5.firebaseapp.com",
  databaseURL: "https://chat-app-1b1c5-default-rtdb.firebaseio.com",
  projectId: "chat-app-1b1c5",
  storageBucket: "chat-app-1b1c5.appspot.com",
  messagingSenderId: "33329285041",
  appId: "1:33329285041:web:fa84a7ac78e4918eee1f90",
  measurementId: "G-M41QE3E4ZH"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Handle form submission
document.getElementById('registerForm').addEventListener('submit', function(event) {
  event.preventDefault();

  var username = document.getElementById('username').value;
  var profilePicInput = document.getElementById('profilePic');

  if (!username || !profilePicInput.files[0]) {
    alert("Please fill out all fields.");
    return;
  }

  // Convert file to Base64 string
  var file = profilePicInput.files[0];
  var reader = new FileReader();
  reader.onload = function(event) {
    var base64String = event.target.result.split(',')[1]; // Get rid of 'data:image/jpeg;base64,'

    // Save username to Firebase Realtime Database
    firebase.database().ref('users/' + username).set({
      username: username,
      profilePic: base64String
    }).then(function() {
      // Save username to localStorage
      localStorage.setItem('username', username);
      // Save profilePic to localStorage
      localStorage.setItem('profilePic', base64String);

      alert('Registration successful!');

      // Redirect to chat page or do something else after registration
      window.location.href = '/chat'; // Replace with your chat page URL
    }).catch(function(error) {
      console.error('Error writing to Firebase Database:', error);
      alert('Registration failed. Please try again.');
    });
  };
  reader.readAsDataURL(file);
});
