// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "YOUR_API_KEY",
    authDomain: "AUTH_DOMAIN",
    databaseURL: "DATABASE_URL",
    projectId: "PROJECT_ID",
    storageBucket: "STORAGE_BUCKET",
    messagingSenderId: "MESSAGING_ID",
    appId: "APP_ID",
    measurementId: "MESAUREMENT_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Framework7
var app = new Framework7();
var $$ = Dom7;

// Get username and profile pic from localStorage
var username = localStorage.getItem('username');
var profilePic = localStorage.getItem('profilePic');

// Set profile picture in navbar
var profileAvatar = document.getElementById('profileAvatar');
if (profilePic) {
  profileAvatar.style.backgroundImage = `url('data:image/jpeg;base64,${profilePic}')`;
} else {
  profileAvatar.style.backgroundImage = `url('https://cdn-icons-png.flaticon.com/512/3237/3237472.png')`;
}

// Init Messages
var messages = app.messages.create({
  el: '.messages',
  firstMessageRule: function(message, previousMessage, nextMessage) {
    if (message.isTitle) return false;
    if (!previousMessage || previousMessage.type !== message.type || previousMessage.name !== message.name) return true;
    return false;
  },
  lastMessageRule: function(message, previousMessage, nextMessage) {
    if (message.isTitle) return false;
    if (!nextMessage || nextMessage.type !== message.type || nextMessage.name !== message.name) return true;
    return false;
  },
  tailMessageRule: function(message, previousMessage, nextMessage) {
    if (message.isTitle) return false;
    if (!nextMessage || nextMessage.type !== message.type || nextMessage.name !== message.name) return true;
    return false;
  }
});

// Init Messagebar
var messagebar = app.messagebar.create({
  el: '.messagebar'
});

// Function to play sent message sound
function playSentMessageSound() {
  var sentSound = document.getElementById('sentSound');
  sentSound.play().catch(function(error) {
    console.error('Error playing sent sound:', error);
  });
}

// Function to play received message sound
function playReceivedMessageSound() {
  var receivedSound = document.getElementById('receivedSound');
  receivedSound.play().catch(function(error) {
    console.error('Error playing received sound:', error);
  });
}

// Function to display a single message
function displayMessage(message) {
  // Retrieve profile picture from Firebase
  firebase.database().ref('users/' + message.name).once('value').then(function(userSnapshot) {
    console.log('Retrieved user data:', userSnapshot.val());
    var userData = userSnapshot.val();
    var userProfilePic = userData && userData.profilePic ? `data:image/jpeg;base64,${userData.profilePic}` : 'https://cdn-icons-png.flaticon.com/512/3237/3237472.png';

    if (message.name === username) {
      messages.addMessage({
        text: message.text,
        type: 'sent',
        name: message.name,
        avatar: userProfilePic,
        date: new Date(message.timestamp)
      });
      playSentMessageSound();
    } else {
      messages.addMessage({
        text: message.text,
        type: 'received',
        name: message.name,
        avatar: userProfilePic,
        date: new Date(message.timestamp)
      });
      playReceivedMessageSound();
    }
  }).catch(function(error) {
    console.error('Error retrieving user data:', error);
  });
}

// Listen for new messages and display them
var messageRef = firebase.database().ref('messages');
messageRef.on('child_added', function(snapshot) {
  var message = snapshot.val();
  displayMessage(message);
});

// Ensure audio can be played after user interaction
window.addEventListener('click', function() {
  playSentMessageSound();
  playReceivedMessageSound();
}, { once: true }); // Add this listener to play audio after first user interaction

// Send Message
$$('.send-link').on('click', function(e) {
  e.preventDefault(); // Prevent default link action

  var text = messagebar.getValue().replace(/\n/g, '<br>').trim();
  if (!text.length) return;

  // Clear area
  messagebar.clear();

  // Get the current timestamp
  var timestamp = new Date().toISOString();

  // Play sent message sound
  playSentMessageSound();

  // Add message to Firebase Realtime Database
  firebase.database().ref('messages').push({
    text: text,
    type: 'sent',
    name: username, // Use the username stored in localStorage
    timestamp: timestamp
  });
});
