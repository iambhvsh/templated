function Wf(e, t) {
  for (var n = 0; n < t.length; n++) {
    const r = t[n];
    if (typeof r != "string" && !Array.isArray(r)) {
      for (const i in r)
        if (i !== "default" && !(i in e)) {
          const o = Object.getOwnPropertyDescriptor(r, i);
          o && Object.defineProperty(e, i, o.get ? o : { enumerable: !0, get: () => r[i] })
        }
    }
  }
  return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }))
}(function() {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
  new MutationObserver(i => {
    for (const o of i)
      if (o.type === "childList")
        for (const a of o.addedNodes) a.tagName === "LINK" && a.rel === "modulepreload" && r(a)
  }).observe(document, { childList: !0, subtree: !0 });

  function n(i) { const o = {}; return i.integrity && (o.integrity = i.integrity), i.referrerPolicy && (o.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? o.credentials = "include" : i.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o }

  function r(i) {
    if (i.ep) return;
    i.ep = !0;
    const o = n(i);
    fetch(i.href, o)
  }
})();

function Vf(e) { return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e }
var m = {},
  Qf = { get exports() { return m }, set exports(e) { m = e } },
  ne = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ii = Symbol.for("react.element"),
  Yf = Symbol.for("react.portal"),
  Kf = Symbol.for("react.fragment"),
  Zf = Symbol.for("react.strict_mode"),
  Gf = Symbol.for("react.profiler"),
  Jf = Symbol.for("react.provider"),
  Xf = Symbol.for("react.context"),
  ep = Symbol.for("react.forward_ref"),
  tp = Symbol.for("react.suspense"),
  np = Symbol.for("react.memo"),
  rp = Symbol.for("react.lazy"),
  Ks = Symbol.iterator;

function ip(e) { return e === null || typeof e != "object" ? null : (e = Ks && e[Ks] || e["@@iterator"], typeof e == "function" ? e : null) }
var pc = { isMounted: function() { return !1 }, enqueueForceUpdate: function() {}, enqueueReplaceState: function() {}, enqueueSetState: function() {} },
  hc = Object.assign,
  gc = {};

function Er(e, t, n) { this.props = e, this.context = t, this.refs = gc, this.updater = n || pc } Er.prototype.isReactComponent = {};
Er.prototype.setState = function(e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, e, t, "setState")
};
Er.prototype.forceUpdate = function(e) { this.updater.enqueueForceUpdate(this, e, "forceUpdate") };

function vc() {} vc.prototype = Er.prototype;

function Za(e, t, n) { this.props = e, this.context = t, this.refs = gc, this.updater = n || pc }
var Ga = Za.prototype = new vc;
Ga.constructor = Za;
hc(Ga, Er.prototype);
Ga.isPureReactComponent = !0;
var Zs = Array.isArray,
  yc = Object.prototype.hasOwnProperty,
  Ja = { current: null },
  xc = { key: !0, ref: !0, __self: !0, __source: !0 };

function kc(e, t, n) {
  var r, i = {},
    o = null,
    a = null;
  if (t != null)
    for (r in t.ref !== void 0 && (a = t.ref), t.key !== void 0 && (o = "" + t.key), t) yc.call(t, r) && !xc.hasOwnProperty(r) && (i[r] = t[r]);
  var s = arguments.length - 2;
  if (s === 1) i.children = n;
  else if (1 < s) {
    for (var u = Array(s), d = 0; d < s; d++) u[d] = arguments[d + 2];
    i.children = u
  }
  if (e && e.defaultProps)
    for (r in s = e.defaultProps, s) i[r] === void 0 && (i[r] = s[r]);
  return { $$typeof: Ii, type: e, key: o, ref: a, props: i, _owner: Ja.current }
}

function lp(e, t) { return { $$typeof: Ii, type: e.type, key: t, ref: e.ref, props: e.props, _owner: e._owner } }

function Xa(e) { return typeof e == "object" && e !== null && e.$$typeof === Ii }

function op(e) { var t = { "=": "=0", ":": "=2" }; return "$" + e.replace(/[=:]/g, function(n) { return t[n] }) }
var Gs = /\/+/g;

function ao(e, t) { return typeof e == "object" && e !== null && e.key != null ? op("" + e.key) : t.toString(36) }

function Gi(e, t, n, r, i) {
  var o = typeof e;
  (o === "undefined" || o === "boolean") && (e = null);
  var a = !1;
  if (e === null) a = !0;
  else switch (o) {
    case "string":
    case "number":
      a = !0;
      break;
    case "object":
      switch (e.$$typeof) {
        case Ii:
        case Yf:
          a = !0
      }
  }
  if (a) return a = e, i = i(a), e = r === "" ? "." + ao(a, 0) : r, Zs(i) ? (n = "", e != null && (n = e.replace(Gs, "$&/") + "/"), Gi(i, t, n, "", function(d) { return d })) : i != null && (Xa(i) && (i = lp(i, n + (!i.key || a && a.key === i.key ? "" : ("" + i.key).replace(Gs, "$&/") + "/") + e)), t.push(i)), 1;
  if (a = 0, r = r === "" ? "." : r + ":", Zs(e))
    for (var s = 0; s < e.length; s++) {
      o = e[s];
      var u = r + ao(o, s);
      a += Gi(o, t, n, u, i)
    } else if (u = ip(e), typeof u == "function")
      for (e = u.call(e), s = 0; !(o = e.next()).done;) o = o.value, u = r + ao(o, s++), a += Gi(o, t, n, u, i);
    else if (o === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
  return a
}

function zi(e, t, n) {
  if (e == null) return e;
  var r = [],
    i = 0;
  return Gi(e, r, "", "", function(o) { return t.call(n, o, i++) }), r
}

function ap(e) {
  if (e._status === -1) {
    var t = e._result;
    t = t(), t.then(function(n) {
      (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
    }, function(n) {
      (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
    }), e._status === -1 && (e._status = 0, e._result = t)
  }
  if (e._status === 1) return e._result.default;
  throw e._result
}
var tt = { current: null },
  Ji = { transition: null },
  sp = { ReactCurrentDispatcher: tt, ReactCurrentBatchConfig: Ji, ReactCurrentOwner: Ja };
ne.Children = { map: zi, forEach: function(e, t, n) { zi(e, function() { t.apply(this, arguments) }, n) }, count: function(e) { var t = 0; return zi(e, function() { t++ }), t }, toArray: function(e) { return zi(e, function(t) { return t }) || [] }, only: function(e) { if (!Xa(e)) throw Error("React.Children.only expected to receive a single React element child."); return e } };
ne.Component = Er;
ne.Fragment = Kf;
ne.Profiler = Gf;
ne.PureComponent = Za;
ne.StrictMode = Zf;
ne.Suspense = tp;
ne.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sp;
ne.cloneElement = function(e, t, n) {
  if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
  var r = hc({}, e.props),
    i = e.key,
    o = e.ref,
    a = e._owner;
  if (t != null) { if (t.ref !== void 0 && (o = t.ref, a = Ja.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var s = e.type.defaultProps; for (u in t) yc.call(t, u) && !xc.hasOwnProperty(u) && (r[u] = t[u] === void 0 && s !== void 0 ? s[u] : t[u]) }
  var u = arguments.length - 2;
  if (u === 1) r.children = n;
  else if (1 < u) {
    s = Array(u);
    for (var d = 0; d < u; d++) s[d] = arguments[d + 2];
    r.children = s
  }
  return { $$typeof: Ii, type: e.type, key: i, ref: o, props: r, _owner: a }
};
ne.createContext = function(e) { return e = { $$typeof: Xf, _currentValue: e, _currentValue2: e, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, e.Provider = { $$typeof: Jf, _context: e }, e.Consumer = e };
ne.createElement = kc;
ne.createFactory = function(e) { var t = kc.bind(null, e); return t.type = e, t };
ne.createRef = function() { return { current: null } };
ne.forwardRef = function(e) { return { $$typeof: ep, render: e } };
ne.isValidElement = Xa;
ne.lazy = function(e) { return { $$typeof: rp, _payload: { _status: -1, _result: e }, _init: ap } };
ne.memo = function(e, t) { return { $$typeof: np, type: e, compare: t === void 0 ? null : t } };
ne.startTransition = function(e) {
  var t = Ji.transition;
  Ji.transition = {};
  try { e() } finally { Ji.transition = t }
};
ne.unstable_act = function() { throw Error("act(...) is not supported in production builds of React.") };
ne.useCallback = function(e, t) { return tt.current.useCallback(e, t) };
ne.useContext = function(e) { return tt.current.useContext(e) };
ne.useDebugValue = function() {};
ne.useDeferredValue = function(e) { return tt.current.useDeferredValue(e) };
ne.useEffect = function(e, t) { return tt.current.useEffect(e, t) };
ne.useId = function() { return tt.current.useId() };
ne.useImperativeHandle = function(e, t, n) { return tt.current.useImperativeHandle(e, t, n) };
ne.useInsertionEffect = function(e, t) { return tt.current.useInsertionEffect(e, t) };
ne.useLayoutEffect = function(e, t) { return tt.current.useLayoutEffect(e, t) };
ne.useMemo = function(e, t) { return tt.current.useMemo(e, t) };
ne.useReducer = function(e, t, n) { return tt.current.useReducer(e, t, n) };
ne.useRef = function(e) { return tt.current.useRef(e) };
ne.useState = function(e) { return tt.current.useState(e) };
ne.useSyncExternalStore = function(e, t, n) { return tt.current.useSyncExternalStore(e, t, n) };
ne.useTransition = function() { return tt.current.useTransition() };
ne.version = "18.2.0";
(function(e) { e.exports = ne })(Qf);
const ke = Vf(m),
  Do = Wf({ __proto__: null, default: ke }, [m]);
var Fo = {},
  up = { get exports() { return Fo }, set exports(e) { Fo = e } },
  gt = {},
  jo = {},
  cp = { get exports() { return jo }, set exports(e) { jo = e } },
  bc = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
  function t(T, j) {
    var $ = T.length;
    T.push(j);
    e: for (; 0 < $;) {
      var G = $ - 1 >>> 1,
        J = T[G];
      if (0 < i(J, j)) T[G] = j, T[$] = J, $ = G;
      else break e
    }
  }

  function n(T) { return T.length === 0 ? null : T[0] }

  function r(T) {
    if (T.length === 0) return null;
    var j = T[0],
      $ = T.pop();
    if ($ !== j) {
      T[0] = $;
      e: for (var G = 0, J = T.length, Me = J >>> 1; G < Me;) {
        var ce = 2 * (G + 1) - 1,
          de = T[ce],
          Ce = ce + 1,
          ge = T[Ce];
        if (0 > i(de, $)) Ce < J && 0 > i(ge, de) ? (T[G] = ge, T[Ce] = $, G = Ce) : (T[G] = de, T[ce] = $, G = ce);
        else if (Ce < J && 0 > i(ge, $)) T[G] = ge, T[Ce] = $, G = Ce;
        else break e
      }
    }
    return j
  }

  function i(T, j) { var $ = T.sortIndex - j.sortIndex; return $ !== 0 ? $ : T.id - j.id }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var o = performance;
    e.unstable_now = function() { return o.now() }
  } else {
    var a = Date,
      s = a.now();
    e.unstable_now = function() { return a.now() - s }
  }
  var u = [],
    d = [],
    p = 1,
    v = null,
    g = 3,
    k = !1,
    C = !1,
    b = !1,
    N = typeof setTimeout == "function" ? setTimeout : null,
    y = typeof clearTimeout == "function" ? clearTimeout : null,
    f = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

  function x(T) {
    for (var j = n(d); j !== null;) {
      if (j.callback === null) r(d);
      else if (j.startTime <= T) r(d), j.sortIndex = j.expirationTime, t(u, j);
      else break;
      j = n(d)
    }
  }

  function w(T) {
    if (b = !1, x(T), !C)
      if (n(u) !== null) C = !0, ee(S);
      else {
        var j = n(d);
        j !== null && ie(w, j.startTime - T)
      }
  }

  function S(T, j) {
    C = !1, b && (b = !1, y(L), L = -1), k = !0;
    var $ = g;
    try {
      for (x(j), v = n(u); v !== null && (!(v.expirationTime > j) || T && !_());) {
        var G = v.callback;
        if (typeof G == "function") {
          v.callback = null, g = v.priorityLevel;
          var J = G(v.expirationTime <= j);
          j = e.unstable_now(), typeof J == "function" ? v.callback = J : v === n(u) && r(u), x(j)
        } else r(u);
        v = n(u)
      }
      if (v !== null) var Me = !0;
      else {
        var ce = n(d);
        ce !== null && ie(w, ce.startTime - j), Me = !1
      }
      return Me
    } finally { v = null, g = $, k = !1 }
  }
  var I = !1,
    M = null,
    L = -1,
    B = 5,
    R = -1;

  function _() { return !(e.unstable_now() - R < B) }

  function q() {
    if (M !== null) {
      var T = e.unstable_now();
      R = T;
      var j = !0;
      try { j = M(!0, T) } finally { j ? V() : (I = !1, M = null) }
    } else I = !1
  }
  var V;
  if (typeof f == "function") V = function() { f(q) };
  else if (typeof MessageChannel < "u") {
    var X = new MessageChannel,
      ue = X.port2;
    X.port1.onmessage = q, V = function() { ue.postMessage(null) }
  } else V = function() { N(q, 0) };

  function ee(T) { M = T, I || (I = !0, V()) }

  function ie(T, j) { L = N(function() { T(e.unstable_now()) }, j) } e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(T) { T.callback = null }, e.unstable_continueExecution = function() { C || k || (C = !0, ee(S)) }, e.unstable_forceFrameRate = function(T) { 0 > T || 125 < T ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : B = 0 < T ? Math.floor(1e3 / T) : 5 }, e.unstable_getCurrentPriorityLevel = function() { return g }, e.unstable_getFirstCallbackNode = function() { return n(u) }, e.unstable_next = function(T) {
    switch (g) {
      case 1:
      case 2:
      case 3:
        var j = 3;
        break;
      default:
        j = g
    }
    var $ = g;
    g = j;
    try { return T() } finally { g = $ }
  }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(T, j) {
    switch (T) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        T = 3
    }
    var $ = g;
    g = T;
    try { return j() } finally { g = $ }
  }, e.unstable_scheduleCallback = function(T, j, $) {
    var G = e.unstable_now();
    switch (typeof $ == "object" && $ !== null ? ($ = $.delay, $ = typeof $ == "number" && 0 < $ ? G + $ : G) : $ = G, T) {
      case 1:
        var J = -1;
        break;
      case 2:
        J = 250;
        break;
      case 5:
        J = 1073741823;
        break;
      case 4:
        J = 1e4;
        break;
      default:
        J = 5e3
    }
    return J = $ + J, T = { id: p++, callback: j, priorityLevel: T, startTime: $, expirationTime: J, sortIndex: -1 }, $ > G ? (T.sortIndex = $, t(d, T), n(u) === null && T === n(d) && (b ? (y(L), L = -1) : b = !0, ie(w, $ - G))) : (T.sortIndex = J, t(u, T), C || k || (C = !0, ee(S))), T
  }, e.unstable_shouldYield = _, e.unstable_wrapCallback = function(T) {
    var j = g;
    return function() {
      var $ = g;
      g = j;
      try { return T.apply(this, arguments) } finally { g = $ }
    }
  }
})(bc);
(function(e) { e.exports = bc })(cp);
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Cc = m,
  ht = jo;

function E(e) { for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]); return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings." }
var wc = new Set,
  li = {};

function Xn(e, t) { Ir(e, t), Ir(e + "Capture", t) }

function Ir(e, t) { for (li[e] = t, e = 0; e < t.length; e++) wc.add(t[e]) }
var rn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
  $o = Object.prototype.hasOwnProperty,
  dp = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
  Js = {},
  Xs = {};

function mp(e) { return $o.call(Xs, e) ? !0 : $o.call(Js, e) ? !1 : dp.test(e) ? Xs[e] = !0 : (Js[e] = !0, !1) }

function fp(e, t, n, r) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
    default:
      return !1
  }
}

function pp(e, t, n, r) {
  if (t === null || typeof t > "u" || fp(e, t, n, r)) return !0;
  if (r) return !1;
  if (n !== null) switch (n.type) {
    case 3:
      return !t;
    case 4:
      return t === !1;
    case 5:
      return isNaN(t);
    case 6:
      return isNaN(t) || 1 > t
  }
  return !1
}

function nt(e, t, n, r, i, o, a) { this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = i, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = a }
var He = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) { He[e] = new nt(e, 0, !1, e, null, !1, !1) });
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
  var t = e[0];
  He[t] = new nt(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) { He[e] = new nt(e, 2, !1, e.toLowerCase(), null, !1, !1) });
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) { He[e] = new nt(e, 2, !1, e, null, !1, !1) });
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) { He[e] = new nt(e, 3, !1, e.toLowerCase(), null, !1, !1) });
["checked", "multiple", "muted", "selected"].forEach(function(e) { He[e] = new nt(e, 3, !0, e, null, !1, !1) });
["capture", "download"].forEach(function(e) { He[e] = new nt(e, 4, !1, e, null, !1, !1) });
["cols", "rows", "size", "span"].forEach(function(e) { He[e] = new nt(e, 6, !1, e, null, !1, !1) });
["rowSpan", "start"].forEach(function(e) { He[e] = new nt(e, 5, !1, e.toLowerCase(), null, !1, !1) });
var es = /[\-:]([a-z])/g;

function ts(e) { return e[1].toUpperCase() }
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
  var t = e.replace(es, ts);
  He[t] = new nt(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
  var t = e.replace(es, ts);
  He[t] = new nt(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
  var t = e.replace(es, ts);
  He[t] = new nt(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) { He[e] = new nt(e, 1, !1, e.toLowerCase(), null, !1, !1) });
He.xlinkHref = new nt("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) { He[e] = new nt(e, 1, !1, e.toLowerCase(), null, !0, !0) });

function ns(e, t, n, r) {
  var i = He.hasOwnProperty(t) ? He[t] : null;
  (i !== null ? i.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (pp(t, n, i, r) && (n = null), r || i === null ? mp(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : i.mustUseProperty ? e[i.propertyName] = n === null ? i.type === 3 ? !1 : "" : n : (t = i.attributeName, r = i.attributeNamespace, n === null ? e.removeAttribute(t) : (i = i.type, n = i === 3 || i === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var sn = Cc.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
  Oi = Symbol.for("react.element"),
  or = Symbol.for("react.portal"),
  ar = Symbol.for("react.fragment"),
  rs = Symbol.for("react.strict_mode"),
  Ao = Symbol.for("react.profiler"),
  Nc = Symbol.for("react.provider"),
  Ic = Symbol.for("react.context"),
  is = Symbol.for("react.forward_ref"),
  Ho = Symbol.for("react.suspense"),
  qo = Symbol.for("react.suspense_list"),
  ls = Symbol.for("react.memo"),
  dn = Symbol.for("react.lazy"),
  Sc = Symbol.for("react.offscreen"),
  eu = Symbol.iterator;

function _r(e) { return e === null || typeof e != "object" ? null : (e = eu && e[eu] || e["@@iterator"], typeof e == "function" ? e : null) }
var Ie = Object.assign,
  so;

function Ur(e) {
  if (so === void 0) try { throw Error() } catch (n) {
    var t = n.stack.trim().match(/\n( *(at )?)/);
    so = t && t[1] || ""
  }
  return `
` + so + e
}
var uo = !1;

function co(e, t) {
  if (!e || uo) return "";
  uo = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t)
      if (t = function() { throw Error() }, Object.defineProperty(t.prototype, "props", { set: function() { throw Error() } }), typeof Reflect == "object" && Reflect.construct) { try { Reflect.construct(t, []) } catch (d) { var r = d } Reflect.construct(e, [], t) } else { try { t.call() } catch (d) { r = d } e.call(t.prototype) }
    else { try { throw Error() } catch (d) { r = d } e() }
  } catch (d) {
    if (d && r && typeof d.stack == "string") {
      for (var i = d.stack.split(`
`), o = r.stack.split(`
`), a = i.length - 1, s = o.length - 1; 1 <= a && 0 <= s && i[a] !== o[s];) s--;
      for (; 1 <= a && 0 <= s; a--, s--)
        if (i[a] !== o[s]) {
          if (a !== 1 || s !== 1)
            do
              if (a--, s--, 0 > s || i[a] !== o[s]) { var u = `
` + i[a].replace(" at new ", " at "); return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u } while (1 <= a && 0 <= s);
          break
        }
    }
  } finally { uo = !1, Error.prepareStackTrace = n }
  return (e = e ? e.displayName || e.name : "") ? Ur(e) : ""
}

function hp(e) {
  switch (e.tag) {
    case 5:
      return Ur(e.type);
    case 16:
      return Ur("Lazy");
    case 13:
      return Ur("Suspense");
    case 19:
      return Ur("SuspenseList");
    case 0:
    case 2:
    case 15:
      return e = co(e.type, !1), e;
    case 11:
      return e = co(e.type.render, !1), e;
    case 1:
      return e = co(e.type, !0), e;
    default:
      return ""
  }
}

function Uo(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case ar:
      return "Fragment";
    case or:
      return "Portal";
    case Ao:
      return "Profiler";
    case rs:
      return "StrictMode";
    case Ho:
      return "Suspense";
    case qo:
      return "SuspenseList"
  }
  if (typeof e == "object") switch (e.$$typeof) {
    case Ic:
      return (e.displayName || "Context") + ".Consumer";
    case Nc:
      return (e._context.displayName || "Context") + ".Provider";
    case is:
      var t = e.render;
      return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
    case ls:
      return t = e.displayName || null, t !== null ? t : Uo(e.type) || "Memo";
    case dn:
      t = e._payload, e = e._init;
      try { return Uo(e(t)) } catch {}
  }
  return null
}

function gp(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Uo(t);
    case 8:
      return t === rs ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t
  }
  return null
}

function Bn(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return ""
  }
}

function Pc(e) { var t = e.type; return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio") }

function vp(e) {
  var t = Pc(e) ? "checked" : "value",
    n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
    r = "" + e[t];
  if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
    var i = n.get,
      o = n.set;
    return Object.defineProperty(e, t, { configurable: !0, get: function() { return i.call(this) }, set: function(a) { r = "" + a, o.call(this, a) } }), Object.defineProperty(e, t, { enumerable: n.enumerable }), { getValue: function() { return r }, setValue: function(a) { r = "" + a }, stopTracking: function() { e._valueTracker = null, delete e[t] } }
  }
}

function _i(e) { e._valueTracker || (e._valueTracker = vp(e)) }

function Mc(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var n = t.getValue(),
    r = "";
  return e && (r = Pc(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function ml(e) { if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null; try { return e.activeElement || e.body } catch { return e.body } }

function Wo(e, t) { var n = t.checked; return Ie({}, t, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: n ?? e._wrapperState.initialChecked }) }

function tu(e, t) {
  var n = t.defaultValue == null ? "" : t.defaultValue,
    r = t.checked != null ? t.checked : t.defaultChecked;
  n = Bn(t.value != null ? t.value : n), e._wrapperState = { initialChecked: r, initialValue: n, controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null }
}

function Lc(e, t) { t = t.checked, t != null && ns(e, "checked", t, !1) }

function Vo(e, t) {
  Lc(e, t);
  var n = Bn(t.value),
    r = t.type;
  if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
  else if (r === "submit" || r === "reset") { e.removeAttribute("value"); return } t.hasOwnProperty("value") ? Qo(e, t.type, n) : t.hasOwnProperty("defaultValue") && Qo(e, t.type, Bn(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function nu(e, t, n) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var r = t.type;
    if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
    t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
  }
  n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function Qo(e, t, n) {
  (t !== "number" || ml(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Wr = Array.isArray;

function xr(e, t, n, r) { if (e = e.options, t) { t = {}; for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0; for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0) } else { for (n = "" + Bn(n), t = null, i = 0; i < e.length; i++) { if (e[i].value === n) { e[i].selected = !0, r && (e[i].defaultSelected = !0); return } t !== null || e[i].disabled || (t = e[i]) } t !== null && (t.selected = !0) } }

function Yo(e, t) { if (t.dangerouslySetInnerHTML != null) throw Error(E(91)); return Ie({}, t, { value: void 0, defaultValue: void 0, children: "" + e._wrapperState.initialValue }) }

function ru(e, t) {
  var n = t.value;
  if (n == null) {
    if (n = t.children, t = t.defaultValue, n != null) {
      if (t != null) throw Error(E(92));
      if (Wr(n)) {
        if (1 < n.length) throw Error(E(93));
        n = n[0]
      }
      t = n
    }
    t == null && (t = ""), n = t
  }
  e._wrapperState = { initialValue: Bn(n) }
}

function Bc(e, t) {
  var n = Bn(t.value),
    r = Bn(t.defaultValue);
  n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function iu(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function Rc(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml"
  }
}

function Ko(e, t) { return e == null || e === "http://www.w3.org/1999/xhtml" ? Rc(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e }
var Di, Ec = function(e) { return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, i) { MSApp.execUnsafeLocalFunction(function() { return e(t, n, r, i) }) } : e }(function(e, t) {
  if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
  else { for (Di = Di || document.createElement("div"), Di.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = Di.firstChild; e.firstChild;) e.removeChild(e.firstChild); for (; t.firstChild;) e.appendChild(t.firstChild) }
});

function oi(e, t) { if (t) { var n = e.firstChild; if (n && n === e.lastChild && n.nodeType === 3) { n.nodeValue = t; return } } e.textContent = t }
var Zr = { animationIterationCount: !0, aspectRatio: !0, borderImageOutset: !0, borderImageSlice: !0, borderImageWidth: !0, boxFlex: !0, boxFlexGroup: !0, boxOrdinalGroup: !0, columnCount: !0, columns: !0, flex: !0, flexGrow: !0, flexPositive: !0, flexShrink: !0, flexNegative: !0, flexOrder: !0, gridArea: !0, gridRow: !0, gridRowEnd: !0, gridRowSpan: !0, gridRowStart: !0, gridColumn: !0, gridColumnEnd: !0, gridColumnSpan: !0, gridColumnStart: !0, fontWeight: !0, lineClamp: !0, lineHeight: !0, opacity: !0, order: !0, orphans: !0, tabSize: !0, widows: !0, zIndex: !0, zoom: !0, fillOpacity: !0, floodOpacity: !0, stopOpacity: !0, strokeDasharray: !0, strokeDashoffset: !0, strokeMiterlimit: !0, strokeOpacity: !0, strokeWidth: !0 },
  yp = ["Webkit", "ms", "Moz", "O"];
Object.keys(Zr).forEach(function(e) { yp.forEach(function(t) { t = t + e.charAt(0).toUpperCase() + e.substring(1), Zr[t] = Zr[e] }) });

function Tc(e, t, n) { return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Zr.hasOwnProperty(e) && Zr[e] ? ("" + t).trim() : t + "px" }

function zc(e, t) {
  e = e.style;
  for (var n in t)
    if (t.hasOwnProperty(n)) {
      var r = n.indexOf("--") === 0,
        i = Tc(n, t[n], r);
      n === "float" && (n = "cssFloat"), r ? e.setProperty(n, i) : e[n] = i
    }
}
var xp = Ie({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });

function Zo(e, t) { if (t) { if (xp[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(E(137, e)); if (t.dangerouslySetInnerHTML != null) { if (t.children != null) throw Error(E(60)); if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(E(61)) } if (t.style != null && typeof t.style != "object") throw Error(E(62)) } }

function Go(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0
  }
}
var Jo = null;

function os(e) { return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e }
var Xo = null,
  kr = null,
  br = null;

function lu(e) {
  if (e = Mi(e)) {
    if (typeof Xo != "function") throw Error(E(280));
    var t = e.stateNode;
    t && (t = Hl(t), Xo(e.stateNode, e.type, t))
  }
}

function Oc(e) { kr ? br ? br.push(e) : br = [e] : kr = e }

function _c() {
  if (kr) {
    var e = kr,
      t = br;
    if (br = kr = null, lu(e), t)
      for (e = 0; e < t.length; e++) lu(t[e])
  }
}

function Dc(e, t) { return e(t) }

function Fc() {}
var mo = !1;

function jc(e, t, n) {
  if (mo) return e(t, n);
  mo = !0;
  try { return Dc(e, t, n) } finally { mo = !1, (kr !== null || br !== null) && (Fc(), _c()) }
}

function ai(e, t) {
  var n = e.stateNode;
  if (n === null) return null;
  var r = Hl(n);
  if (r === null) return null;
  n = r[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
      break e;
    default:
      e = !1
  }
  if (e) return null;
  if (n && typeof n != "function") throw Error(E(231, t, typeof n));
  return n
}
var ea = !1;
if (rn) try {
  var Dr = {};
  Object.defineProperty(Dr, "passive", { get: function() { ea = !0 } }), window.addEventListener("test", Dr, Dr), window.removeEventListener("test", Dr, Dr)
} catch { ea = !1 }

function kp(e, t, n, r, i, o, a, s, u) { var d = Array.prototype.slice.call(arguments, 3); try { t.apply(n, d) } catch (p) { this.onError(p) } }
var Gr = !1,
  fl = null,
  pl = !1,
  ta = null,
  bp = { onError: function(e) { Gr = !0, fl = e } };

function Cp(e, t, n, r, i, o, a, s, u) { Gr = !1, fl = null, kp.apply(bp, arguments) }

function wp(e, t, n, r, i, o, a, s, u) {
  if (Cp.apply(this, arguments), Gr) {
    if (Gr) {
      var d = fl;
      Gr = !1, fl = null
    } else throw Error(E(198));
    pl || (pl = !0, ta = d)
  }
}

function er(e) {
  var t = e,
    n = e;
  if (e.alternate)
    for (; t.return;) t = t.return;
  else {
    e = t;
    do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
  }
  return t.tag === 3 ? n : null
}

function $c(e) { if (e.tag === 13) { var t = e.memoizedState; if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated } return null }

function ou(e) { if (er(e) !== e) throw Error(E(188)) }

function Np(e) {
  var t = e.alternate;
  if (!t) { if (t = er(e), t === null) throw Error(E(188)); return t !== e ? null : e }
  for (var n = e, r = t;;) {
    var i = n.return;
    if (i === null) break;
    var o = i.alternate;
    if (o === null) { if (r = i.return, r !== null) { n = r; continue } break }
    if (i.child === o.child) {
      for (o = i.child; o;) {
        if (o === n) return ou(i), e;
        if (o === r) return ou(i), t;
        o = o.sibling
      }
      throw Error(E(188))
    }
    if (n.return !== r.return) n = i, r = o;
    else { for (var a = !1, s = i.child; s;) { if (s === n) { a = !0, n = i, r = o; break } if (s === r) { a = !0, r = i, n = o; break } s = s.sibling } if (!a) { for (s = o.child; s;) { if (s === n) { a = !0, n = o, r = i; break } if (s === r) { a = !0, r = o, n = i; break } s = s.sibling } if (!a) throw Error(E(189)) } }
    if (n.alternate !== r) throw Error(E(190))
  }
  if (n.tag !== 3) throw Error(E(188));
  return n.stateNode.current === n ? e : t
}

function Ac(e) { return e = Np(e), e !== null ? Hc(e) : null }

function Hc(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null;) {
    var t = Hc(e);
    if (t !== null) return t;
    e = e.sibling
  }
  return null
}
var qc = ht.unstable_scheduleCallback,
  au = ht.unstable_cancelCallback,
  Ip = ht.unstable_shouldYield,
  Sp = ht.unstable_requestPaint,
  Be = ht.unstable_now,
  Pp = ht.unstable_getCurrentPriorityLevel,
  as = ht.unstable_ImmediatePriority,
  Uc = ht.unstable_UserBlockingPriority,
  hl = ht.unstable_NormalPriority,
  Mp = ht.unstable_LowPriority,
  Wc = ht.unstable_IdlePriority,
  Fl = null,
  Qt = null;

function Lp(e) { if (Qt && typeof Qt.onCommitFiberRoot == "function") try { Qt.onCommitFiberRoot(Fl, e, void 0, (e.current.flags & 128) === 128) } catch {} }
var Dt = Math.clz32 ? Math.clz32 : Ep,
  Bp = Math.log,
  Rp = Math.LN2;

function Ep(e) { return e >>>= 0, e === 0 ? 32 : 31 - (Bp(e) / Rp | 0) | 0 }
var Fi = 64,
  ji = 4194304;

function Vr(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e
  }
}

function gl(e, t) {
  var n = e.pendingLanes;
  if (n === 0) return 0;
  var r = 0,
    i = e.suspendedLanes,
    o = e.pingedLanes,
    a = n & 268435455;
  if (a !== 0) {
    var s = a & ~i;
    s !== 0 ? r = Vr(s) : (o &= a, o !== 0 && (r = Vr(o)))
  } else a = n & ~i, a !== 0 ? r = Vr(a) : o !== 0 && (r = Vr(o));
  if (r === 0) return 0;
  if (t !== 0 && t !== r && !(t & i) && (i = r & -r, o = t & -t, i >= o || i === 16 && (o & 4194240) !== 0)) return t;
  if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
    for (e = e.entanglements, t &= r; 0 < t;) n = 31 - Dt(t), i = 1 << n, r |= e[n], t &= ~i;
  return r
}

function Tp(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1
  }
}

function zp(e, t) {
  for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, o = e.pendingLanes; 0 < o;) {
    var a = 31 - Dt(o),
      s = 1 << a,
      u = i[a];
    u === -1 ? (!(s & n) || s & r) && (i[a] = Tp(s, t)) : u <= t && (e.expiredLanes |= s), o &= ~s
  }
}

function na(e) { return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0 }

function Vc() { var e = Fi; return Fi <<= 1, !(Fi & 4194240) && (Fi = 64), e }

function fo(e) { for (var t = [], n = 0; 31 > n; n++) t.push(e); return t }

function Si(e, t, n) { e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Dt(t), e[t] = n }

function Op(e, t) {
  var n = e.pendingLanes & ~t;
  e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
  var r = e.eventTimes;
  for (e = e.expirationTimes; 0 < n;) {
    var i = 31 - Dt(n),
      o = 1 << i;
    t[i] = 0, r[i] = -1, e[i] = -1, n &= ~o
  }
}

function ss(e, t) {
  var n = e.entangledLanes |= t;
  for (e = e.entanglements; n;) {
    var r = 31 - Dt(n),
      i = 1 << r;
    i & t | e[r] & t && (e[r] |= t), n &= ~i
  }
}
var me = 0;

function Qc(e) { return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1 }
var Yc, us, Kc, Zc, Gc, ra = !1,
  $i = [],
  kn = null,
  bn = null,
  Cn = null,
  si = new Map,
  ui = new Map,
  pn = [],
  _p = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function su(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      kn = null;
      break;
    case "dragenter":
    case "dragleave":
      bn = null;
      break;
    case "mouseover":
    case "mouseout":
      Cn = null;
      break;
    case "pointerover":
    case "pointerout":
      si.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      ui.delete(t.pointerId)
  }
}

function Fr(e, t, n, r, i, o) { return e === null || e.nativeEvent !== o ? (e = { blockedOn: t, domEventName: n, eventSystemFlags: r, nativeEvent: o, targetContainers: [i] }, t !== null && (t = Mi(t), t !== null && us(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e) }

function Dp(e, t, n, r, i) {
  switch (t) {
    case "focusin":
      return kn = Fr(kn, e, t, n, r, i), !0;
    case "dragenter":
      return bn = Fr(bn, e, t, n, r, i), !0;
    case "mouseover":
      return Cn = Fr(Cn, e, t, n, r, i), !0;
    case "pointerover":
      var o = i.pointerId;
      return si.set(o, Fr(si.get(o) || null, e, t, n, r, i)), !0;
    case "gotpointercapture":
      return o = i.pointerId, ui.set(o, Fr(ui.get(o) || null, e, t, n, r, i)), !0
  }
  return !1
}

function Jc(e) { var t = $n(e.target); if (t !== null) { var n = er(t); if (n !== null) { if (t = n.tag, t === 13) { if (t = $c(n), t !== null) { e.blockedOn = t, Gc(e.priority, function() { Kc(n) }); return } } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) { e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null; return } } } e.blockedOn = null }

function Xi(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length;) {
    var n = ia(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (n === null) {
      n = e.nativeEvent;
      var r = new n.constructor(n.type, n);
      Jo = r, n.target.dispatchEvent(r), Jo = null
    } else return t = Mi(n), t !== null && us(t), e.blockedOn = n, !1;
    t.shift()
  }
  return !0
}

function uu(e, t, n) { Xi(e) && n.delete(t) }

function Fp() { ra = !1, kn !== null && Xi(kn) && (kn = null), bn !== null && Xi(bn) && (bn = null), Cn !== null && Xi(Cn) && (Cn = null), si.forEach(uu), ui.forEach(uu) }

function jr(e, t) { e.blockedOn === t && (e.blockedOn = null, ra || (ra = !0, ht.unstable_scheduleCallback(ht.unstable_NormalPriority, Fp))) }

function ci(e) {
  function t(i) { return jr(i, e) }
  if (0 < $i.length) {
    jr($i[0], e);
    for (var n = 1; n < $i.length; n++) {
      var r = $i[n];
      r.blockedOn === e && (r.blockedOn = null)
    }
  }
  for (kn !== null && jr(kn, e), bn !== null && jr(bn, e), Cn !== null && jr(Cn, e), si.forEach(t), ui.forEach(t), n = 0; n < pn.length; n++) r = pn[n], r.blockedOn === e && (r.blockedOn = null);
  for (; 0 < pn.length && (n = pn[0], n.blockedOn === null);) Jc(n), n.blockedOn === null && pn.shift()
}
var Cr = sn.ReactCurrentBatchConfig,
  vl = !0;

function jp(e, t, n, r) {
  var i = me,
    o = Cr.transition;
  Cr.transition = null;
  try { me = 1, cs(e, t, n, r) } finally { me = i, Cr.transition = o }
}

function $p(e, t, n, r) {
  var i = me,
    o = Cr.transition;
  Cr.transition = null;
  try { me = 4, cs(e, t, n, r) } finally { me = i, Cr.transition = o }
}

function cs(e, t, n, r) {
  if (vl) {
    var i = ia(e, t, n, r);
    if (i === null) wo(e, t, r, yl, n), su(e, r);
    else if (Dp(i, e, t, n, r)) r.stopPropagation();
    else if (su(e, r), t & 4 && -1 < _p.indexOf(e)) {
      for (; i !== null;) {
        var o = Mi(i);
        if (o !== null && Yc(o), o = ia(e, t, n, r), o === null && wo(e, t, r, yl, n), o === i) break;
        i = o
      }
      i !== null && r.stopPropagation()
    } else wo(e, t, r, null, n)
  }
}
var yl = null;

function ia(e, t, n, r) {
  if (yl = null, e = os(r), e = $n(e), e !== null)
    if (t = er(e), t === null) e = null;
    else if (n = t.tag, n === 13) {
    if (e = $c(t), e !== null) return e;
    e = null
  } else if (n === 3) {
    if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
    e = null
  } else t !== e && (e = null);
  return yl = e, null
}

function Xc(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (Pp()) {
        case as:
          return 1;
        case Uc:
          return 4;
        case hl:
        case Mp:
          return 16;
        case Wc:
          return 536870912;
        default:
          return 16
      }
    default:
      return 16
  }
}
var gn = null,
  ds = null,
  el = null;

function ed() {
  if (el) return el;
  var e, t = ds,
    n = t.length,
    r, i = "value" in gn ? gn.value : gn.textContent,
    o = i.length;
  for (e = 0; e < n && t[e] === i[e]; e++);
  var a = n - e;
  for (r = 1; r <= a && t[n - r] === i[o - r]; r++);
  return el = i.slice(e, 1 < r ? 1 - r : void 0)
}

function tl(e) { var t = e.keyCode; return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0 }

function Ai() { return !0 }

function cu() { return !1 }

function vt(e) {
  function t(n, r, i, o, a) { this._reactName = n, this._targetInst = i, this.type = r, this.nativeEvent = o, this.target = a, this.currentTarget = null; for (var s in e) e.hasOwnProperty(s) && (n = e[s], this[s] = n ? n(o) : o[s]); return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? Ai : cu, this.isPropagationStopped = cu, this }
  return Ie(t.prototype, {
    preventDefault: function() {
      this.defaultPrevented = !0;
      var n = this.nativeEvent;
      n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Ai)
    },
    stopPropagation: function() {
      var n = this.nativeEvent;
      n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Ai)
    },
    persist: function() {},
    isPersistent: Ai
  }), t
}
var Tr = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(e) { return e.timeStamp || Date.now() }, defaultPrevented: 0, isTrusted: 0 },
  ms = vt(Tr),
  Pi = Ie({}, Tr, { view: 0, detail: 0 }),
  Ap = vt(Pi),
  po, ho, $r, jl = Ie({}, Pi, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: fs, button: 0, buttons: 0, relatedTarget: function(e) { return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget }, movementX: function(e) { return "movementX" in e ? e.movementX : (e !== $r && ($r && e.type === "mousemove" ? (po = e.screenX - $r.screenX, ho = e.screenY - $r.screenY) : ho = po = 0, $r = e), po) }, movementY: function(e) { return "movementY" in e ? e.movementY : ho } }),
  du = vt(jl),
  Hp = Ie({}, jl, { dataTransfer: 0 }),
  qp = vt(Hp),
  Up = Ie({}, Pi, { relatedTarget: 0 }),
  go = vt(Up),
  Wp = Ie({}, Tr, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
  Vp = vt(Wp),
  Qp = Ie({}, Tr, { clipboardData: function(e) { return "clipboardData" in e ? e.clipboardData : window.clipboardData } }),
  Yp = vt(Qp),
  Kp = Ie({}, Tr, { data: 0 }),
  mu = vt(Kp),
  Zp = { Esc: "Escape", Spacebar: " ", Left: "ArrowLeft", Up: "ArrowUp", Right: "ArrowRight", Down: "ArrowDown", Del: "Delete", Win: "OS", Menu: "ContextMenu", Apps: "ContextMenu", Scroll: "ScrollLock", MozPrintableKey: "Unidentified" },
  Gp = { 8: "Backspace", 9: "Tab", 12: "Clear", 13: "Enter", 16: "Shift", 17: "Control", 18: "Alt", 19: "Pause", 20: "CapsLock", 27: "Escape", 32: " ", 33: "PageUp", 34: "PageDown", 35: "End", 36: "Home", 37: "ArrowLeft", 38: "ArrowUp", 39: "ArrowRight", 40: "ArrowDown", 45: "Insert", 46: "Delete", 112: "F1", 113: "F2", 114: "F3", 115: "F4", 116: "F5", 117: "F6", 118: "F7", 119: "F8", 120: "F9", 121: "F10", 122: "F11", 123: "F12", 144: "NumLock", 145: "ScrollLock", 224: "Meta" },
  Jp = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };

function Xp(e) { var t = this.nativeEvent; return t.getModifierState ? t.getModifierState(e) : (e = Jp[e]) ? !!t[e] : !1 }

function fs() { return Xp }
var eh = Ie({}, Pi, { key: function(e) { if (e.key) { var t = Zp[e.key] || e.key; if (t !== "Unidentified") return t } return e.type === "keypress" ? (e = tl(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? Gp[e.keyCode] || "Unidentified" : "" }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: fs, charCode: function(e) { return e.type === "keypress" ? tl(e) : 0 }, keyCode: function(e) { return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0 }, which: function(e) { return e.type === "keypress" ? tl(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0 } }),
  th = vt(eh),
  nh = Ie({}, jl, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }),
  fu = vt(nh),
  rh = Ie({}, Pi, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: fs }),
  ih = vt(rh),
  lh = Ie({}, Tr, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
  oh = vt(lh),
  ah = Ie({}, jl, { deltaX: function(e) { return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0 }, deltaY: function(e) { return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0 }, deltaZ: 0, deltaMode: 0 }),
  sh = vt(ah),
  uh = [9, 13, 27, 32],
  ps = rn && "CompositionEvent" in window,
  Jr = null;
rn && "documentMode" in document && (Jr = document.documentMode);
var ch = rn && "TextEvent" in window && !Jr,
  td = rn && (!ps || Jr && 8 < Jr && 11 >= Jr),
  pu = String.fromCharCode(32),
  hu = !1;

function nd(e, t) {
  switch (e) {
    case "keyup":
      return uh.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1
  }
}

function rd(e) { return e = e.detail, typeof e == "object" && "data" in e ? e.data : null }
var sr = !1;

function dh(e, t) {
  switch (e) {
    case "compositionend":
      return rd(t);
    case "keypress":
      return t.which !== 32 ? null : (hu = !0, pu);
    case "textInput":
      return e = t.data, e === pu && hu ? null : e;
    default:
      return null
  }
}

function mh(e, t) {
  if (sr) return e === "compositionend" || !ps && nd(e, t) ? (e = ed(), el = ds = gn = null, sr = !1, e) : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) { if (t.char && 1 < t.char.length) return t.char; if (t.which) return String.fromCharCode(t.which) }
      return null;
    case "compositionend":
      return td && t.locale !== "ko" ? null : t.data;
    default:
      return null
  }
}
var fh = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };

function gu(e) { var t = e && e.nodeName && e.nodeName.toLowerCase(); return t === "input" ? !!fh[e.type] : t === "textarea" }

function id(e, t, n, r) { Oc(r), t = xl(t, "onChange"), 0 < t.length && (n = new ms("onChange", "change", null, n, r), e.push({ event: n, listeners: t })) }
var Xr = null,
  di = null;

function ph(e) { hd(e, 0) }

function $l(e) { var t = dr(e); if (Mc(t)) return e }

function hh(e, t) { if (e === "change") return t }
var ld = !1;
if (rn) {
  var vo;
  if (rn) {
    var yo = "oninput" in document;
    if (!yo) {
      var vu = document.createElement("div");
      vu.setAttribute("oninput", "return;"), yo = typeof vu.oninput == "function"
    }
    vo = yo
  } else vo = !1;
  ld = vo && (!document.documentMode || 9 < document.documentMode)
}

function yu() { Xr && (Xr.detachEvent("onpropertychange", od), di = Xr = null) }

function od(e) {
  if (e.propertyName === "value" && $l(di)) {
    var t = [];
    id(t, di, e, os(e)), jc(ph, t)
  }
}

function gh(e, t, n) { e === "focusin" ? (yu(), Xr = t, di = n, Xr.attachEvent("onpropertychange", od)) : e === "focusout" && yu() }

function vh(e) { if (e === "selectionchange" || e === "keyup" || e === "keydown") return $l(di) }

function yh(e, t) { if (e === "click") return $l(t) }

function xh(e, t) { if (e === "input" || e === "change") return $l(t) }

function kh(e, t) { return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t }
var jt = typeof Object.is == "function" ? Object.is : kh;

function mi(e, t) {
  if (jt(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
  var n = Object.keys(e),
    r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (r = 0; r < n.length; r++) { var i = n[r]; if (!$o.call(t, i) || !jt(e[i], t[i])) return !1 }
  return !0
}

function xu(e) { for (; e && e.firstChild;) e = e.firstChild; return e }

function ku(e, t) {
  var n = xu(e);
  e = 0;
  for (var r; n;) {
    if (n.nodeType === 3) {
      if (r = e + n.textContent.length, e <= t && r >= t) return { node: n, offset: t - e };
      e = r
    }
    e: { for (; n;) { if (n.nextSibling) { n = n.nextSibling; break e } n = n.parentNode } n = void 0 } n = xu(n)
  }
}

function ad(e, t) { return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? ad(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1 }

function sd() {
  for (var e = window, t = ml(); t instanceof e.HTMLIFrameElement;) {
    try { var n = typeof t.contentWindow.location.href == "string" } catch { n = !1 }
    if (n) e = t.contentWindow;
    else break;
    t = ml(e.document)
  }
  return t
}

function hs(e) { var t = e && e.nodeName && e.nodeName.toLowerCase(); return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true") }

function bh(e) {
  var t = sd(),
    n = e.focusedElem,
    r = e.selectionRange;
  if (t !== n && n && n.ownerDocument && ad(n.ownerDocument.documentElement, n)) {
    if (r !== null && hs(n)) {
      if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
      else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
        e = e.getSelection();
        var i = n.textContent.length,
          o = Math.min(r.start, i);
        r = r.end === void 0 ? o : Math.min(r.end, i), !e.extend && o > r && (i = r, r = o, o = i), i = ku(n, o);
        var a = ku(n, r);
        i && a && (e.rangeCount !== 1 || e.anchorNode !== i.node || e.anchorOffset !== i.offset || e.focusNode !== a.node || e.focusOffset !== a.offset) && (t = t.createRange(), t.setStart(i.node, i.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(a.node, a.offset)) : (t.setEnd(a.node, a.offset), e.addRange(t)))
      }
    }
    for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
  }
}
var Ch = rn && "documentMode" in document && 11 >= document.documentMode,
  ur = null,
  la = null,
  ei = null,
  oa = !1;

function bu(e, t, n) {
  var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  oa || ur == null || ur !== ml(r) || (r = ur, "selectionStart" in r && hs(r) ? r = { start: r.selectionStart, end: r.selectionEnd } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = { anchorNode: r.anchorNode, anchorOffset: r.anchorOffset, focusNode: r.focusNode, focusOffset: r.focusOffset }), ei && mi(ei, r) || (ei = r, r = xl(la, "onSelect"), 0 < r.length && (t = new ms("onSelect", "select", null, t, n), e.push({ event: t, listeners: r }), t.target = ur)))
}

function Hi(e, t) { var n = {}; return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n }
var cr = { animationend: Hi("Animation", "AnimationEnd"), animationiteration: Hi("Animation", "AnimationIteration"), animationstart: Hi("Animation", "AnimationStart"), transitionend: Hi("Transition", "TransitionEnd") },
  xo = {},
  ud = {};
rn && (ud = document.createElement("div").style, "AnimationEvent" in window || (delete cr.animationend.animation, delete cr.animationiteration.animation, delete cr.animationstart.animation), "TransitionEvent" in window || delete cr.transitionend.transition);

function Al(e) {
  if (xo[e]) return xo[e];
  if (!cr[e]) return e;
  var t = cr[e],
    n;
  for (n in t)
    if (t.hasOwnProperty(n) && n in ud) return xo[e] = t[n];
  return e
}
var cd = Al("animationend"),
  dd = Al("animationiteration"),
  md = Al("animationstart"),
  fd = Al("transitionend"),
  pd = new Map,
  Cu = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function En(e, t) { pd.set(e, t), Xn(t, [e]) }
for (var ko = 0; ko < Cu.length; ko++) {
  var bo = Cu[ko],
    wh = bo.toLowerCase(),
    Nh = bo[0].toUpperCase() + bo.slice(1);
  En(wh, "on" + Nh)
}
En(cd, "onAnimationEnd");
En(dd, "onAnimationIteration");
En(md, "onAnimationStart");
En("dblclick", "onDoubleClick");
En("focusin", "onFocus");
En("focusout", "onBlur");
En(fd, "onTransitionEnd");
Ir("onMouseEnter", ["mouseout", "mouseover"]);
Ir("onMouseLeave", ["mouseout", "mouseover"]);
Ir("onPointerEnter", ["pointerout", "pointerover"]);
Ir("onPointerLeave", ["pointerout", "pointerover"]);
Xn("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Xn("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Xn("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Xn("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Xn("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Xn("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Qr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
  Ih = new Set("cancel close invalid load scroll toggle".split(" ").concat(Qr));

function wu(e, t, n) {
  var r = e.type || "unknown-event";
  e.currentTarget = n, wp(r, t, void 0, e), e.currentTarget = null
}

function hd(e, t) {
  t = (t & 4) !== 0;
  for (var n = 0; n < e.length; n++) {
    var r = e[n],
      i = r.event;
    r = r.listeners;
    e: {
      var o = void 0;
      if (t)
        for (var a = r.length - 1; 0 <= a; a--) {
          var s = r[a],
            u = s.instance,
            d = s.currentTarget;
          if (s = s.listener, u !== o && i.isPropagationStopped()) break e;
          wu(i, s, d), o = u
        } else
          for (a = 0; a < r.length; a++) {
            if (s = r[a], u = s.instance, d = s.currentTarget, s = s.listener, u !== o && i.isPropagationStopped()) break e;
            wu(i, s, d), o = u
          }
    }
  }
  if (pl) throw e = ta, pl = !1, ta = null, e
}

function ye(e, t) {
  var n = t[da];
  n === void 0 && (n = t[da] = new Set);
  var r = e + "__bubble";
  n.has(r) || (gd(t, e, 2, !1), n.add(r))
}

function Co(e, t, n) {
  var r = 0;
  t && (r |= 4), gd(n, e, r, t)
}
var qi = "_reactListening" + Math.random().toString(36).slice(2);

function fi(e) {
  if (!e[qi]) {
    e[qi] = !0, wc.forEach(function(n) { n !== "selectionchange" && (Ih.has(n) || Co(n, !1, e), Co(n, !0, e)) });
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[qi] || (t[qi] = !0, Co("selectionchange", !1, t))
  }
}

function gd(e, t, n, r) {
  switch (Xc(t)) {
    case 1:
      var i = jp;
      break;
    case 4:
      i = $p;
      break;
    default:
      i = cs
  }
  n = i.bind(null, t, n, e), i = void 0, !ea || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), r ? i !== void 0 ? e.addEventListener(t, n, { capture: !0, passive: i }) : e.addEventListener(t, n, !0) : i !== void 0 ? e.addEventListener(t, n, { passive: i }) : e.addEventListener(t, n, !1)
}

function wo(e, t, n, r, i) {
  var o = r;
  if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
    if (r === null) return;
    var a = r.tag;
    if (a === 3 || a === 4) {
      var s = r.stateNode.containerInfo;
      if (s === i || s.nodeType === 8 && s.parentNode === i) break;
      if (a === 4)
        for (a = r.return; a !== null;) {
          var u = a.tag;
          if ((u === 3 || u === 4) && (u = a.stateNode.containerInfo, u === i || u.nodeType === 8 && u.parentNode === i)) return;
          a = a.return
        }
      for (; s !== null;) { if (a = $n(s), a === null) return; if (u = a.tag, u === 5 || u === 6) { r = o = a; continue e } s = s.parentNode }
    }
    r = r.return
  }
  jc(function() {
    var d = o,
      p = os(n),
      v = [];
    e: {
      var g = pd.get(e);
      if (g !== void 0) {
        var k = ms,
          C = e;
        switch (e) {
          case "keypress":
            if (tl(n) === 0) break e;
          case "keydown":
          case "keyup":
            k = th;
            break;
          case "focusin":
            C = "focus", k = go;
            break;
          case "focusout":
            C = "blur", k = go;
            break;
          case "beforeblur":
          case "afterblur":
            k = go;
            break;
          case "click":
            if (n.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            k = du;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            k = qp;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            k = ih;
            break;
          case cd:
          case dd:
          case md:
            k = Vp;
            break;
          case fd:
            k = oh;
            break;
          case "scroll":
            k = Ap;
            break;
          case "wheel":
            k = sh;
            break;
          case "copy":
          case "cut":
          case "paste":
            k = Yp;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            k = fu
        }
        var b = (t & 4) !== 0,
          N = !b && e === "scroll",
          y = b ? g !== null ? g + "Capture" : null : g;
        b = [];
        for (var f = d, x; f !== null;) {
          x = f;
          var w = x.stateNode;
          if (x.tag === 5 && w !== null && (x = w, y !== null && (w = ai(f, y), w != null && b.push(pi(f, w, x)))), N) break;
          f = f.return
        }
        0 < b.length && (g = new k(g, C, null, n, p), v.push({ event: g, listeners: b }))
      }
    }
    if (!(t & 7)) {
      e: {
        if (g = e === "mouseover" || e === "pointerover", k = e === "mouseout" || e === "pointerout", g && n !== Jo && (C = n.relatedTarget || n.fromElement) && ($n(C) || C[ln])) break e;
        if ((k || g) && (g = p.window === p ? p : (g = p.ownerDocument) ? g.defaultView || g.parentWindow : window, k ? (C = n.relatedTarget || n.toElement, k = d, C = C ? $n(C) : null, C !== null && (N = er(C), C !== N || C.tag !== 5 && C.tag !== 6) && (C = null)) : (k = null, C = d), k !== C)) {
          if (b = du, w = "onMouseLeave", y = "onMouseEnter", f = "mouse", (e === "pointerout" || e === "pointerover") && (b = fu, w = "onPointerLeave", y = "onPointerEnter", f = "pointer"), N = k == null ? g : dr(k), x = C == null ? g : dr(C), g = new b(w, f + "leave", k, n, p), g.target = N, g.relatedTarget = x, w = null, $n(p) === d && (b = new b(y, f + "enter", C, n, p), b.target = x, b.relatedTarget = N, w = b), N = w, k && C) t: {
            for (b = k, y = C, f = 0, x = b; x; x = rr(x)) f++;
            for (x = 0, w = y; w; w = rr(w)) x++;
            for (; 0 < f - x;) b = rr(b),
            f--;
            for (; 0 < x - f;) y = rr(y),
            x--;
            for (; f--;) {
              if (b === y || y !== null && b === y.alternate) break t;
              b = rr(b), y = rr(y)
            }
            b = null
          }
          else b = null;
          k !== null && Nu(v, g, k, b, !1), C !== null && N !== null && Nu(v, N, C, b, !0)
        }
      }
      e: {
        if (g = d ? dr(d) : window, k = g.nodeName && g.nodeName.toLowerCase(), k === "select" || k === "input" && g.type === "file") var S = hh;
        else if (gu(g))
          if (ld) S = xh;
          else { S = vh; var I = gh }
        else(k = g.nodeName) && k.toLowerCase() === "input" && (g.type === "checkbox" || g.type === "radio") && (S = yh);
        if (S && (S = S(e, d))) { id(v, S, n, p); break e } I && I(e, g, d),
        e === "focusout" && (I = g._wrapperState) && I.controlled && g.type === "number" && Qo(g, "number", g.value)
      }
      switch (I = d ? dr(d) : window, e) {
        case "focusin":
          (gu(I) || I.contentEditable === "true") && (ur = I, la = d, ei = null);
          break;
        case "focusout":
          ei = la = ur = null;
          break;
        case "mousedown":
          oa = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          oa = !1, bu(v, n, p);
          break;
        case "selectionchange":
          if (Ch) break;
        case "keydown":
        case "keyup":
          bu(v, n, p)
      }
      var M;
      if (ps) e: {
        switch (e) {
          case "compositionstart":
            var L = "onCompositionStart";
            break e;
          case "compositionend":
            L = "onCompositionEnd";
            break e;
          case "compositionupdate":
            L = "onCompositionUpdate";
            break e
        }
        L = void 0
      }
      else sr ? nd(e, n) && (L = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (L = "onCompositionStart");L && (td && n.locale !== "ko" && (sr || L !== "onCompositionStart" ? L === "onCompositionEnd" && sr && (M = ed()) : (gn = p, ds = "value" in gn ? gn.value : gn.textContent, sr = !0)), I = xl(d, L), 0 < I.length && (L = new mu(L, e, null, n, p), v.push({ event: L, listeners: I }), M ? L.data = M : (M = rd(n), M !== null && (L.data = M)))),
      (M = ch ? dh(e, n) : mh(e, n)) && (d = xl(d, "onBeforeInput"), 0 < d.length && (p = new mu("onBeforeInput", "beforeinput", null, n, p), v.push({ event: p, listeners: d }), p.data = M))
    }
    hd(v, t)
  })
}

function pi(e, t, n) { return { instance: e, listener: t, currentTarget: n } }

function xl(e, t) {
  for (var n = t + "Capture", r = []; e !== null;) {
    var i = e,
      o = i.stateNode;
    i.tag === 5 && o !== null && (i = o, o = ai(e, n), o != null && r.unshift(pi(e, o, i)), o = ai(e, t), o != null && r.push(pi(e, o, i))), e = e.return
  }
  return r
}

function rr(e) {
  if (e === null) return null;
  do e = e.return; while (e && e.tag !== 5);
  return e || null
}

function Nu(e, t, n, r, i) {
  for (var o = t._reactName, a = []; n !== null && n !== r;) {
    var s = n,
      u = s.alternate,
      d = s.stateNode;
    if (u !== null && u === r) break;
    s.tag === 5 && d !== null && (s = d, i ? (u = ai(n, o), u != null && a.unshift(pi(n, u, s))) : i || (u = ai(n, o), u != null && a.push(pi(n, u, s)))), n = n.return
  }
  a.length !== 0 && e.push({ event: t, listeners: a })
}
var Sh = /\r\n?/g,
  Ph = /\u0000|\uFFFD/g;

function Iu(e) { return (typeof e == "string" ? e : "" + e).replace(Sh, `
`).replace(Ph, "") }

function Ui(e, t, n) { if (t = Iu(t), Iu(e) !== t && n) throw Error(E(425)) }

function kl() {}
var aa = null,
  sa = null;

function ua(e, t) { return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null }
var ca = typeof setTimeout == "function" ? setTimeout : void 0,
  Mh = typeof clearTimeout == "function" ? clearTimeout : void 0,
  Su = typeof Promise == "function" ? Promise : void 0,
  Lh = typeof queueMicrotask == "function" ? queueMicrotask : typeof Su < "u" ? function(e) { return Su.resolve(null).then(e).catch(Bh) } : ca;

function Bh(e) { setTimeout(function() { throw e }) }

function No(e, t) {
  var n = t,
    r = 0;
  do {
    var i = n.nextSibling;
    if (e.removeChild(n), i && i.nodeType === 8)
      if (n = i.data, n === "/$") { if (r === 0) { e.removeChild(i), ci(t); return } r-- } else n !== "$" && n !== "$?" && n !== "$!" || r++;
    n = i
  } while (n);
  ci(t)
}

function wn(e) { for (; e != null; e = e.nextSibling) { var t = e.nodeType; if (t === 1 || t === 3) break; if (t === 8) { if (t = e.data, t === "$" || t === "$!" || t === "$?") break; if (t === "/$") return null } } return e }

function Pu(e) {
  e = e.previousSibling;
  for (var t = 0; e;) {
    if (e.nodeType === 8) {
      var n = e.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (t === 0) return e;
        t--
      } else n === "/$" && t++
    }
    e = e.previousSibling
  }
  return null
}
var zr = Math.random().toString(36).slice(2),
  Wt = "__reactFiber$" + zr,
  hi = "__reactProps$" + zr,
  ln = "__reactContainer$" + zr,
  da = "__reactEvents$" + zr,
  Rh = "__reactListeners$" + zr,
  Eh = "__reactHandles$" + zr;

function $n(e) {
  var t = e[Wt];
  if (t) return t;
  for (var n = e.parentNode; n;) {
    if (t = n[ln] || n[Wt]) {
      if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
        for (e = Pu(e); e !== null;) {
          if (n = e[Wt]) return n;
          e = Pu(e)
        }
      return t
    }
    e = n, n = e.parentNode
  }
  return null
}

function Mi(e) { return e = e[Wt] || e[ln], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e }

function dr(e) { if (e.tag === 5 || e.tag === 6) return e.stateNode; throw Error(E(33)) }

function Hl(e) { return e[hi] || null }
var ma = [],
  mr = -1;

function Tn(e) { return { current: e } }

function xe(e) { 0 > mr || (e.current = ma[mr], ma[mr] = null, mr--) }

function he(e, t) { mr++, ma[mr] = e.current, e.current = t }
var Rn = {},
  Ke = Tn(Rn),
  ot = Tn(!1),
  Qn = Rn;

function Sr(e, t) {
  var n = e.type.contextTypes;
  if (!n) return Rn;
  var r = e.stateNode;
  if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
  var i = {},
    o;
  for (o in n) i[o] = t[o];
  return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i
}

function at(e) { return e = e.childContextTypes, e != null }

function bl() { xe(ot), xe(Ke) }

function Mu(e, t, n) {
  if (Ke.current !== Rn) throw Error(E(168));
  he(Ke, t), he(ot, n)
}

function vd(e, t, n) {
  var r = e.stateNode;
  if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
  r = r.getChildContext();
  for (var i in r)
    if (!(i in t)) throw Error(E(108, gp(e) || "Unknown", i));
  return Ie({}, n, r)
}

function Cl(e) { return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || Rn, Qn = Ke.current, he(Ke, e), he(ot, ot.current), !0 }

function Lu(e, t, n) {
  var r = e.stateNode;
  if (!r) throw Error(E(169));
  n ? (e = vd(e, t, Qn), r.__reactInternalMemoizedMergedChildContext = e, xe(ot), xe(Ke), he(Ke, e)) : xe(ot), he(ot, n)
}
var Jt = null,
  ql = !1,
  Io = !1;

function yd(e) { Jt === null ? Jt = [e] : Jt.push(e) }

function Th(e) { ql = !0, yd(e) }

function zn() {
  if (!Io && Jt !== null) {
    Io = !0;
    var e = 0,
      t = me;
    try {
      var n = Jt;
      for (me = 1; e < n.length; e++) {
        var r = n[e];
        do r = r(!0); while (r !== null)
      }
      Jt = null, ql = !1
    } catch (i) { throw Jt !== null && (Jt = Jt.slice(e + 1)), qc(as, zn), i } finally { me = t, Io = !1 }
  }
  return null
}
var fr = [],
  pr = 0,
  wl = null,
  Nl = 0,
  Ct = [],
  wt = 0,
  Yn = null,
  Xt = 1,
  en = "";

function On(e, t) { fr[pr++] = Nl, fr[pr++] = wl, wl = e, Nl = t }

function xd(e, t, n) {
  Ct[wt++] = Xt, Ct[wt++] = en, Ct[wt++] = Yn, Yn = e;
  var r = Xt;
  e = en;
  var i = 32 - Dt(r) - 1;
  r &= ~(1 << i), n += 1;
  var o = 32 - Dt(t) + i;
  if (30 < o) {
    var a = i - i % 5;
    o = (r & (1 << a) - 1).toString(32), r >>= a, i -= a, Xt = 1 << 32 - Dt(t) + i | n << i | r, en = o + e
  } else Xt = 1 << o | n << i | r, en = e
}

function gs(e) { e.return !== null && (On(e, 1), xd(e, 1, 0)) }

function vs(e) { for (; e === wl;) wl = fr[--pr], fr[pr] = null, Nl = fr[--pr], fr[pr] = null; for (; e === Yn;) Yn = Ct[--wt], Ct[wt] = null, en = Ct[--wt], Ct[wt] = null, Xt = Ct[--wt], Ct[wt] = null }
var pt = null,
  ft = null,
  be = !1,
  _t = null;

function kd(e, t) {
  var n = Nt(5, null, null, 0);
  n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function Bu(e, t) {
  switch (e.tag) {
    case 5:
      var n = e.type;
      return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, pt = e, ft = wn(t.firstChild), !0) : !1;
    case 6:
      return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, pt = e, ft = null, !0) : !1;
    case 13:
      return t = t.nodeType !== 8 ? null : t, t !== null ? (n = Yn !== null ? { id: Xt, overflow: en } : null, e.memoizedState = { dehydrated: t, treeContext: n, retryLane: 1073741824 }, n = Nt(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, pt = e, ft = null, !0) : !1;
    default:
      return !1
  }
}

function fa(e) { return (e.mode & 1) !== 0 && (e.flags & 128) === 0 }

function pa(e) {
  if (be) {
    var t = ft;
    if (t) {
      var n = t;
      if (!Bu(e, t)) {
        if (fa(e)) throw Error(E(418));
        t = wn(n.nextSibling);
        var r = pt;
        t && Bu(e, t) ? kd(r, n) : (e.flags = e.flags & -4097 | 2, be = !1, pt = e)
      }
    } else {
      if (fa(e)) throw Error(E(418));
      e.flags = e.flags & -4097 | 2, be = !1, pt = e
    }
  }
}

function Ru(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
  pt = e
}

function Wi(e) {
  if (e !== pt) return !1;
  if (!be) return Ru(e), be = !0, !1;
  var t;
  if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !ua(e.type, e.memoizedProps)), t && (t = ft)) { if (fa(e)) throw bd(), Error(E(418)); for (; t;) kd(e, t), t = wn(t.nextSibling) }
  if (Ru(e), e.tag === 13) {
    if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(E(317));
    e: { for (e = e.nextSibling, t = 0; e;) { if (e.nodeType === 8) { var n = e.data; if (n === "/$") { if (t === 0) { ft = wn(e.nextSibling); break e } t-- } else n !== "$" && n !== "$!" && n !== "$?" || t++ } e = e.nextSibling } ft = null }
  } else ft = pt ? wn(e.stateNode.nextSibling) : null;
  return !0
}

function bd() { for (var e = ft; e;) e = wn(e.nextSibling) }

function Pr() { ft = pt = null, be = !1 }

function ys(e) { _t === null ? _t = [e] : _t.push(e) }
var zh = sn.ReactCurrentBatchConfig;

function Tt(e, t) { if (e && e.defaultProps) { t = Ie({}, t), e = e.defaultProps; for (var n in e) t[n] === void 0 && (t[n] = e[n]); return t } return t }
var Il = Tn(null),
  Sl = null,
  hr = null,
  xs = null;

function ks() { xs = hr = Sl = null }

function bs(e) {
  var t = Il.current;
  xe(Il), e._currentValue = t
}

function ha(e, t, n) {
  for (; e !== null;) {
    var r = e.alternate;
    if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
    e = e.return
  }
}

function wr(e, t) { Sl = e, xs = hr = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (lt = !0), e.firstContext = null) }

function St(e) {
  var t = e._currentValue;
  if (xs !== e)
    if (e = { context: e, memoizedValue: t, next: null }, hr === null) {
      if (Sl === null) throw Error(E(308));
      hr = e, Sl.dependencies = { lanes: 0, firstContext: e }
    } else hr = hr.next = e;
  return t
}
var An = null;

function Cs(e) { An === null ? An = [e] : An.push(e) }

function Cd(e, t, n, r) { var i = t.interleaved; return i === null ? (n.next = n, Cs(t)) : (n.next = i.next, i.next = n), t.interleaved = n, on(e, r) }

function on(e, t) { e.lanes |= t; var n = e.alternate; for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return; return n.tag === 3 ? n.stateNode : null }
var mn = !1;

function ws(e) { e.updateQueue = { baseState: e.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null } }

function wd(e, t) { e = e.updateQueue, t.updateQueue === e && (t.updateQueue = { baseState: e.baseState, firstBaseUpdate: e.firstBaseUpdate, lastBaseUpdate: e.lastBaseUpdate, shared: e.shared, effects: e.effects }) }

function nn(e, t) { return { eventTime: e, lane: t, tag: 0, payload: null, callback: null, next: null } }

function Nn(e, t, n) { var r = e.updateQueue; if (r === null) return null; if (r = r.shared, ae & 2) { var i = r.pending; return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, on(e, n) } return i = r.interleaved, i === null ? (t.next = t, Cs(r)) : (t.next = i.next, i.next = t), r.interleaved = t, on(e, n) }

function nl(e, t, n) {
  if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
    var r = t.lanes;
    r &= e.pendingLanes, n |= r, t.lanes = n, ss(e, n)
  }
}

function Eu(e, t) {
  var n = e.updateQueue,
    r = e.alternate;
  if (r !== null && (r = r.updateQueue, n === r)) {
    var i = null,
      o = null;
    if (n = n.firstBaseUpdate, n !== null) {
      do {
        var a = { eventTime: n.eventTime, lane: n.lane, tag: n.tag, payload: n.payload, callback: n.callback, next: null };
        o === null ? i = o = a : o = o.next = a, n = n.next
      } while (n !== null);
      o === null ? i = o = t : o = o.next = t
    } else i = o = t;
    n = { baseState: r.baseState, firstBaseUpdate: i, lastBaseUpdate: o, shared: r.shared, effects: r.effects }, e.updateQueue = n;
    return
  }
  e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function Pl(e, t, n, r) {
  var i = e.updateQueue;
  mn = !1;
  var o = i.firstBaseUpdate,
    a = i.lastBaseUpdate,
    s = i.shared.pending;
  if (s !== null) {
    i.shared.pending = null;
    var u = s,
      d = u.next;
    u.next = null, a === null ? o = d : a.next = d, a = u;
    var p = e.alternate;
    p !== null && (p = p.updateQueue, s = p.lastBaseUpdate, s !== a && (s === null ? p.firstBaseUpdate = d : s.next = d, p.lastBaseUpdate = u))
  }
  if (o !== null) {
    var v = i.baseState;
    a = 0, p = d = u = null, s = o;
    do {
      var g = s.lane,
        k = s.eventTime;
      if ((r & g) === g) {
        p !== null && (p = p.next = { eventTime: k, lane: 0, tag: s.tag, payload: s.payload, callback: s.callback, next: null });
        e: {
          var C = e,
            b = s;
          switch (g = t, k = n, b.tag) {
            case 1:
              if (C = b.payload, typeof C == "function") { v = C.call(k, v, g); break e } v = C;
              break e;
            case 3:
              C.flags = C.flags & -65537 | 128;
            case 0:
              if (C = b.payload, g = typeof C == "function" ? C.call(k, v, g) : C, g == null) break e;
              v = Ie({}, v, g);
              break e;
            case 2:
              mn = !0
          }
        }
        s.callback !== null && s.lane !== 0 && (e.flags |= 64, g = i.effects, g === null ? i.effects = [s] : g.push(s))
      } else k = { eventTime: k, lane: g, tag: s.tag, payload: s.payload, callback: s.callback, next: null }, p === null ? (d = p = k, u = v) : p = p.next = k, a |= g;
      if (s = s.next, s === null) {
        if (s = i.shared.pending, s === null) break;
        g = s, s = g.next, g.next = null, i.lastBaseUpdate = g, i.shared.pending = null
      }
    } while (1);
    if (p === null && (u = v), i.baseState = u, i.firstBaseUpdate = d, i.lastBaseUpdate = p, t = i.shared.interleaved, t !== null) {
      i = t;
      do a |= i.lane, i = i.next; while (i !== t)
    } else o === null && (i.shared.lanes = 0);
    Zn |= a, e.lanes = a, e.memoizedState = v
  }
}

function Tu(e, t, n) {
  if (e = t.effects, t.effects = null, e !== null)
    for (t = 0; t < e.length; t++) {
      var r = e[t],
        i = r.callback;
      if (i !== null) {
        if (r.callback = null, r = n, typeof i != "function") throw Error(E(191, i));
        i.call(r)
      }
    }
}
var Nd = new Cc.Component().refs;

function ga(e, t, n, r) { t = e.memoizedState, n = n(r, t), n = n == null ? t : Ie({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n) }
var Ul = {
  isMounted: function(e) { return (e = e._reactInternals) ? er(e) === e : !1 },
  enqueueSetState: function(e, t, n) {
    e = e._reactInternals;
    var r = et(),
      i = Sn(e),
      o = nn(r, i);
    o.payload = t, n != null && (o.callback = n), t = Nn(e, o, i), t !== null && (Ft(t, e, i, r), nl(t, e, i))
  },
  enqueueReplaceState: function(e, t, n) {
    e = e._reactInternals;
    var r = et(),
      i = Sn(e),
      o = nn(r, i);
    o.tag = 1, o.payload = t, n != null && (o.callback = n), t = Nn(e, o, i), t !== null && (Ft(t, e, i, r), nl(t, e, i))
  },
  enqueueForceUpdate: function(e, t) {
    e = e._reactInternals;
    var n = et(),
      r = Sn(e),
      i = nn(n, r);
    i.tag = 2, t != null && (i.callback = t), t = Nn(e, i, r), t !== null && (Ft(t, e, r, n), nl(t, e, r))
  }
};

function zu(e, t, n, r, i, o, a) { return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, a) : t.prototype && t.prototype.isPureReactComponent ? !mi(n, r) || !mi(i, o) : !0 }

function Id(e, t, n) {
  var r = !1,
    i = Rn,
    o = t.contextType;
  return typeof o == "object" && o !== null ? o = St(o) : (i = at(t) ? Qn : Ke.current, r = t.contextTypes, o = (r = r != null) ? Sr(e, i) : Rn), t = new t(n, o), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = Ul, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = o), t
}

function Ou(e, t, n, r) { e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ul.enqueueReplaceState(t, t.state, null) }

function va(e, t, n, r) {
  var i = e.stateNode;
  i.props = n, i.state = e.memoizedState, i.refs = Nd, ws(e);
  var o = t.contextType;
  typeof o == "object" && o !== null ? i.context = St(o) : (o = at(t) ? Qn : Ke.current, i.context = Sr(e, o)), i.state = e.memoizedState, o = t.getDerivedStateFromProps, typeof o == "function" && (ga(e, t, o, n), i.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (t = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), t !== i.state && Ul.enqueueReplaceState(i, i.state, null), Pl(e, n, i, r), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4194308)
}

function Ar(e, t, n) {
  if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
    if (n._owner) {
      if (n = n._owner, n) { if (n.tag !== 1) throw Error(E(309)); var r = n.stateNode }
      if (!r) throw Error(E(147, e));
      var i = r,
        o = "" + e;
      return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(a) {
        var s = i.refs;
        s === Nd && (s = i.refs = {}), a === null ? delete s[o] : s[o] = a
      }, t._stringRef = o, t)
    }
    if (typeof e != "string") throw Error(E(284));
    if (!n._owner) throw Error(E(290, e))
  }
  return e
}

function Vi(e, t) { throw e = Object.prototype.toString.call(t), Error(E(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)) }

function _u(e) { var t = e._init; return t(e._payload) }

function Sd(e) {
  function t(y, f) {
    if (e) {
      var x = y.deletions;
      x === null ? (y.deletions = [f], y.flags |= 16) : x.push(f)
    }
  }

  function n(y, f) { if (!e) return null; for (; f !== null;) t(y, f), f = f.sibling; return null }

  function r(y, f) { for (y = new Map; f !== null;) f.key !== null ? y.set(f.key, f) : y.set(f.index, f), f = f.sibling; return y }

  function i(y, f) { return y = Pn(y, f), y.index = 0, y.sibling = null, y }

  function o(y, f, x) { return y.index = x, e ? (x = y.alternate, x !== null ? (x = x.index, x < f ? (y.flags |= 2, f) : x) : (y.flags |= 2, f)) : (y.flags |= 1048576, f) }

  function a(y) { return e && y.alternate === null && (y.flags |= 2), y }

  function s(y, f, x, w) { return f === null || f.tag !== 6 ? (f = Eo(x, y.mode, w), f.return = y, f) : (f = i(f, x), f.return = y, f) }

  function u(y, f, x, w) { var S = x.type; return S === ar ? p(y, f, x.props.children, w, x.key) : f !== null && (f.elementType === S || typeof S == "object" && S !== null && S.$$typeof === dn && _u(S) === f.type) ? (w = i(f, x.props), w.ref = Ar(y, f, x), w.return = y, w) : (w = sl(x.type, x.key, x.props, null, y.mode, w), w.ref = Ar(y, f, x), w.return = y, w) }

  function d(y, f, x, w) { return f === null || f.tag !== 4 || f.stateNode.containerInfo !== x.containerInfo || f.stateNode.implementation !== x.implementation ? (f = To(x, y.mode, w), f.return = y, f) : (f = i(f, x.children || []), f.return = y, f) }

  function p(y, f, x, w, S) { return f === null || f.tag !== 7 ? (f = Wn(x, y.mode, w, S), f.return = y, f) : (f = i(f, x), f.return = y, f) }

  function v(y, f, x) {
    if (typeof f == "string" && f !== "" || typeof f == "number") return f = Eo("" + f, y.mode, x), f.return = y, f;
    if (typeof f == "object" && f !== null) {
      switch (f.$$typeof) {
        case Oi:
          return x = sl(f.type, f.key, f.props, null, y.mode, x), x.ref = Ar(y, null, f), x.return = y, x;
        case or:
          return f = To(f, y.mode, x), f.return = y, f;
        case dn:
          var w = f._init;
          return v(y, w(f._payload), x)
      }
      if (Wr(f) || _r(f)) return f = Wn(f, y.mode, x, null), f.return = y, f;
      Vi(y, f)
    }
    return null
  }

  function g(y, f, x, w) {
    var S = f !== null ? f.key : null;
    if (typeof x == "string" && x !== "" || typeof x == "number") return S !== null ? null : s(y, f, "" + x, w);
    if (typeof x == "object" && x !== null) {
      switch (x.$$typeof) {
        case Oi:
          return x.key === S ? u(y, f, x, w) : null;
        case or:
          return x.key === S ? d(y, f, x, w) : null;
        case dn:
          return S = x._init, g(y, f, S(x._payload), w)
      }
      if (Wr(x) || _r(x)) return S !== null ? null : p(y, f, x, w, null);
      Vi(y, x)
    }
    return null
  }

  function k(y, f, x, w, S) {
    if (typeof w == "string" && w !== "" || typeof w == "number") return y = y.get(x) || null, s(f, y, "" + w, S);
    if (typeof w == "object" && w !== null) {
      switch (w.$$typeof) {
        case Oi:
          return y = y.get(w.key === null ? x : w.key) || null, u(f, y, w, S);
        case or:
          return y = y.get(w.key === null ? x : w.key) || null, d(f, y, w, S);
        case dn:
          var I = w._init;
          return k(y, f, x, I(w._payload), S)
      }
      if (Wr(w) || _r(w)) return y = y.get(x) || null, p(f, y, w, S, null);
      Vi(f, w)
    }
    return null
  }

  function C(y, f, x, w) { for (var S = null, I = null, M = f, L = f = 0, B = null; M !== null && L < x.length; L++) { M.index > L ? (B = M, M = null) : B = M.sibling; var R = g(y, M, x[L], w); if (R === null) { M === null && (M = B); break } e && M && R.alternate === null && t(y, M), f = o(R, f, L), I === null ? S = R : I.sibling = R, I = R, M = B } if (L === x.length) return n(y, M), be && On(y, L), S; if (M === null) { for (; L < x.length; L++) M = v(y, x[L], w), M !== null && (f = o(M, f, L), I === null ? S = M : I.sibling = M, I = M); return be && On(y, L), S } for (M = r(y, M); L < x.length; L++) B = k(M, y, L, x[L], w), B !== null && (e && B.alternate !== null && M.delete(B.key === null ? L : B.key), f = o(B, f, L), I === null ? S = B : I.sibling = B, I = B); return e && M.forEach(function(_) { return t(y, _) }), be && On(y, L), S }

  function b(y, f, x, w) { var S = _r(x); if (typeof S != "function") throw Error(E(150)); if (x = S.call(x), x == null) throw Error(E(151)); for (var I = S = null, M = f, L = f = 0, B = null, R = x.next(); M !== null && !R.done; L++, R = x.next()) { M.index > L ? (B = M, M = null) : B = M.sibling; var _ = g(y, M, R.value, w); if (_ === null) { M === null && (M = B); break } e && M && _.alternate === null && t(y, M), f = o(_, f, L), I === null ? S = _ : I.sibling = _, I = _, M = B } if (R.done) return n(y, M), be && On(y, L), S; if (M === null) { for (; !R.done; L++, R = x.next()) R = v(y, R.value, w), R !== null && (f = o(R, f, L), I === null ? S = R : I.sibling = R, I = R); return be && On(y, L), S } for (M = r(y, M); !R.done; L++, R = x.next()) R = k(M, y, L, R.value, w), R !== null && (e && R.alternate !== null && M.delete(R.key === null ? L : R.key), f = o(R, f, L), I === null ? S = R : I.sibling = R, I = R); return e && M.forEach(function(q) { return t(y, q) }), be && On(y, L), S }

  function N(y, f, x, w) {
    if (typeof x == "object" && x !== null && x.type === ar && x.key === null && (x = x.props.children), typeof x == "object" && x !== null) {
      switch (x.$$typeof) {
        case Oi:
          e: {
            for (var S = x.key, I = f; I !== null;) {
              if (I.key === S) { if (S = x.type, S === ar) { if (I.tag === 7) { n(y, I.sibling), f = i(I, x.props.children), f.return = y, y = f; break e } } else if (I.elementType === S || typeof S == "object" && S !== null && S.$$typeof === dn && _u(S) === I.type) { n(y, I.sibling), f = i(I, x.props), f.ref = Ar(y, I, x), f.return = y, y = f; break e } n(y, I); break } else t(y, I);
              I = I.sibling
            }
            x.type === ar ? (f = Wn(x.props.children, y.mode, w, x.key), f.return = y, y = f) : (w = sl(x.type, x.key, x.props, null, y.mode, w), w.ref = Ar(y, f, x), w.return = y, y = w)
          }
          return a(y);
        case or:
          e: {
            for (I = x.key; f !== null;) {
              if (f.key === I)
                if (f.tag === 4 && f.stateNode.containerInfo === x.containerInfo && f.stateNode.implementation === x.implementation) { n(y, f.sibling), f = i(f, x.children || []), f.return = y, y = f; break e } else { n(y, f); break }
              else t(y, f);
              f = f.sibling
            }
            f = To(x, y.mode, w),
            f.return = y,
            y = f
          }
          return a(y);
        case dn:
          return I = x._init, N(y, f, I(x._payload), w)
      }
      if (Wr(x)) return C(y, f, x, w);
      if (_r(x)) return b(y, f, x, w);
      Vi(y, x)
    }
    return typeof x == "string" && x !== "" || typeof x == "number" ? (x = "" + x, f !== null && f.tag === 6 ? (n(y, f.sibling), f = i(f, x), f.return = y, y = f) : (n(y, f), f = Eo(x, y.mode, w), f.return = y, y = f), a(y)) : n(y, f)
  }
  return N
}
var Mr = Sd(!0),
  Pd = Sd(!1),
  Li = {},
  Yt = Tn(Li),
  gi = Tn(Li),
  vi = Tn(Li);

function Hn(e) { if (e === Li) throw Error(E(174)); return e }

function Ns(e, t) {
  switch (he(vi, t), he(gi, e), he(Yt, Li), e = t.nodeType, e) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : Ko(null, "");
      break;
    default:
      e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = Ko(t, e)
  }
  xe(Yt), he(Yt, t)
}

function Lr() { xe(Yt), xe(gi), xe(vi) }

function Md(e) {
  Hn(vi.current);
  var t = Hn(Yt.current),
    n = Ko(t, e.type);
  t !== n && (he(gi, e), he(Yt, n))
}

function Is(e) { gi.current === e && (xe(Yt), xe(gi)) }
var we = Tn(0);

function Ml(e) {
  for (var t = e; t !== null;) {
    if (t.tag === 13) { var n = t.memoizedState; if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) { if (t.flags & 128) return t } else if (t.child !== null) { t.child.return = t, t = t.child; continue }
    if (t === e) break;
    for (; t.sibling === null;) {
      if (t.return === null || t.return === e) return null;
      t = t.return
    }
    t.sibling.return = t.return, t = t.sibling
  }
  return null
}
var So = [];

function Ss() {
  for (var e = 0; e < So.length; e++) So[e]._workInProgressVersionPrimary = null;
  So.length = 0
}
var rl = sn.ReactCurrentDispatcher,
  Po = sn.ReactCurrentBatchConfig,
  Kn = 0,
  Ne = null,
  Te = null,
  De = null,
  Ll = !1,
  ti = !1,
  yi = 0,
  Oh = 0;

function Ve() { throw Error(E(321)) }

function Ps(e, t) {
  if (t === null) return !1;
  for (var n = 0; n < t.length && n < e.length; n++)
    if (!jt(e[n], t[n])) return !1;
  return !0
}

function Ms(e, t, n, r, i, o) {
  if (Kn = o, Ne = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, rl.current = e === null || e.memoizedState === null ? jh : $h, e = n(r, i), ti) {
    o = 0;
    do {
      if (ti = !1, yi = 0, 25 <= o) throw Error(E(301));
      o += 1, De = Te = null, t.updateQueue = null, rl.current = Ah, e = n(r, i)
    } while (ti)
  }
  if (rl.current = Bl, t = Te !== null && Te.next !== null, Kn = 0, De = Te = Ne = null, Ll = !1, t) throw Error(E(300));
  return e
}

function Ls() { var e = yi !== 0; return yi = 0, e }

function Ut() { var e = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null }; return De === null ? Ne.memoizedState = De = e : De = De.next = e, De }

function Pt() {
  if (Te === null) {
    var e = Ne.alternate;
    e = e !== null ? e.memoizedState : null
  } else e = Te.next;
  var t = De === null ? Ne.memoizedState : De.next;
  if (t !== null) De = t, Te = e;
  else {
    if (e === null) throw Error(E(310));
    Te = e, e = { memoizedState: Te.memoizedState, baseState: Te.baseState, baseQueue: Te.baseQueue, queue: Te.queue, next: null }, De === null ? Ne.memoizedState = De = e : De = De.next = e
  }
  return De
}

function xi(e, t) { return typeof t == "function" ? t(e) : t }

function Mo(e) {
  var t = Pt(),
    n = t.queue;
  if (n === null) throw Error(E(311));
  n.lastRenderedReducer = e;
  var r = Te,
    i = r.baseQueue,
    o = n.pending;
  if (o !== null) {
    if (i !== null) {
      var a = i.next;
      i.next = o.next, o.next = a
    }
    r.baseQueue = i = o, n.pending = null
  }
  if (i !== null) {
    o = i.next, r = r.baseState;
    var s = a = null,
      u = null,
      d = o;
    do {
      var p = d.lane;
      if ((Kn & p) === p) u !== null && (u = u.next = { lane: 0, action: d.action, hasEagerState: d.hasEagerState, eagerState: d.eagerState, next: null }), r = d.hasEagerState ? d.eagerState : e(r, d.action);
      else {
        var v = { lane: p, action: d.action, hasEagerState: d.hasEagerState, eagerState: d.eagerState, next: null };
        u === null ? (s = u = v, a = r) : u = u.next = v, Ne.lanes |= p, Zn |= p
      }
      d = d.next
    } while (d !== null && d !== o);
    u === null ? a = r : u.next = s, jt(r, t.memoizedState) || (lt = !0), t.memoizedState = r, t.baseState = a, t.baseQueue = u, n.lastRenderedState = r
  }
  if (e = n.interleaved, e !== null) {
    i = e;
    do o = i.lane, Ne.lanes |= o, Zn |= o, i = i.next; while (i !== e)
  } else i === null && (n.lanes = 0);
  return [t.memoizedState, n.dispatch]
}

function Lo(e) {
  var t = Pt(),
    n = t.queue;
  if (n === null) throw Error(E(311));
  n.lastRenderedReducer = e;
  var r = n.dispatch,
    i = n.pending,
    o = t.memoizedState;
  if (i !== null) {
    n.pending = null;
    var a = i = i.next;
    do o = e(o, a.action), a = a.next; while (a !== i);
    jt(o, t.memoizedState) || (lt = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
  }
  return [o, r]
}

function Ld() {}

function Bd(e, t) {
  var n = Ne,
    r = Pt(),
    i = t(),
    o = !jt(r.memoizedState, i);
  if (o && (r.memoizedState = i, lt = !0), r = r.queue, Bs(Td.bind(null, n, r, e), [e]), r.getSnapshot !== t || o || De !== null && De.memoizedState.tag & 1) {
    if (n.flags |= 2048, ki(9, Ed.bind(null, n, r, i, t), void 0, null), Fe === null) throw Error(E(349));
    Kn & 30 || Rd(n, t, i)
  }
  return i
}

function Rd(e, t, n) { e.flags |= 16384, e = { getSnapshot: t, value: n }, t = Ne.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, Ne.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e)) }

function Ed(e, t, n, r) { t.value = n, t.getSnapshot = r, zd(t) && Od(e) }

function Td(e, t, n) { return n(function() { zd(t) && Od(e) }) }

function zd(e) {
  var t = e.getSnapshot;
  e = e.value;
  try { var n = t(); return !jt(e, n) } catch { return !0 }
}

function Od(e) {
  var t = on(e, 1);
  t !== null && Ft(t, e, 1, -1)
}

function Du(e) { var t = Ut(); return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: xi, lastRenderedState: e }, t.queue = e, e = e.dispatch = Fh.bind(null, Ne, e), [t.memoizedState, e] }

function ki(e, t, n, r) { return e = { tag: e, create: t, destroy: n, deps: r, next: null }, t = Ne.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, Ne.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e }

function _d() { return Pt().memoizedState }

function il(e, t, n, r) {
  var i = Ut();
  Ne.flags |= e, i.memoizedState = ki(1 | t, n, void 0, r === void 0 ? null : r)
}

function Wl(e, t, n, r) {
  var i = Pt();
  r = r === void 0 ? null : r;
  var o = void 0;
  if (Te !== null) { var a = Te.memoizedState; if (o = a.destroy, r !== null && Ps(r, a.deps)) { i.memoizedState = ki(t, n, o, r); return } } Ne.flags |= e, i.memoizedState = ki(1 | t, n, o, r)
}

function Fu(e, t) { return il(8390656, 8, e, t) }

function Bs(e, t) { return Wl(2048, 8, e, t) }

function Dd(e, t) { return Wl(4, 2, e, t) }

function Fd(e, t) { return Wl(4, 4, e, t) }

function jd(e, t) {
  if (typeof t == "function") return e = e(), t(e),
    function() { t(null) };
  if (t != null) return e = e(), t.current = e,
    function() { t.current = null }
}

function $d(e, t, n) { return n = n != null ? n.concat([e]) : null, Wl(4, 4, jd.bind(null, t, e), n) }

function Rs() {}

function Ad(e, t) {
  var n = Pt();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && Ps(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function Hd(e, t) {
  var n = Pt();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && Ps(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function qd(e, t, n) { return Kn & 21 ? (jt(n, t) || (n = Vc(), Ne.lanes |= n, Zn |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, lt = !0), e.memoizedState = n) }

function _h(e, t) {
  var n = me;
  me = n !== 0 && 4 > n ? n : 4, e(!0);
  var r = Po.transition;
  Po.transition = {};
  try { e(!1), t() } finally { me = n, Po.transition = r }
}

function Ud() { return Pt().memoizedState }

function Dh(e, t, n) {
  var r = Sn(e);
  if (n = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null }, Wd(e)) Vd(t, n);
  else if (n = Cd(e, t, n, r), n !== null) {
    var i = et();
    Ft(n, e, r, i), Qd(n, t, r)
  }
}

function Fh(e, t, n) {
  var r = Sn(e),
    i = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (Wd(e)) Vd(t, i);
  else {
    var o = e.alternate;
    if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer, o !== null)) try {
      var a = t.lastRenderedState,
        s = o(a, n);
      if (i.hasEagerState = !0, i.eagerState = s, jt(s, a)) {
        var u = t.interleaved;
        u === null ? (i.next = i, Cs(t)) : (i.next = u.next, u.next = i), t.interleaved = i;
        return
      }
    } catch {} finally {} n = Cd(e, t, i, r), n !== null && (i = et(), Ft(n, e, r, i), Qd(n, t, r))
  }
}

function Wd(e) { var t = e.alternate; return e === Ne || t !== null && t === Ne }

function Vd(e, t) {
  ti = Ll = !0;
  var n = e.pending;
  n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function Qd(e, t, n) {
  if (n & 4194240) {
    var r = t.lanes;
    r &= e.pendingLanes, n |= r, t.lanes = n, ss(e, n)
  }
}
var Bl = { readContext: St, useCallback: Ve, useContext: Ve, useEffect: Ve, useImperativeHandle: Ve, useInsertionEffect: Ve, useLayoutEffect: Ve, useMemo: Ve, useReducer: Ve, useRef: Ve, useState: Ve, useDebugValue: Ve, useDeferredValue: Ve, useTransition: Ve, useMutableSource: Ve, useSyncExternalStore: Ve, useId: Ve, unstable_isNewReconciler: !1 },
  jh = {
    readContext: St,
    useCallback: function(e, t) { return Ut().memoizedState = [e, t === void 0 ? null : t], e },
    useContext: St,
    useEffect: Fu,
    useImperativeHandle: function(e, t, n) { return n = n != null ? n.concat([e]) : null, il(4194308, 4, jd.bind(null, t, e), n) },
    useLayoutEffect: function(e, t) { return il(4194308, 4, e, t) },
    useInsertionEffect: function(e, t) { return il(4, 2, e, t) },
    useMemo: function(e, t) { var n = Ut(); return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e },
    useReducer: function(e, t, n) { var r = Ut(); return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: e, lastRenderedState: t }, r.queue = e, e = e.dispatch = Dh.bind(null, Ne, e), [r.memoizedState, e] },
    useRef: function(e) { var t = Ut(); return e = { current: e }, t.memoizedState = e },
    useState: Du,
    useDebugValue: Rs,
    useDeferredValue: function(e) { return Ut().memoizedState = e },
    useTransition: function() {
      var e = Du(!1),
        t = e[0];
      return e = _h.bind(null, e[1]), Ut().memoizedState = e, [t, e]
    },
    useMutableSource: function() {},
    useSyncExternalStore: function(e, t, n) {
      var r = Ne,
        i = Ut();
      if (be) {
        if (n === void 0) throw Error(E(407));
        n = n()
      } else {
        if (n = t(), Fe === null) throw Error(E(349));
        Kn & 30 || Rd(r, t, n)
      }
      i.memoizedState = n;
      var o = { value: n, getSnapshot: t };
      return i.queue = o, Fu(Td.bind(null, r, o, e), [e]), r.flags |= 2048, ki(9, Ed.bind(null, r, o, n, t), void 0, null), n
    },
    useId: function() {
      var e = Ut(),
        t = Fe.identifierPrefix;
      if (be) {
        var n = en,
          r = Xt;
        n = (r & ~(1 << 32 - Dt(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = yi++, 0 < n && (t += "H" + n.toString(32)), t += ":"
      } else n = Oh++, t = ":" + t + "r" + n.toString(32) + ":";
      return e.memoizedState = t
    },
    unstable_isNewReconciler: !1
  },
  $h = {
    readContext: St,
    useCallback: Ad,
    useContext: St,
    useEffect: Bs,
    useImperativeHandle: $d,
    useInsertionEffect: Dd,
    useLayoutEffect: Fd,
    useMemo: Hd,
    useReducer: Mo,
    useRef: _d,
    useState: function() { return Mo(xi) },
    useDebugValue: Rs,
    useDeferredValue: function(e) { var t = Pt(); return qd(t, Te.memoizedState, e) },
    useTransition: function() {
      var e = Mo(xi)[0],
        t = Pt().memoizedState;
      return [e, t]
    },
    useMutableSource: Ld,
    useSyncExternalStore: Bd,
    useId: Ud,
    unstable_isNewReconciler: !1
  },
  Ah = {
    readContext: St,
    useCallback: Ad,
    useContext: St,
    useEffect: Bs,
    useImperativeHandle: $d,
    useInsertionEffect: Dd,
    useLayoutEffect: Fd,
    useMemo: Hd,
    useReducer: Lo,
    useRef: _d,
    useState: function() { return Lo(xi) },
    useDebugValue: Rs,
    useDeferredValue: function(e) { var t = Pt(); return Te === null ? t.memoizedState = e : qd(t, Te.memoizedState, e) },
    useTransition: function() {
      var e = Lo(xi)[0],
        t = Pt().memoizedState;
      return [e, t]
    },
    useMutableSource: Ld,
    useSyncExternalStore: Bd,
    useId: Ud,
    unstable_isNewReconciler: !1
  };

function Br(e, t) {
  try {
    var n = "",
      r = t;
    do n += hp(r), r = r.return; while (r);
    var i = n
  } catch (o) { i = `
Error generating stack: ` + o.message + `
` + o.stack }
  return { value: e, source: t, stack: i, digest: null }
}

function Bo(e, t, n) { return { value: e, source: null, stack: n ?? null, digest: t ?? null } }

function ya(e, t) { try { console.error(t.value) } catch (n) { setTimeout(function() { throw n }) } }
var Hh = typeof WeakMap == "function" ? WeakMap : Map;

function Yd(e, t, n) { n = nn(-1, n), n.tag = 3, n.payload = { element: null }; var r = t.value; return n.callback = function() { El || (El = !0, Ma = r), ya(e, t) }, n }

function Kd(e, t, n) {
  n = nn(-1, n), n.tag = 3;
  var r = e.type.getDerivedStateFromError;
  if (typeof r == "function") {
    var i = t.value;
    n.payload = function() { return r(i) }, n.callback = function() { ya(e, t) }
  }
  var o = e.stateNode;
  return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
    ya(e, t), typeof r != "function" && (In === null ? In = new Set([this]) : In.add(this));
    var a = t.stack;
    this.componentDidCatch(t.value, { componentStack: a !== null ? a : "" })
  }), n
}

function ju(e, t, n) {
  var r = e.pingCache;
  if (r === null) {
    r = e.pingCache = new Hh;
    var i = new Set;
    r.set(t, i)
  } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
  i.has(n) || (i.add(n), e = ng.bind(null, e, t, n), t.then(e, e))
}

function $u(e) {
  do {
    var t;
    if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
    e = e.return
  } while (e !== null);
  return null
}

function Au(e, t, n, r, i) { return e.mode & 1 ? (e.flags |= 65536, e.lanes = i, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = nn(-1, 1), t.tag = 2, Nn(n, t, 1))), n.lanes |= 1), e) }
var qh = sn.ReactCurrentOwner,
  lt = !1;

function Xe(e, t, n, r) { t.child = e === null ? Pd(t, null, n, r) : Mr(t, e.child, n, r) }

function Hu(e, t, n, r, i) { n = n.render; var o = t.ref; return wr(t, i), r = Ms(e, t, n, r, o, i), n = Ls(), e !== null && !lt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, an(e, t, i)) : (be && n && gs(t), t.flags |= 1, Xe(e, t, r, i), t.child) }

function qu(e, t, n, r, i) { if (e === null) { var o = n.type; return typeof o == "function" && !js(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = o, Zd(e, t, o, r, i)) : (e = sl(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e) } if (o = e.child, !(e.lanes & i)) { var a = o.memoizedProps; if (n = n.compare, n = n !== null ? n : mi, n(a, r) && e.ref === t.ref) return an(e, t, i) } return t.flags |= 1, e = Pn(o, r), e.ref = t.ref, e.return = t, t.child = e }

function Zd(e, t, n, r, i) {
  if (e !== null) {
    var o = e.memoizedProps;
    if (mi(o, r) && e.ref === t.ref)
      if (lt = !1, t.pendingProps = r = o, (e.lanes & i) !== 0) e.flags & 131072 && (lt = !0);
      else return t.lanes = e.lanes, an(e, t, i)
  }
  return xa(e, t, n, r, i)
}

function Gd(e, t, n) {
  var r = t.pendingProps,
    i = r.children,
    o = e !== null ? e.memoizedState : null;
  if (r.mode === "hidden")
    if (!(t.mode & 1)) t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, he(vr, mt), mt |= n;
    else {
      if (!(n & 1073741824)) return e = o !== null ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = { baseLanes: e, cachePool: null, transitions: null }, t.updateQueue = null, he(vr, mt), mt |= e, null;
      t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, r = o !== null ? o.baseLanes : n, he(vr, mt), mt |= r
    }
  else o !== null ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, he(vr, mt), mt |= r;
  return Xe(e, t, i, n), t.child
}

function Jd(e, t) {
  var n = t.ref;
  (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function xa(e, t, n, r, i) { var o = at(n) ? Qn : Ke.current; return o = Sr(t, o), wr(t, i), n = Ms(e, t, n, r, o, i), r = Ls(), e !== null && !lt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, an(e, t, i)) : (be && r && gs(t), t.flags |= 1, Xe(e, t, n, i), t.child) }

function Uu(e, t, n, r, i) {
  if (at(n)) {
    var o = !0;
    Cl(t)
  } else o = !1;
  if (wr(t, i), t.stateNode === null) ll(e, t), Id(t, n, r), va(t, n, r, i), r = !0;
  else if (e === null) {
    var a = t.stateNode,
      s = t.memoizedProps;
    a.props = s;
    var u = a.context,
      d = n.contextType;
    typeof d == "object" && d !== null ? d = St(d) : (d = at(n) ? Qn : Ke.current, d = Sr(t, d));
    var p = n.getDerivedStateFromProps,
      v = typeof p == "function" || typeof a.getSnapshotBeforeUpdate == "function";
    v || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (s !== r || u !== d) && Ou(t, a, r, d), mn = !1;
    var g = t.memoizedState;
    a.state = g, Pl(t, r, a, i), u = t.memoizedState, s !== r || g !== u || ot.current || mn ? (typeof p == "function" && (ga(t, n, p, r), u = t.memoizedState), (s = mn || zu(t, n, s, r, g, u, d)) ? (v || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = u), a.props = r, a.state = u, a.context = d, r = s) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
  } else {
    a = t.stateNode, wd(e, t), s = t.memoizedProps, d = t.type === t.elementType ? s : Tt(t.type, s), a.props = d, v = t.pendingProps, g = a.context, u = n.contextType, typeof u == "object" && u !== null ? u = St(u) : (u = at(n) ? Qn : Ke.current, u = Sr(t, u));
    var k = n.getDerivedStateFromProps;
    (p = typeof k == "function" || typeof a.getSnapshotBeforeUpdate == "function") || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (s !== v || g !== u) && Ou(t, a, r, u), mn = !1, g = t.memoizedState, a.state = g, Pl(t, r, a, i);
    var C = t.memoizedState;
    s !== v || g !== C || ot.current || mn ? (typeof k == "function" && (ga(t, n, k, r), C = t.memoizedState), (d = mn || zu(t, n, d, r, g, C, u) || !1) ? (p || typeof a.UNSAFE_componentWillUpdate != "function" && typeof a.componentWillUpdate != "function" || (typeof a.componentWillUpdate == "function" && a.componentWillUpdate(r, C, u), typeof a.UNSAFE_componentWillUpdate == "function" && a.UNSAFE_componentWillUpdate(r, C, u)), typeof a.componentDidUpdate == "function" && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof a.componentDidUpdate != "function" || s === e.memoizedProps && g === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || s === e.memoizedProps && g === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = C), a.props = r, a.state = C, a.context = u, r = d) : (typeof a.componentDidUpdate != "function" || s === e.memoizedProps && g === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || s === e.memoizedProps && g === e.memoizedState || (t.flags |= 1024), r = !1)
  }
  return ka(e, t, n, r, o, i)
}

function ka(e, t, n, r, i, o) {
  Jd(e, t);
  var a = (t.flags & 128) !== 0;
  if (!r && !a) return i && Lu(t, n, !1), an(e, t, o);
  r = t.stateNode, qh.current = t;
  var s = a && typeof n.getDerivedStateFromError != "function" ? null : r.render();
  return t.flags |= 1, e !== null && a ? (t.child = Mr(t, e.child, null, o), t.child = Mr(t, null, s, o)) : Xe(e, t, s, o), t.memoizedState = r.state, i && Lu(t, n, !0), t.child
}

function Xd(e) {
  var t = e.stateNode;
  t.pendingContext ? Mu(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Mu(e, t.context, !1), Ns(e, t.containerInfo)
}

function Wu(e, t, n, r, i) { return Pr(), ys(i), t.flags |= 256, Xe(e, t, n, r), t.child }
var ba = { dehydrated: null, treeContext: null, retryLane: 0 };

function Ca(e) { return { baseLanes: e, cachePool: null, transitions: null } }

function em(e, t, n) {
  var r = t.pendingProps,
    i = we.current,
    o = !1,
    a = (t.flags & 128) !== 0,
    s;
  if ((s = a) || (s = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0), s ? (o = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (i |= 1), he(we, i & 1), e === null) return pa(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (a = r.children, e = r.fallback, o ? (r = t.mode, o = t.child, a = { mode: "hidden", children: a }, !(r & 1) && o !== null ? (o.childLanes = 0, o.pendingProps = a) : o = Yl(a, r, 0, null), e = Wn(e, r, n, null), o.return = t, e.return = t, o.sibling = e, t.child = o, t.child.memoizedState = Ca(n), t.memoizedState = ba, e) : Es(t, a));
  if (i = e.memoizedState, i !== null && (s = i.dehydrated, s !== null)) return Uh(e, t, a, r, s, i, n);
  if (o) { o = r.fallback, a = t.mode, i = e.child, s = i.sibling; var u = { mode: "hidden", children: r.children }; return !(a & 1) && t.child !== i ? (r = t.child, r.childLanes = 0, r.pendingProps = u, t.deletions = null) : (r = Pn(i, u), r.subtreeFlags = i.subtreeFlags & 14680064), s !== null ? o = Pn(s, o) : (o = Wn(o, a, n, null), o.flags |= 2), o.return = t, r.return = t, r.sibling = o, t.child = r, r = o, o = t.child, a = e.child.memoizedState, a = a === null ? Ca(n) : { baseLanes: a.baseLanes | n, cachePool: null, transitions: a.transitions }, o.memoizedState = a, o.childLanes = e.childLanes & ~n, t.memoizedState = ba, r }
  return o = e.child, e = o.sibling, r = Pn(o, { mode: "visible", children: r.children }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function Es(e, t) { return t = Yl({ mode: "visible", children: t }, e.mode, 0, null), t.return = e, e.child = t }

function Qi(e, t, n, r) { return r !== null && ys(r), Mr(t, e.child, null, n), e = Es(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e }

function Uh(e, t, n, r, i, o, a) {
  if (n) return t.flags & 256 ? (t.flags &= -257, r = Bo(Error(E(422))), Qi(e, t, a, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, i = t.mode, r = Yl({ mode: "visible", children: r.children }, i, 0, null), o = Wn(o, i, a, null), o.flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, t.mode & 1 && Mr(t, e.child, null, a), t.child.memoizedState = Ca(a), t.memoizedState = ba, o);
  if (!(t.mode & 1)) return Qi(e, t, a, null);
  if (i.data === "$!") { if (r = i.nextSibling && i.nextSibling.dataset, r) var s = r.dgst; return r = s, o = Error(E(419)), r = Bo(o, r, void 0), Qi(e, t, a, r) }
  if (s = (a & e.childLanes) !== 0, lt || s) {
    if (r = Fe, r !== null) {
      switch (a & -a) {
        case 4:
          i = 2;
          break;
        case 16:
          i = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          i = 32;
          break;
        case 536870912:
          i = 268435456;
          break;
        default:
          i = 0
      }
      i = i & (r.suspendedLanes | a) ? 0 : i, i !== 0 && i !== o.retryLane && (o.retryLane = i, on(e, i), Ft(r, e, i, -1))
    }
    return Fs(), r = Bo(Error(E(421))), Qi(e, t, a, r)
  }
  return i.data === "$?" ? (t.flags |= 128, t.child = e.child, t = rg.bind(null, e), i._reactRetry = t, null) : (e = o.treeContext, ft = wn(i.nextSibling), pt = t, be = !0, _t = null, e !== null && (Ct[wt++] = Xt, Ct[wt++] = en, Ct[wt++] = Yn, Xt = e.id, en = e.overflow, Yn = t), t = Es(t, r.children), t.flags |= 4096, t)
}

function Vu(e, t, n) {
  e.lanes |= t;
  var r = e.alternate;
  r !== null && (r.lanes |= t), ha(e.return, t, n)
}

function Ro(e, t, n, r, i) {
  var o = e.memoizedState;
  o === null ? e.memoizedState = { isBackwards: t, rendering: null, renderingStartTime: 0, last: r, tail: n, tailMode: i } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i)
}

function tm(e, t, n) {
  var r = t.pendingProps,
    i = r.revealOrder,
    o = r.tail;
  if (Xe(e, t, r.children, n), r = we.current, r & 2) r = r & 1 | 2, t.flags |= 128;
  else {
    if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
      if (e.tag === 13) e.memoizedState !== null && Vu(e, n, t);
      else if (e.tag === 19) Vu(e, n, t);
      else if (e.child !== null) { e.child.return = e, e = e.child; continue }
      if (e === t) break e;
      for (; e.sibling === null;) {
        if (e.return === null || e.return === t) break e;
        e = e.return
      }
      e.sibling.return = e.return, e = e.sibling
    }
    r &= 1
  }
  if (he(we, r), !(t.mode & 1)) t.memoizedState = null;
  else switch (i) {
    case "forwards":
      for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && Ml(e) === null && (i = n), n = n.sibling;
      n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), Ro(t, !1, i, n, o);
      break;
    case "backwards":
      for (n = null, i = t.child, t.child = null; i !== null;) { if (e = i.alternate, e !== null && Ml(e) === null) { t.child = i; break } e = i.sibling, i.sibling = n, n = i, i = e } Ro(t, !0, n, null, o);
      break;
    case "together":
      Ro(t, !1, null, null, void 0);
      break;
    default:
      t.memoizedState = null
  }
  return t.child
}

function ll(e, t) {!(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2) }

function an(e, t, n) {
  if (e !== null && (t.dependencies = e.dependencies), Zn |= t.lanes, !(n & t.childLanes)) return null;
  if (e !== null && t.child !== e.child) throw Error(E(153));
  if (t.child !== null) {
    for (e = t.child, n = Pn(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = Pn(e, e.pendingProps), n.return = t;
    n.sibling = null
  }
  return t.child
}

function Wh(e, t, n) {
  switch (t.tag) {
    case 3:
      Xd(t), Pr();
      break;
    case 5:
      Md(t);
      break;
    case 1:
      at(t.type) && Cl(t);
      break;
    case 4:
      Ns(t, t.stateNode.containerInfo);
      break;
    case 10:
      var r = t.type._context,
        i = t.memoizedProps.value;
      he(Il, r._currentValue), r._currentValue = i;
      break;
    case 13:
      if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (he(we, we.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? em(e, t, n) : (he(we, we.current & 1), e = an(e, t, n), e !== null ? e.sibling : null);
      he(we, we.current & 1);
      break;
    case 19:
      if (r = (n & t.childLanes) !== 0, e.flags & 128) {
        if (r) return tm(e, t, n);
        t.flags |= 128
      }
      if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), he(we, we.current), r) break;
      return null;
    case 22:
    case 23:
      return t.lanes = 0, Gd(e, t, n)
  }
  return an(e, t, n)
}
var nm, wa, rm, im;
nm = function(e, t) {
  for (var n = t.child; n !== null;) {
    if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) { n.child.return = n, n = n.child; continue }
    if (n === t) break;
    for (; n.sibling === null;) {
      if (n.return === null || n.return === t) return;
      n = n.return
    }
    n.sibling.return = n.return, n = n.sibling
  }
};
wa = function() {};
rm = function(e, t, n, r) {
  var i = e.memoizedProps;
  if (i !== r) {
    e = t.stateNode, Hn(Yt.current);
    var o = null;
    switch (n) {
      case "input":
        i = Wo(e, i), r = Wo(e, r), o = [];
        break;
      case "select":
        i = Ie({}, i, { value: void 0 }), r = Ie({}, r, { value: void 0 }), o = [];
        break;
      case "textarea":
        i = Yo(e, i), r = Yo(e, r), o = [];
        break;
      default:
        typeof i.onClick != "function" && typeof r.onClick == "function" && (e.onclick = kl)
    }
    Zo(n, r);
    var a;
    n = null;
    for (d in i)
      if (!r.hasOwnProperty(d) && i.hasOwnProperty(d) && i[d] != null)
        if (d === "style") { var s = i[d]; for (a in s) s.hasOwnProperty(a) && (n || (n = {}), n[a] = "") } else d !== "dangerouslySetInnerHTML" && d !== "children" && d !== "suppressContentEditableWarning" && d !== "suppressHydrationWarning" && d !== "autoFocus" && (li.hasOwnProperty(d) ? o || (o = []) : (o = o || []).push(d, null));
    for (d in r) {
      var u = r[d];
      if (s = i != null ? i[d] : void 0, r.hasOwnProperty(d) && u !== s && (u != null || s != null))
        if (d === "style")
          if (s) { for (a in s) !s.hasOwnProperty(a) || u && u.hasOwnProperty(a) || (n || (n = {}), n[a] = ""); for (a in u) u.hasOwnProperty(a) && s[a] !== u[a] && (n || (n = {}), n[a] = u[a]) } else n || (o || (o = []), o.push(d, n)), n = u;
      else d === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, s = s ? s.__html : void 0, u != null && s !== u && (o = o || []).push(d, u)) : d === "children" ? typeof u != "string" && typeof u != "number" || (o = o || []).push(d, "" + u) : d !== "suppressContentEditableWarning" && d !== "suppressHydrationWarning" && (li.hasOwnProperty(d) ? (u != null && d === "onScroll" && ye("scroll", e), o || s === u || (o = [])) : (o = o || []).push(d, u))
    }
    n && (o = o || []).push("style", n);
    var d = o;
    (t.updateQueue = d) && (t.flags |= 4)
  }
};
im = function(e, t, n, r) { n !== r && (t.flags |= 4) };

function Hr(e, t) {
  if (!be) switch (e.tailMode) {
    case "hidden":
      t = e.tail;
      for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
      n === null ? e.tail = null : n.sibling = null;
      break;
    case "collapsed":
      n = e.tail;
      for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
      r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
  }
}

function Qe(e) {
  var t = e.alternate !== null && e.alternate.child === e.child,
    n = 0,
    r = 0;
  if (t)
    for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 14680064, r |= i.flags & 14680064, i.return = e, i = i.sibling;
  else
    for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
  return e.subtreeFlags |= r, e.childLanes = n, t
}

function Vh(e, t, n) {
  var r = t.pendingProps;
  switch (vs(t), t.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return Qe(t), null;
    case 1:
      return at(t.type) && bl(), Qe(t), null;
    case 3:
      return r = t.stateNode, Lr(), xe(ot), xe(Ke), Ss(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (Wi(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, _t !== null && (Ra(_t), _t = null))), wa(e, t), Qe(t), null;
    case 5:
      Is(t);
      var i = Hn(vi.current);
      if (n = t.type, e !== null && t.stateNode != null) rm(e, t, n, r, i), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
      else {
        if (!r) { if (t.stateNode === null) throw Error(E(166)); return Qe(t), null }
        if (e = Hn(Yt.current), Wi(t)) {
          r = t.stateNode, n = t.type;
          var o = t.memoizedProps;
          switch (r[Wt] = t, r[hi] = o, e = (t.mode & 1) !== 0, n) {
            case "dialog":
              ye("cancel", r), ye("close", r);
              break;
            case "iframe":
            case "object":
            case "embed":
              ye("load", r);
              break;
            case "video":
            case "audio":
              for (i = 0; i < Qr.length; i++) ye(Qr[i], r);
              break;
            case "source":
              ye("error", r);
              break;
            case "img":
            case "image":
            case "link":
              ye("error", r), ye("load", r);
              break;
            case "details":
              ye("toggle", r);
              break;
            case "input":
              tu(r, o), ye("invalid", r);
              break;
            case "select":
              r._wrapperState = { wasMultiple: !!o.multiple }, ye("invalid", r);
              break;
            case "textarea":
              ru(r, o), ye("invalid", r)
          }
          Zo(n, o), i = null;
          for (var a in o)
            if (o.hasOwnProperty(a)) {
              var s = o[a];
              a === "children" ? typeof s == "string" ? r.textContent !== s && (o.suppressHydrationWarning !== !0 && Ui(r.textContent, s, e), i = ["children", s]) : typeof s == "number" && r.textContent !== "" + s && (o.suppressHydrationWarning !== !0 && Ui(r.textContent, s, e), i = ["children", "" + s]) : li.hasOwnProperty(a) && s != null && a === "onScroll" && ye("scroll", r)
            } switch (n) {
            case "input":
              _i(r), nu(r, o, !0);
              break;
            case "textarea":
              _i(r), iu(r);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof o.onClick == "function" && (r.onclick = kl)
          }
          r = i, t.updateQueue = r, r !== null && (t.flags |= 4)
        } else {
          a = i.nodeType === 9 ? i : i.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = Rc(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = a.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = a.createElement(n, { is: r.is }) : (e = a.createElement(n), n === "select" && (a = e, r.multiple ? a.multiple = !0 : r.size && (a.size = r.size))) : e = a.createElementNS(e, n), e[Wt] = t, e[hi] = r, nm(e, t, !1, !1), t.stateNode = e;
          e: {
            switch (a = Go(n, r), n) {
              case "dialog":
                ye("cancel", e), ye("close", e), i = r;
                break;
              case "iframe":
              case "object":
              case "embed":
                ye("load", e), i = r;
                break;
              case "video":
              case "audio":
                for (i = 0; i < Qr.length; i++) ye(Qr[i], e);
                i = r;
                break;
              case "source":
                ye("error", e), i = r;
                break;
              case "img":
              case "image":
              case "link":
                ye("error", e), ye("load", e), i = r;
                break;
              case "details":
                ye("toggle", e), i = r;
                break;
              case "input":
                tu(e, r), i = Wo(e, r), ye("invalid", e);
                break;
              case "option":
                i = r;
                break;
              case "select":
                e._wrapperState = { wasMultiple: !!r.multiple }, i = Ie({}, r, { value: void 0 }), ye("invalid", e);
                break;
              case "textarea":
                ru(e, r), i = Yo(e, r), ye("invalid", e);
                break;
              default:
                i = r
            }
            Zo(n, i),
            s = i;
            for (o in s)
              if (s.hasOwnProperty(o)) {
                var u = s[o];
                o === "style" ? zc(e, u) : o === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, u != null && Ec(e, u)) : o === "children" ? typeof u == "string" ? (n !== "textarea" || u !== "") && oi(e, u) : typeof u == "number" && oi(e, "" + u) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (li.hasOwnProperty(o) ? u != null && o === "onScroll" && ye("scroll", e) : u != null && ns(e, o, u, a))
              } switch (n) {
              case "input":
                _i(e), nu(e, r, !1);
                break;
              case "textarea":
                _i(e), iu(e);
                break;
              case "option":
                r.value != null && e.setAttribute("value", "" + Bn(r.value));
                break;
              case "select":
                e.multiple = !!r.multiple, o = r.value, o != null ? xr(e, !!r.multiple, o, !1) : r.defaultValue != null && xr(e, !!r.multiple, r.defaultValue, !0);
                break;
              default:
                typeof i.onClick == "function" && (e.onclick = kl)
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                r = !!r.autoFocus;
                break e;
              case "img":
                r = !0;
                break e;
              default:
                r = !1
            }
          }
          r && (t.flags |= 4)
        }
        t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
      }
      return Qe(t), null;
    case 6:
      if (e && t.stateNode != null) im(e, t, e.memoizedProps, r);
      else {
        if (typeof r != "string" && t.stateNode === null) throw Error(E(166));
        if (n = Hn(vi.current), Hn(Yt.current), Wi(t)) {
          if (r = t.stateNode, n = t.memoizedProps, r[Wt] = t, (o = r.nodeValue !== n) && (e = pt, e !== null)) switch (e.tag) {
            case 3:
              Ui(r.nodeValue, n, (e.mode & 1) !== 0);
              break;
            case 5:
              e.memoizedProps.suppressHydrationWarning !== !0 && Ui(r.nodeValue, n, (e.mode & 1) !== 0)
          }
          o && (t.flags |= 4)
        } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Wt] = t, t.stateNode = r
      }
      return Qe(t), null;
    case 13:
      if (xe(we), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
        if (be && ft !== null && t.mode & 1 && !(t.flags & 128)) bd(), Pr(), t.flags |= 98560, o = !1;
        else if (o = Wi(t), r !== null && r.dehydrated !== null) {
          if (e === null) {
            if (!o) throw Error(E(318));
            if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(E(317));
            o[Wt] = t
          } else Pr(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
          Qe(t), o = !1
        } else _t !== null && (Ra(_t), _t = null), o = !0;
        if (!o) return t.flags & 65536 ? t : null
      }
      return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || we.current & 1 ? ze === 0 && (ze = 3) : Fs())), t.updateQueue !== null && (t.flags |= 4), Qe(t), null);
    case 4:
      return Lr(), wa(e, t), e === null && fi(t.stateNode.containerInfo), Qe(t), null;
    case 10:
      return bs(t.type._context), Qe(t), null;
    case 17:
      return at(t.type) && bl(), Qe(t), null;
    case 19:
      if (xe(we), o = t.memoizedState, o === null) return Qe(t), null;
      if (r = (t.flags & 128) !== 0, a = o.rendering, a === null)
        if (r) Hr(o, !1);
        else {
          if (ze !== 0 || e !== null && e.flags & 128)
            for (e = t.child; e !== null;) { if (a = Ml(e), a !== null) { for (t.flags |= 128, Hr(o, !1), r = a.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) o = n, e = r, o.flags &= 14680066, a = o.alternate, a === null ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = a.childLanes, o.lanes = a.lanes, o.child = a.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = a.memoizedProps, o.memoizedState = a.memoizedState, o.updateQueue = a.updateQueue, o.type = a.type, e = a.dependencies, o.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }), n = n.sibling; return he(we, we.current & 1 | 2), t.child } e = e.sibling } o.tail !== null && Be() > Rr && (t.flags |= 128, r = !0, Hr(o, !1), t.lanes = 4194304)
        }
      else {
        if (!r)
          if (e = Ml(a), e !== null) { if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), Hr(o, !0), o.tail === null && o.tailMode === "hidden" && !a.alternate && !be) return Qe(t), null } else 2 * Be() - o.renderingStartTime > Rr && n !== 1073741824 && (t.flags |= 128, r = !0, Hr(o, !1), t.lanes = 4194304);
        o.isBackwards ? (a.sibling = t.child, t.child = a) : (n = o.last, n !== null ? n.sibling = a : t.child = a, o.last = a)
      }
      return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = Be(), t.sibling = null, n = we.current, he(we, r ? n & 1 | 2 : n & 1), t) : (Qe(t), null);
    case 22:
    case 23:
      return Ds(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? mt & 1073741824 && (Qe(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Qe(t), null;
    case 24:
      return null;
    case 25:
      return null
  }
  throw Error(E(156, t.tag))
}

function Qh(e, t) {
  switch (vs(t), t.tag) {
    case 1:
      return at(t.type) && bl(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 3:
      return Lr(), xe(ot), xe(Ke), Ss(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
    case 5:
      return Is(t), null;
    case 13:
      if (xe(we), e = t.memoizedState, e !== null && e.dehydrated !== null) {
        if (t.alternate === null) throw Error(E(340));
        Pr()
      }
      return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 19:
      return xe(we), null;
    case 4:
      return Lr(), null;
    case 10:
      return bs(t.type._context), null;
    case 22:
    case 23:
      return Ds(), null;
    case 24:
      return null;
    default:
      return null
  }
}
var Yi = !1,
  Ye = !1,
  Yh = typeof WeakSet == "function" ? WeakSet : Set,
  F = null;

function gr(e, t) {
  var n = e.ref;
  if (n !== null)
    if (typeof n == "function") try { n(null) } catch (r) { Pe(e, t, r) } else n.current = null
}

function Na(e, t, n) { try { n() } catch (r) { Pe(e, t, r) } }
var Qu = !1;

function Kh(e, t) {
  if (aa = vl, e = sd(), hs(e)) {
    if ("selectionStart" in e) var n = { start: e.selectionStart, end: e.selectionEnd };
    else e: {
      n = (n = e.ownerDocument) && n.defaultView || window;
      var r = n.getSelection && n.getSelection();
      if (r && r.rangeCount !== 0) {
        n = r.anchorNode;
        var i = r.anchorOffset,
          o = r.focusNode;
        r = r.focusOffset;
        try { n.nodeType, o.nodeType } catch { n = null; break e }
        var a = 0,
          s = -1,
          u = -1,
          d = 0,
          p = 0,
          v = e,
          g = null;
        t: for (;;) {
          for (var k; v !== n || i !== 0 && v.nodeType !== 3 || (s = a + i), v !== o || r !== 0 && v.nodeType !== 3 || (u = a + r), v.nodeType === 3 && (a += v.nodeValue.length), (k = v.firstChild) !== null;) g = v, v = k;
          for (;;) {
            if (v === e) break t;
            if (g === n && ++d === i && (s = a), g === o && ++p === r && (u = a), (k = v.nextSibling) !== null) break;
            v = g, g = v.parentNode
          }
          v = k
        }
        n = s === -1 || u === -1 ? null : { start: s, end: u }
      } else n = null
    }
    n = n || { start: 0, end: 0 }
  } else n = null;
  for (sa = { focusedElem: e, selectionRange: n }, vl = !1, F = t; F !== null;)
    if (t = F, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, F = e;
    else
      for (; F !== null;) {
        t = F;
        try {
          var C = t.alternate;
          if (t.flags & 1024) switch (t.tag) {
            case 0:
            case 11:
            case 15:
              break;
            case 1:
              if (C !== null) {
                var b = C.memoizedProps,
                  N = C.memoizedState,
                  y = t.stateNode,
                  f = y.getSnapshotBeforeUpdate(t.elementType === t.type ? b : Tt(t.type, b), N);
                y.__reactInternalSnapshotBeforeUpdate = f
              }
              break;
            case 3:
              var x = t.stateNode.containerInfo;
              x.nodeType === 1 ? x.textContent = "" : x.nodeType === 9 && x.documentElement && x.removeChild(x.documentElement);
              break;
            case 5:
            case 6:
            case 4:
            case 17:
              break;
            default:
              throw Error(E(163))
          }
        } catch (w) { Pe(t, t.return, w) }
        if (e = t.sibling, e !== null) { e.return = t.return, F = e; break } F = t.return
      }
  return C = Qu, Qu = !1, C
}

function ni(e, t, n) {
  var r = t.updateQueue;
  if (r = r !== null ? r.lastEffect : null, r !== null) {
    var i = r = r.next;
    do {
      if ((i.tag & e) === e) {
        var o = i.destroy;
        i.destroy = void 0, o !== void 0 && Na(t, n, o)
      }
      i = i.next
    } while (i !== r)
  }
}

function Vl(e, t) {
  if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
    var n = t = t.next;
    do {
      if ((n.tag & e) === e) {
        var r = n.create;
        n.destroy = r()
      }
      n = n.next
    } while (n !== t)
  }
}

function Ia(e) {
  var t = e.ref;
  if (t !== null) {
    var n = e.stateNode;
    switch (e.tag) {
      case 5:
        e = n;
        break;
      default:
        e = n
    }
    typeof t == "function" ? t(e) : t.current = e
  }
}

function lm(e) {
  var t = e.alternate;
  t !== null && (e.alternate = null, lm(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Wt], delete t[hi], delete t[da], delete t[Rh], delete t[Eh])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function om(e) { return e.tag === 5 || e.tag === 3 || e.tag === 4 }

function Yu(e) {
  e: for (;;) {
    for (; e.sibling === null;) {
      if (e.return === null || om(e.return)) return null;
      e = e.return
    }
    for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      e.child.return = e, e = e.child
    }
    if (!(e.flags & 2)) return e.stateNode
  }
}

function Sa(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = kl));
  else if (r !== 4 && (e = e.child, e !== null))
    for (Sa(e, t, n), e = e.sibling; e !== null;) Sa(e, t, n), e = e.sibling
}

function Pa(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
  else if (r !== 4 && (e = e.child, e !== null))
    for (Pa(e, t, n), e = e.sibling; e !== null;) Pa(e, t, n), e = e.sibling
}
var $e = null,
  Ot = !1;

function un(e, t, n) { for (n = n.child; n !== null;) am(e, t, n), n = n.sibling }

function am(e, t, n) {
  if (Qt && typeof Qt.onCommitFiberUnmount == "function") try { Qt.onCommitFiberUnmount(Fl, n) } catch {}
  switch (n.tag) {
    case 5:
      Ye || gr(n, t);
    case 6:
      var r = $e,
        i = Ot;
      $e = null, un(e, t, n), $e = r, Ot = i, $e !== null && (Ot ? (e = $e, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : $e.removeChild(n.stateNode));
      break;
    case 18:
      $e !== null && (Ot ? (e = $e, n = n.stateNode, e.nodeType === 8 ? No(e.parentNode, n) : e.nodeType === 1 && No(e, n), ci(e)) : No($e, n.stateNode));
      break;
    case 4:
      r = $e, i = Ot, $e = n.stateNode.containerInfo, Ot = !0, un(e, t, n), $e = r, Ot = i;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!Ye && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
        i = r = r.next;
        do {
          var o = i,
            a = o.destroy;
          o = o.tag, a !== void 0 && (o & 2 || o & 4) && Na(n, t, a), i = i.next
        } while (i !== r)
      }
      un(e, t, n);
      break;
    case 1:
      if (!Ye && (gr(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try { r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount() } catch (s) { Pe(n, t, s) } un(e, t, n);
      break;
    case 21:
      un(e, t, n);
      break;
    case 22:
      n.mode & 1 ? (Ye = (r = Ye) || n.memoizedState !== null, un(e, t, n), Ye = r) : un(e, t, n);
      break;
    default:
      un(e, t, n)
  }
}

function Ku(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var n = e.stateNode;
    n === null && (n = e.stateNode = new Yh), t.forEach(function(r) {
      var i = ig.bind(null, e, r);
      n.has(r) || (n.add(r), r.then(i, i))
    })
  }
}

function Bt(e, t) {
  var n = t.deletions;
  if (n !== null)
    for (var r = 0; r < n.length; r++) {
      var i = n[r];
      try {
        var o = e,
          a = t,
          s = a;
        e: for (; s !== null;) {
          switch (s.tag) {
            case 5:
              $e = s.stateNode, Ot = !1;
              break e;
            case 3:
              $e = s.stateNode.containerInfo, Ot = !0;
              break e;
            case 4:
              $e = s.stateNode.containerInfo, Ot = !0;
              break e
          }
          s = s.return
        }
        if ($e === null) throw Error(E(160));
        am(o, a, i), $e = null, Ot = !1;
        var u = i.alternate;
        u !== null && (u.return = null), i.return = null
      } catch (d) { Pe(i, t, d) }
    }
  if (t.subtreeFlags & 12854)
    for (t = t.child; t !== null;) sm(t, e), t = t.sibling
}

function sm(e, t) {
  var n = e.alternate,
    r = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if (Bt(t, e), Ht(e), r & 4) { try { ni(3, e, e.return), Vl(3, e) } catch (b) { Pe(e, e.return, b) } try { ni(5, e, e.return) } catch (b) { Pe(e, e.return, b) } }
      break;
    case 1:
      Bt(t, e), Ht(e), r & 512 && n !== null && gr(n, n.return);
      break;
    case 5:
      if (Bt(t, e), Ht(e), r & 512 && n !== null && gr(n, n.return), e.flags & 32) { var i = e.stateNode; try { oi(i, "") } catch (b) { Pe(e, e.return, b) } }
      if (r & 4 && (i = e.stateNode, i != null)) {
        var o = e.memoizedProps,
          a = n !== null ? n.memoizedProps : o,
          s = e.type,
          u = e.updateQueue;
        if (e.updateQueue = null, u !== null) try {
          s === "input" && o.type === "radio" && o.name != null && Lc(i, o), Go(s, a);
          var d = Go(s, o);
          for (a = 0; a < u.length; a += 2) {
            var p = u[a],
              v = u[a + 1];
            p === "style" ? zc(i, v) : p === "dangerouslySetInnerHTML" ? Ec(i, v) : p === "children" ? oi(i, v) : ns(i, p, v, d)
          }
          switch (s) {
            case "input":
              Vo(i, o);
              break;
            case "textarea":
              Bc(i, o);
              break;
            case "select":
              var g = i._wrapperState.wasMultiple;
              i._wrapperState.wasMultiple = !!o.multiple;
              var k = o.value;
              k != null ? xr(i, !!o.multiple, k, !1) : g !== !!o.multiple && (o.defaultValue != null ? xr(i, !!o.multiple, o.defaultValue, !0) : xr(i, !!o.multiple, o.multiple ? [] : "", !1))
          }
          i[hi] = o
        } catch (b) { Pe(e, e.return, b) }
      }
      break;
    case 6:
      if (Bt(t, e), Ht(e), r & 4) {
        if (e.stateNode === null) throw Error(E(162));
        i = e.stateNode, o = e.memoizedProps;
        try { i.nodeValue = o } catch (b) { Pe(e, e.return, b) }
      }
      break;
    case 3:
      if (Bt(t, e), Ht(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try { ci(t.containerInfo) } catch (b) { Pe(e, e.return, b) }
      break;
    case 4:
      Bt(t, e), Ht(e);
      break;
    case 13:
      Bt(t, e), Ht(e), i = e.child, i.flags & 8192 && (o = i.memoizedState !== null, i.stateNode.isHidden = o, !o || i.alternate !== null && i.alternate.memoizedState !== null || (Os = Be())), r & 4 && Ku(e);
      break;
    case 22:
      if (p = n !== null && n.memoizedState !== null, e.mode & 1 ? (Ye = (d = Ye) || p, Bt(t, e), Ye = d) : Bt(t, e), Ht(e), r & 8192) {
        if (d = e.memoizedState !== null, (e.stateNode.isHidden = d) && !p && e.mode & 1)
          for (F = e, p = e.child; p !== null;) {
            for (v = F = p; F !== null;) {
              switch (g = F, k = g.child, g.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                  ni(4, g, g.return);
                  break;
                case 1:
                  gr(g, g.return);
                  var C = g.stateNode;
                  if (typeof C.componentWillUnmount == "function") { r = g, n = g.return; try { t = r, C.props = t.memoizedProps, C.state = t.memoizedState, C.componentWillUnmount() } catch (b) { Pe(r, n, b) } }
                  break;
                case 5:
                  gr(g, g.return);
                  break;
                case 22:
                  if (g.memoizedState !== null) { Gu(v); continue }
              }
              k !== null ? (k.return = g, F = k) : Gu(v)
            }
            p = p.sibling
          }
        e: for (p = null, v = e;;) {
          if (v.tag === 5) { if (p === null) { p = v; try { i = v.stateNode, d ? (o = i.style, typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (s = v.stateNode, u = v.memoizedProps.style, a = u != null && u.hasOwnProperty("display") ? u.display : null, s.style.display = Tc("display", a)) } catch (b) { Pe(e, e.return, b) } } } else if (v.tag === 6) { if (p === null) try { v.stateNode.nodeValue = d ? "" : v.memoizedProps } catch (b) { Pe(e, e.return, b) } } else if ((v.tag !== 22 && v.tag !== 23 || v.memoizedState === null || v === e) && v.child !== null) { v.child.return = v, v = v.child; continue }
          if (v === e) break e;
          for (; v.sibling === null;) {
            if (v.return === null || v.return === e) break e;
            p === v && (p = null), v = v.return
          }
          p === v && (p = null), v.sibling.return = v.return, v = v.sibling
        }
      }
      break;
    case 19:
      Bt(t, e), Ht(e), r & 4 && Ku(e);
      break;
    case 21:
      break;
    default:
      Bt(t, e), Ht(e)
  }
}

function Ht(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: { for (var n = e.return; n !== null;) { if (om(n)) { var r = n; break e } n = n.return } throw Error(E(160)) }
      switch (r.tag) {
        case 5:
          var i = r.stateNode;
          r.flags & 32 && (oi(i, ""), r.flags &= -33);
          var o = Yu(e);
          Pa(e, o, i);
          break;
        case 3:
        case 4:
          var a = r.stateNode.containerInfo,
            s = Yu(e);
          Sa(e, s, a);
          break;
        default:
          throw Error(E(161))
      }
    }
    catch (u) { Pe(e, e.return, u) } e.flags &= -3
  }
  t & 4096 && (e.flags &= -4097)
}

function Zh(e, t, n) { F = e, um(e) }

function um(e, t, n) {
  for (var r = (e.mode & 1) !== 0; F !== null;) {
    var i = F,
      o = i.child;
    if (i.tag === 22 && r) {
      var a = i.memoizedState !== null || Yi;
      if (!a) {
        var s = i.alternate,
          u = s !== null && s.memoizedState !== null || Ye;
        s = Yi;
        var d = Ye;
        if (Yi = a, (Ye = u) && !d)
          for (F = i; F !== null;) a = F, u = a.child, a.tag === 22 && a.memoizedState !== null ? Ju(i) : u !== null ? (u.return = a, F = u) : Ju(i);
        for (; o !== null;) F = o, um(o), o = o.sibling;
        F = i, Yi = s, Ye = d
      }
      Zu(e)
    } else i.subtreeFlags & 8772 && o !== null ? (o.return = i, F = o) : Zu(e)
  }
}

function Zu(e) {
  for (; F !== null;) {
    var t = F;
    if (t.flags & 8772) {
      var n = t.alternate;
      try {
        if (t.flags & 8772) switch (t.tag) {
          case 0:
          case 11:
          case 15:
            Ye || Vl(5, t);
            break;
          case 1:
            var r = t.stateNode;
            if (t.flags & 4 && !Ye)
              if (n === null) r.componentDidMount();
              else {
                var i = t.elementType === t.type ? n.memoizedProps : Tt(t.type, n.memoizedProps);
                r.componentDidUpdate(i, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
              } var o = t.updateQueue;
            o !== null && Tu(t, o, r);
            break;
          case 3:
            var a = t.updateQueue;
            if (a !== null) {
              if (n = null, t.child !== null) switch (t.child.tag) {
                case 5:
                  n = t.child.stateNode;
                  break;
                case 1:
                  n = t.child.stateNode
              }
              Tu(t, a, n)
            }
            break;
          case 5:
            var s = t.stateNode;
            if (n === null && t.flags & 4) {
              n = s;
              var u = t.memoizedProps;
              switch (t.type) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  u.autoFocus && n.focus();
                  break;
                case "img":
                  u.src && (n.src = u.src)
              }
            }
            break;
          case 6:
            break;
          case 4:
            break;
          case 12:
            break;
          case 13:
            if (t.memoizedState === null) {
              var d = t.alternate;
              if (d !== null) {
                var p = d.memoizedState;
                if (p !== null) {
                  var v = p.dehydrated;
                  v !== null && ci(v)
                }
              }
            }
            break;
          case 19:
          case 17:
          case 21:
          case 22:
          case 23:
          case 25:
            break;
          default:
            throw Error(E(163))
        }
        Ye || t.flags & 512 && Ia(t)
      } catch (g) { Pe(t, t.return, g) }
    }
    if (t === e) { F = null; break }
    if (n = t.sibling, n !== null) { n.return = t.return, F = n; break } F = t.return
  }
}

function Gu(e) { for (; F !== null;) { var t = F; if (t === e) { F = null; break } var n = t.sibling; if (n !== null) { n.return = t.return, F = n; break } F = t.return } }

function Ju(e) {
  for (; F !== null;) {
    var t = F;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var n = t.return;
          try { Vl(4, t) } catch (u) { Pe(t, n, u) }
          break;
        case 1:
          var r = t.stateNode;
          if (typeof r.componentDidMount == "function") { var i = t.return; try { r.componentDidMount() } catch (u) { Pe(t, i, u) } }
          var o = t.return;
          try { Ia(t) } catch (u) { Pe(t, o, u) }
          break;
        case 5:
          var a = t.return;
          try { Ia(t) } catch (u) { Pe(t, a, u) }
      }
    } catch (u) { Pe(t, t.return, u) }
    if (t === e) { F = null; break }
    var s = t.sibling;
    if (s !== null) { s.return = t.return, F = s; break } F = t.return
  }
}
var Gh = Math.ceil,
  Rl = sn.ReactCurrentDispatcher,
  Ts = sn.ReactCurrentOwner,
  It = sn.ReactCurrentBatchConfig,
  ae = 0,
  Fe = null,
  Re = null,
  Ae = 0,
  mt = 0,
  vr = Tn(0),
  ze = 0,
  bi = null,
  Zn = 0,
  Ql = 0,
  zs = 0,
  ri = null,
  it = null,
  Os = 0,
  Rr = 1 / 0,
  Gt = null,
  El = !1,
  Ma = null,
  In = null,
  Ki = !1,
  vn = null,
  Tl = 0,
  ii = 0,
  La = null,
  ol = -1,
  al = 0;

function et() { return ae & 6 ? Be() : ol !== -1 ? ol : ol = Be() }

function Sn(e) { return e.mode & 1 ? ae & 2 && Ae !== 0 ? Ae & -Ae : zh.transition !== null ? (al === 0 && (al = Vc()), al) : (e = me, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Xc(e.type)), e) : 1 }

function Ft(e, t, n, r) {
  if (50 < ii) throw ii = 0, La = null, Error(E(185));
  Si(e, n, r), (!(ae & 2) || e !== Fe) && (e === Fe && (!(ae & 2) && (Ql |= n), ze === 4 && hn(e, Ae)), st(e, r), n === 1 && ae === 0 && !(t.mode & 1) && (Rr = Be() + 500, ql && zn()))
}

function st(e, t) {
  var n = e.callbackNode;
  zp(e, t);
  var r = gl(e, e === Fe ? Ae : 0);
  if (r === 0) n !== null && au(n), e.callbackNode = null, e.callbackPriority = 0;
  else if (t = r & -r, e.callbackPriority !== t) {
    if (n != null && au(n), t === 1) e.tag === 0 ? Th(Xu.bind(null, e)) : yd(Xu.bind(null, e)), Lh(function() {!(ae & 6) && zn() }), n = null;
    else {
      switch (Qc(r)) {
        case 1:
          n = as;
          break;
        case 4:
          n = Uc;
          break;
        case 16:
          n = hl;
          break;
        case 536870912:
          n = Wc;
          break;
        default:
          n = hl
      }
      n = vm(n, cm.bind(null, e))
    }
    e.callbackPriority = t, e.callbackNode = n
  }
}

function cm(e, t) {
  if (ol = -1, al = 0, ae & 6) throw Error(E(327));
  var n = e.callbackNode;
  if (Nr() && e.callbackNode !== n) return null;
  var r = gl(e, e === Fe ? Ae : 0);
  if (r === 0) return null;
  if (r & 30 || r & e.expiredLanes || t) t = zl(e, r);
  else {
    t = r;
    var i = ae;
    ae |= 2;
    var o = mm();
    (Fe !== e || Ae !== t) && (Gt = null, Rr = Be() + 500, Un(e, t));
    do try { eg(); break } catch (s) { dm(e, s) }
    while (1);
    ks(), Rl.current = o, ae = i, Re !== null ? t = 0 : (Fe = null, Ae = 0, t = ze)
  }
  if (t !== 0) {
    if (t === 2 && (i = na(e), i !== 0 && (r = i, t = Ba(e, i))), t === 1) throw n = bi, Un(e, 0), hn(e, r), st(e, Be()), n;
    if (t === 6) hn(e, r);
    else {
      if (i = e.current.alternate, !(r & 30) && !Jh(i) && (t = zl(e, r), t === 2 && (o = na(e), o !== 0 && (r = o, t = Ba(e, o))), t === 1)) throw n = bi, Un(e, 0), hn(e, r), st(e, Be()), n;
      switch (e.finishedWork = i, e.finishedLanes = r, t) {
        case 0:
        case 1:
          throw Error(E(345));
        case 2:
          _n(e, it, Gt);
          break;
        case 3:
          if (hn(e, r), (r & 130023424) === r && (t = Os + 500 - Be(), 10 < t)) { if (gl(e, 0) !== 0) break; if (i = e.suspendedLanes, (i & r) !== r) { et(), e.pingedLanes |= e.suspendedLanes & i; break } e.timeoutHandle = ca(_n.bind(null, e, it, Gt), t); break } _n(e, it, Gt);
          break;
        case 4:
          if (hn(e, r), (r & 4194240) === r) break;
          for (t = e.eventTimes, i = -1; 0 < r;) {
            var a = 31 - Dt(r);
            o = 1 << a, a = t[a], a > i && (i = a), r &= ~o
          }
          if (r = i, r = Be() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * Gh(r / 1960)) - r, 10 < r) { e.timeoutHandle = ca(_n.bind(null, e, it, Gt), r); break } _n(e, it, Gt);
          break;
        case 5:
          _n(e, it, Gt);
          break;
        default:
          throw Error(E(329))
      }
    }
  }
  return st(e, Be()), e.callbackNode === n ? cm.bind(null, e) : null
}

function Ba(e, t) { var n = ri; return e.current.memoizedState.isDehydrated && (Un(e, t).flags |= 256), e = zl(e, t), e !== 2 && (t = it, it = n, t !== null && Ra(t)), e }

function Ra(e) { it === null ? it = e : it.push.apply(it, e) }

function Jh(e) {
  for (var t = e;;) {
    if (t.flags & 16384) {
      var n = t.updateQueue;
      if (n !== null && (n = n.stores, n !== null))
        for (var r = 0; r < n.length; r++) {
          var i = n[r],
            o = i.getSnapshot;
          i = i.value;
          try { if (!jt(o(), i)) return !1 } catch { return !1 }
        }
    }
    if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
    else {
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return !0;
        t = t.return
      }
      t.sibling.return = t.return, t = t.sibling
    }
  }
  return !0
}

function hn(e, t) {
  for (t &= ~zs, t &= ~Ql, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
    var n = 31 - Dt(t),
      r = 1 << n;
    e[n] = -1, t &= ~r
  }
}

function Xu(e) {
  if (ae & 6) throw Error(E(327));
  Nr();
  var t = gl(e, 0);
  if (!(t & 1)) return st(e, Be()), null;
  var n = zl(e, t);
  if (e.tag !== 0 && n === 2) {
    var r = na(e);
    r !== 0 && (t = r, n = Ba(e, r))
  }
  if (n === 1) throw n = bi, Un(e, 0), hn(e, t), st(e, Be()), n;
  if (n === 6) throw Error(E(345));
  return e.finishedWork = e.current.alternate, e.finishedLanes = t, _n(e, it, Gt), st(e, Be()), null
}

function _s(e, t) {
  var n = ae;
  ae |= 1;
  try { return e(t) } finally { ae = n, ae === 0 && (Rr = Be() + 500, ql && zn()) }
}

function Gn(e) {
  vn !== null && vn.tag === 0 && !(ae & 6) && Nr();
  var t = ae;
  ae |= 1;
  var n = It.transition,
    r = me;
  try { if (It.transition = null, me = 1, e) return e() } finally { me = r, It.transition = n, ae = t, !(ae & 6) && zn() }
}

function Ds() { mt = vr.current, xe(vr) }

function Un(e, t) {
  e.finishedWork = null, e.finishedLanes = 0;
  var n = e.timeoutHandle;
  if (n !== -1 && (e.timeoutHandle = -1, Mh(n)), Re !== null)
    for (n = Re.return; n !== null;) {
      var r = n;
      switch (vs(r), r.tag) {
        case 1:
          r = r.type.childContextTypes, r != null && bl();
          break;
        case 3:
          Lr(), xe(ot), xe(Ke), Ss();
          break;
        case 5:
          Is(r);
          break;
        case 4:
          Lr();
          break;
        case 13:
          xe(we);
          break;
        case 19:
          xe(we);
          break;
        case 10:
          bs(r.type._context);
          break;
        case 22:
        case 23:
          Ds()
      }
      n = n.return
    }
  if (Fe = e, Re = e = Pn(e.current, null), Ae = mt = t, ze = 0, bi = null, zs = Ql = Zn = 0, it = ri = null, An !== null) {
    for (t = 0; t < An.length; t++)
      if (n = An[t], r = n.interleaved, r !== null) {
        n.interleaved = null;
        var i = r.next,
          o = n.pending;
        if (o !== null) {
          var a = o.next;
          o.next = i, r.next = a
        }
        n.pending = r
      } An = null
  }
  return e
}

function dm(e, t) {
  do {
    var n = Re;
    try {
      if (ks(), rl.current = Bl, Ll) {
        for (var r = Ne.memoizedState; r !== null;) {
          var i = r.queue;
          i !== null && (i.pending = null), r = r.next
        }
        Ll = !1
      }
      if (Kn = 0, De = Te = Ne = null, ti = !1, yi = 0, Ts.current = null, n === null || n.return === null) { ze = 1, bi = t, Re = null; break } e: {
        var o = e,
          a = n.return,
          s = n,
          u = t;
        if (t = Ae, s.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
          var d = u,
            p = s,
            v = p.tag;
          if (!(p.mode & 1) && (v === 0 || v === 11 || v === 15)) {
            var g = p.alternate;
            g ? (p.updateQueue = g.updateQueue, p.memoizedState = g.memoizedState, p.lanes = g.lanes) : (p.updateQueue = null, p.memoizedState = null)
          }
          var k = $u(a);
          if (k !== null) {
            k.flags &= -257, Au(k, a, s, o, t), k.mode & 1 && ju(o, d, t), t = k, u = d;
            var C = t.updateQueue;
            if (C === null) {
              var b = new Set;
              b.add(u), t.updateQueue = b
            } else C.add(u);
            break e
          } else { if (!(t & 1)) { ju(o, d, t), Fs(); break e } u = Error(E(426)) }
        } else if (be && s.mode & 1) { var N = $u(a); if (N !== null) {!(N.flags & 65536) && (N.flags |= 256), Au(N, a, s, o, t), ys(Br(u, s)); break e } } o = u = Br(u, s),
        ze !== 4 && (ze = 2),
        ri === null ? ri = [o] : ri.push(o),
        o = a;do {
          switch (o.tag) {
            case 3:
              o.flags |= 65536, t &= -t, o.lanes |= t;
              var y = Yd(o, u, t);
              Eu(o, y);
              break e;
            case 1:
              s = u;
              var f = o.type,
                x = o.stateNode;
              if (!(o.flags & 128) && (typeof f.getDerivedStateFromError == "function" || x !== null && typeof x.componentDidCatch == "function" && (In === null || !In.has(x)))) {
                o.flags |= 65536, t &= -t, o.lanes |= t;
                var w = Kd(o, s, t);
                Eu(o, w);
                break e
              }
          }
          o = o.return
        } while (o !== null)
      }
      pm(n)
    } catch (S) { t = S, Re === n && n !== null && (Re = n = n.return); continue }
    break
  } while (1)
}

function mm() { var e = Rl.current; return Rl.current = Bl, e === null ? Bl : e }

function Fs() {
  (ze === 0 || ze === 3 || ze === 2) && (ze = 4), Fe === null || !(Zn & 268435455) && !(Ql & 268435455) || hn(Fe, Ae)
}

function zl(e, t) {
  var n = ae;
  ae |= 2;
  var r = mm();
  (Fe !== e || Ae !== t) && (Gt = null, Un(e, t));
  do try { Xh(); break } catch (i) { dm(e, i) }
  while (1);
  if (ks(), ae = n, Rl.current = r, Re !== null) throw Error(E(261));
  return Fe = null, Ae = 0, ze
}

function Xh() { for (; Re !== null;) fm(Re) }

function eg() { for (; Re !== null && !Ip();) fm(Re) }

function fm(e) {
  var t = gm(e.alternate, e, mt);
  e.memoizedProps = e.pendingProps, t === null ? pm(e) : Re = t, Ts.current = null
}

function pm(e) {
  var t = e;
  do {
    var n = t.alternate;
    if (e = t.return, t.flags & 32768) {
      if (n = Qh(n, t), n !== null) { n.flags &= 32767, Re = n; return }
      if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
      else { ze = 6, Re = null; return }
    } else if (n = Vh(n, t, mt), n !== null) { Re = n; return }
    if (t = t.sibling, t !== null) { Re = t; return } Re = t = e
  } while (t !== null);
  ze === 0 && (ze = 5)
}

function _n(e, t, n) {
  var r = me,
    i = It.transition;
  try { It.transition = null, me = 1, tg(e, t, n, r) } finally { It.transition = i, me = r }
  return null
}

function tg(e, t, n, r) {
  do Nr(); while (vn !== null);
  if (ae & 6) throw Error(E(327));
  n = e.finishedWork;
  var i = e.finishedLanes;
  if (n === null) return null;
  if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(E(177));
  e.callbackNode = null, e.callbackPriority = 0;
  var o = n.lanes | n.childLanes;
  if (Op(e, o), e === Fe && (Re = Fe = null, Ae = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || Ki || (Ki = !0, vm(hl, function() { return Nr(), null })), o = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || o) {
    o = It.transition, It.transition = null;
    var a = me;
    me = 1;
    var s = ae;
    ae |= 4, Ts.current = null, Kh(e, n), sm(n, e), bh(sa), vl = !!aa, sa = aa = null, e.current = n, Zh(n), Sp(), ae = s, me = a, It.transition = o
  } else e.current = n;
  if (Ki && (Ki = !1, vn = e, Tl = i), o = e.pendingLanes, o === 0 && (In = null), Lp(n.stateNode), st(e, Be()), t !== null)
    for (r = e.onRecoverableError, n = 0; n < t.length; n++) i = t[n], r(i.value, { componentStack: i.stack, digest: i.digest });
  if (El) throw El = !1, e = Ma, Ma = null, e;
  return Tl & 1 && e.tag !== 0 && Nr(), o = e.pendingLanes, o & 1 ? e === La ? ii++ : (ii = 0, La = e) : ii = 0, zn(), null
}

function Nr() {
  if (vn !== null) {
    var e = Qc(Tl),
      t = It.transition,
      n = me;
    try {
      if (It.transition = null, me = 16 > e ? 16 : e, vn === null) var r = !1;
      else {
        if (e = vn, vn = null, Tl = 0, ae & 6) throw Error(E(331));
        var i = ae;
        for (ae |= 4, F = e.current; F !== null;) {
          var o = F,
            a = o.child;
          if (F.flags & 16) {
            var s = o.deletions;
            if (s !== null) {
              for (var u = 0; u < s.length; u++) {
                var d = s[u];
                for (F = d; F !== null;) {
                  var p = F;
                  switch (p.tag) {
                    case 0:
                    case 11:
                    case 15:
                      ni(8, p, o)
                  }
                  var v = p.child;
                  if (v !== null) v.return = p, F = v;
                  else
                    for (; F !== null;) {
                      p = F;
                      var g = p.sibling,
                        k = p.return;
                      if (lm(p), p === d) { F = null; break }
                      if (g !== null) { g.return = k, F = g; break } F = k
                    }
                }
              }
              var C = o.alternate;
              if (C !== null) {
                var b = C.child;
                if (b !== null) {
                  C.child = null;
                  do {
                    var N = b.sibling;
                    b.sibling = null, b = N
                  } while (b !== null)
                }
              }
              F = o
            }
          }
          if (o.subtreeFlags & 2064 && a !== null) a.return = o, F = a;
          else e: for (; F !== null;) {
            if (o = F, o.flags & 2048) switch (o.tag) {
              case 0:
              case 11:
              case 15:
                ni(9, o, o.return)
            }
            var y = o.sibling;
            if (y !== null) { y.return = o.return, F = y; break e } F = o.return
          }
        }
        var f = e.current;
        for (F = f; F !== null;) {
          a = F;
          var x = a.child;
          if (a.subtreeFlags & 2064 && x !== null) x.return = a, F = x;
          else e: for (a = f; F !== null;) {
            if (s = F, s.flags & 2048) try {
              switch (s.tag) {
                case 0:
                case 11:
                case 15:
                  Vl(9, s)
              }
            } catch (S) { Pe(s, s.return, S) }
            if (s === a) { F = null; break e }
            var w = s.sibling;
            if (w !== null) { w.return = s.return, F = w; break e } F = s.return
          }
        }
        if (ae = i, zn(), Qt && typeof Qt.onPostCommitFiberRoot == "function") try { Qt.onPostCommitFiberRoot(Fl, e) } catch {} r = !0
      }
      return r
    } finally { me = n, It.transition = t }
  }
  return !1
}

function ec(e, t, n) { t = Br(n, t), t = Yd(e, t, 1), e = Nn(e, t, 1), t = et(), e !== null && (Si(e, 1, t), st(e, t)) }

function Pe(e, t, n) {
  if (e.tag === 3) ec(e, e, n);
  else
    for (; t !== null;) { if (t.tag === 3) { ec(t, e, n); break } else if (t.tag === 1) { var r = t.stateNode; if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (In === null || !In.has(r))) { e = Br(n, e), e = Kd(t, e, 1), t = Nn(t, e, 1), e = et(), t !== null && (Si(t, 1, e), st(t, e)); break } } t = t.return }
}

function ng(e, t, n) {
  var r = e.pingCache;
  r !== null && r.delete(t), t = et(), e.pingedLanes |= e.suspendedLanes & n, Fe === e && (Ae & n) === n && (ze === 4 || ze === 3 && (Ae & 130023424) === Ae && 500 > Be() - Os ? Un(e, 0) : zs |= n), st(e, t)
}

function hm(e, t) {
  t === 0 && (e.mode & 1 ? (t = ji, ji <<= 1, !(ji & 130023424) && (ji = 4194304)) : t = 1);
  var n = et();
  e = on(e, t), e !== null && (Si(e, t, n), st(e, n))
}

function rg(e) {
  var t = e.memoizedState,
    n = 0;
  t !== null && (n = t.retryLane), hm(e, n)
}

function ig(e, t) {
  var n = 0;
  switch (e.tag) {
    case 13:
      var r = e.stateNode,
        i = e.memoizedState;
      i !== null && (n = i.retryLane);
      break;
    case 19:
      r = e.stateNode;
      break;
    default:
      throw Error(E(314))
  }
  r !== null && r.delete(t), hm(e, n)
}
var gm;
gm = function(e, t, n) {
  if (e !== null)
    if (e.memoizedProps !== t.pendingProps || ot.current) lt = !0;
    else {
      if (!(e.lanes & n) && !(t.flags & 128)) return lt = !1, Wh(e, t, n);
      lt = !!(e.flags & 131072)
    }
  else lt = !1, be && t.flags & 1048576 && xd(t, Nl, t.index);
  switch (t.lanes = 0, t.tag) {
    case 2:
      var r = t.type;
      ll(e, t), e = t.pendingProps;
      var i = Sr(t, Ke.current);
      wr(t, n), i = Ms(null, t, r, e, i, n);
      var o = Ls();
      return t.flags |= 1, typeof i == "object" && i !== null && typeof i.render == "function" && i.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, at(r) ? (o = !0, Cl(t)) : o = !1, t.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, ws(t), i.updater = Ul, t.stateNode = i, i._reactInternals = t, va(t, r, e, n), t = ka(null, t, r, !0, o, n)) : (t.tag = 0, be && o && gs(t), Xe(null, t, i, n), t = t.child), t;
    case 16:
      r = t.elementType;
      e: {
        switch (ll(e, t), e = t.pendingProps, i = r._init, r = i(r._payload), t.type = r, i = t.tag = og(r), e = Tt(r, e), i) {
          case 0:
            t = xa(null, t, r, e, n);
            break e;
          case 1:
            t = Uu(null, t, r, e, n);
            break e;
          case 11:
            t = Hu(null, t, r, e, n);
            break e;
          case 14:
            t = qu(null, t, r, Tt(r.type, e), n);
            break e
        }
        throw Error(E(306, r, ""))
      }
      return t;
    case 0:
      return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Tt(r, i), xa(e, t, r, i, n);
    case 1:
      return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Tt(r, i), Uu(e, t, r, i, n);
    case 3:
      e: {
        if (Xd(t), e === null) throw Error(E(387));r = t.pendingProps,
        o = t.memoizedState,
        i = o.element,
        wd(e, t),
        Pl(t, r, null, n);
        var a = t.memoizedState;
        if (r = a.element, o.isDehydrated)
          if (o = { element: r, isDehydrated: !1, cache: a.cache, pendingSuspenseBoundaries: a.pendingSuspenseBoundaries, transitions: a.transitions }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) { i = Br(Error(E(423)), t), t = Wu(e, t, r, n, i); break e } else if (r !== i) { i = Br(Error(E(424)), t), t = Wu(e, t, r, n, i); break e } else
          for (ft = wn(t.stateNode.containerInfo.firstChild), pt = t, be = !0, _t = null, n = Pd(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
        else { if (Pr(), r === i) { t = an(e, t, n); break e } Xe(e, t, r, n) } t = t.child
      }
      return t;
    case 5:
      return Md(t), e === null && pa(t), r = t.type, i = t.pendingProps, o = e !== null ? e.memoizedProps : null, a = i.children, ua(r, i) ? a = null : o !== null && ua(r, o) && (t.flags |= 32), Jd(e, t), Xe(e, t, a, n), t.child;
    case 6:
      return e === null && pa(t), null;
    case 13:
      return em(e, t, n);
    case 4:
      return Ns(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = Mr(t, null, r, n) : Xe(e, t, r, n), t.child;
    case 11:
      return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Tt(r, i), Hu(e, t, r, i, n);
    case 7:
      return Xe(e, t, t.pendingProps, n), t.child;
    case 8:
      return Xe(e, t, t.pendingProps.children, n), t.child;
    case 12:
      return Xe(e, t, t.pendingProps.children, n), t.child;
    case 10:
      e: {
        if (r = t.type._context, i = t.pendingProps, o = t.memoizedProps, a = i.value, he(Il, r._currentValue), r._currentValue = a, o !== null)
          if (jt(o.value, a)) { if (o.children === i.children && !ot.current) { t = an(e, t, n); break e } } else
            for (o = t.child, o !== null && (o.return = t); o !== null;) {
              var s = o.dependencies;
              if (s !== null) {
                a = o.child;
                for (var u = s.firstContext; u !== null;) {
                  if (u.context === r) {
                    if (o.tag === 1) {
                      u = nn(-1, n & -n), u.tag = 2;
                      var d = o.updateQueue;
                      if (d !== null) {
                        d = d.shared;
                        var p = d.pending;
                        p === null ? u.next = u : (u.next = p.next, p.next = u), d.pending = u
                      }
                    }
                    o.lanes |= n, u = o.alternate, u !== null && (u.lanes |= n), ha(o.return, n, t), s.lanes |= n;
                    break
                  }
                  u = u.next
                }
              } else if (o.tag === 10) a = o.type === t.type ? null : o.child;
              else if (o.tag === 18) {
                if (a = o.return, a === null) throw Error(E(341));
                a.lanes |= n, s = a.alternate, s !== null && (s.lanes |= n), ha(a, n, t), a = o.sibling
              } else a = o.child;
              if (a !== null) a.return = o;
              else
                for (a = o; a !== null;) { if (a === t) { a = null; break } if (o = a.sibling, o !== null) { o.return = a.return, a = o; break } a = a.return } o = a
            }
        Xe(e, t, i.children, n),
        t = t.child
      }
      return t;
    case 9:
      return i = t.type, r = t.pendingProps.children, wr(t, n), i = St(i), r = r(i), t.flags |= 1, Xe(e, t, r, n), t.child;
    case 14:
      return r = t.type, i = Tt(r, t.pendingProps), i = Tt(r.type, i), qu(e, t, r, i, n);
    case 15:
      return Zd(e, t, t.type, t.pendingProps, n);
    case 17:
      return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Tt(r, i), ll(e, t), t.tag = 1, at(r) ? (e = !0, Cl(t)) : e = !1, wr(t, n), Id(t, r, i), va(t, r, i, n), ka(null, t, r, !0, e, n);
    case 19:
      return tm(e, t, n);
    case 22:
      return Gd(e, t, n)
  }
  throw Error(E(156, t.tag))
};

function vm(e, t) { return qc(e, t) }

function lg(e, t, n, r) { this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null }

function Nt(e, t, n, r) { return new lg(e, t, n, r) }

function js(e) { return e = e.prototype, !(!e || !e.isReactComponent) }

function og(e) { if (typeof e == "function") return js(e) ? 1 : 0; if (e != null) { if (e = e.$$typeof, e === is) return 11; if (e === ls) return 14 } return 2 }

function Pn(e, t) { var n = e.alternate; return n === null ? (n = Nt(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n }

function sl(e, t, n, r, i, o) {
  var a = 2;
  if (r = e, typeof e == "function") js(e) && (a = 1);
  else if (typeof e == "string") a = 5;
  else e: switch (e) {
    case ar:
      return Wn(n.children, i, o, t);
    case rs:
      a = 8, i |= 8;
      break;
    case Ao:
      return e = Nt(12, n, t, i | 2), e.elementType = Ao, e.lanes = o, e;
    case Ho:
      return e = Nt(13, n, t, i), e.elementType = Ho, e.lanes = o, e;
    case qo:
      return e = Nt(19, n, t, i), e.elementType = qo, e.lanes = o, e;
    case Sc:
      return Yl(n, i, o, t);
    default:
      if (typeof e == "object" && e !== null) switch (e.$$typeof) {
        case Nc:
          a = 10;
          break e;
        case Ic:
          a = 9;
          break e;
        case is:
          a = 11;
          break e;
        case ls:
          a = 14;
          break e;
        case dn:
          a = 16, r = null;
          break e
      }
      throw Error(E(130, e == null ? e : typeof e, ""))
  }
  return t = Nt(a, n, t, i), t.elementType = e, t.type = r, t.lanes = o, t
}

function Wn(e, t, n, r) { return e = Nt(7, e, r, t), e.lanes = n, e }

function Yl(e, t, n, r) { return e = Nt(22, e, r, t), e.elementType = Sc, e.lanes = n, e.stateNode = { isHidden: !1 }, e }

function Eo(e, t, n) { return e = Nt(6, e, null, t), e.lanes = n, e }

function To(e, t, n) { return t = Nt(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = { containerInfo: e.containerInfo, pendingChildren: null, implementation: e.implementation }, t }

function ag(e, t, n, r, i) { this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = fo(0), this.expirationTimes = fo(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = fo(0), this.identifierPrefix = r, this.onRecoverableError = i, this.mutableSourceEagerHydrationData = null }

function $s(e, t, n, r, i, o, a, s, u) { return e = new ag(e, t, n, s, u), t === 1 ? (t = 1, o === !0 && (t |= 8)) : t = 0, o = Nt(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = { element: r, isDehydrated: n, cache: null, transitions: null, pendingSuspenseBoundaries: null }, ws(o), e }

function sg(e, t, n) { var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null; return { $$typeof: or, key: r == null ? null : "" + r, children: e, containerInfo: t, implementation: n } }

function ym(e) {
  if (!e) return Rn;
  e = e._reactInternals;
  e: {
    if (er(e) !== e || e.tag !== 1) throw Error(E(170));
    var t = e;do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (at(t.type)) { t = t.stateNode.__reactInternalMemoizedMergedChildContext; break e }
      }
      t = t.return
    } while (t !== null);
    throw Error(E(171))
  }
  if (e.tag === 1) { var n = e.type; if (at(n)) return vd(e, n, t) }
  return t
}

function xm(e, t, n, r, i, o, a, s, u) { return e = $s(n, r, !0, e, i, o, a, s, u), e.context = ym(null), n = e.current, r = et(), i = Sn(n), o = nn(r, i), o.callback = t ?? null, Nn(n, o, i), e.current.lanes = i, Si(e, i, r), st(e, r), e }

function Kl(e, t, n, r) {
  var i = t.current,
    o = et(),
    a = Sn(i);
  return n = ym(n), t.context === null ? t.context = n : t.pendingContext = n, t = nn(o, a), t.payload = { element: e }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = Nn(i, t, a), e !== null && (Ft(e, i, a, o), nl(e, i, a)), a
}

function Ol(e) {
  if (e = e.current, !e.child) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode
  }
}

function tc(e, t) {
  if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
    var n = e.retryLane;
    e.retryLane = n !== 0 && n < t ? n : t
  }
}

function As(e, t) { tc(e, t), (e = e.alternate) && tc(e, t) }

function ug() { return null }
var km = typeof reportError == "function" ? reportError : function(e) { console.error(e) };

function Hs(e) { this._internalRoot = e } Zl.prototype.render = Hs.prototype.render = function(e) {
  var t = this._internalRoot;
  if (t === null) throw Error(E(409));
  Kl(e, t, null, null)
};
Zl.prototype.unmount = Hs.prototype.unmount = function() {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    Gn(function() { Kl(null, e, null, null) }), t[ln] = null
  }
};

function Zl(e) { this._internalRoot = e } Zl.prototype.unstable_scheduleHydration = function(e) {
  if (e) {
    var t = Zc();
    e = { blockedOn: null, target: e, priority: t };
    for (var n = 0; n < pn.length && t !== 0 && t < pn[n].priority; n++);
    pn.splice(n, 0, e), n === 0 && Jc(e)
  }
};

function qs(e) { return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11) }

function Gl(e) { return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable ")) }

function nc() {}

function cg(e, t, n, r, i) {
  if (i) {
    if (typeof r == "function") {
      var o = r;
      r = function() {
        var d = Ol(a);
        o.call(d)
      }
    }
    var a = xm(t, r, e, 0, null, !1, !1, "", nc);
    return e._reactRootContainer = a, e[ln] = a.current, fi(e.nodeType === 8 ? e.parentNode : e), Gn(), a
  }
  for (; i = e.lastChild;) e.removeChild(i);
  if (typeof r == "function") {
    var s = r;
    r = function() {
      var d = Ol(u);
      s.call(d)
    }
  }
  var u = $s(e, 0, !1, null, null, !1, !1, "", nc);
  return e._reactRootContainer = u, e[ln] = u.current, fi(e.nodeType === 8 ? e.parentNode : e), Gn(function() { Kl(t, u, n, r) }), u
}

function Jl(e, t, n, r, i) {
  var o = n._reactRootContainer;
  if (o) {
    var a = o;
    if (typeof i == "function") {
      var s = i;
      i = function() {
        var u = Ol(a);
        s.call(u)
      }
    }
    Kl(t, a, e, i)
  } else a = cg(n, t, e, i, r);
  return Ol(a)
}
Yc = function(e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var n = Vr(t.pendingLanes);
        n !== 0 && (ss(t, n | 1), st(t, Be()), !(ae & 6) && (Rr = Be() + 500, zn()))
      }
      break;
    case 13:
      Gn(function() {
        var r = on(e, 1);
        if (r !== null) {
          var i = et();
          Ft(r, e, 1, i)
        }
      }), As(e, 1)
  }
};
us = function(e) {
  if (e.tag === 13) {
    var t = on(e, 134217728);
    if (t !== null) {
      var n = et();
      Ft(t, e, 134217728, n)
    }
    As(e, 134217728)
  }
};
Kc = function(e) {
  if (e.tag === 13) {
    var t = Sn(e),
      n = on(e, t);
    if (n !== null) {
      var r = et();
      Ft(n, e, t, r)
    }
    As(e, t)
  }
};
Zc = function() { return me };
Gc = function(e, t) { var n = me; try { return me = e, t() } finally { me = n } };
Xo = function(e, t, n) {
  switch (t) {
    case "input":
      if (Vo(e, n), t = n.name, n.type === "radio" && t != null) {
        for (n = e; n.parentNode;) n = n.parentNode;
        for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
          var r = n[t];
          if (r !== e && r.form === e.form) {
            var i = Hl(r);
            if (!i) throw Error(E(90));
            Mc(r), Vo(r, i)
          }
        }
      }
      break;
    case "textarea":
      Bc(e, n);
      break;
    case "select":
      t = n.value, t != null && xr(e, !!n.multiple, t, !1)
  }
};
Dc = _s;
Fc = Gn;
var dg = { usingClientEntryPoint: !1, Events: [Mi, dr, Hl, Oc, _c, _s] },
  qr = { findFiberByHostInstance: $n, bundleType: 0, version: "18.2.0", rendererPackageName: "react-dom" },
  mg = { bundleType: qr.bundleType, version: qr.version, rendererPackageName: qr.rendererPackageName, rendererConfig: qr.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: sn.ReactCurrentDispatcher, findHostInstanceByFiber: function(e) { return e = Ac(e), e === null ? null : e.stateNode }, findFiberByHostInstance: qr.findFiberByHostInstance || ug, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.2.0-next-9e3b772b8-20220608" };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") { var Zi = __REACT_DEVTOOLS_GLOBAL_HOOK__; if (!Zi.isDisabled && Zi.supportsFiber) try { Fl = Zi.inject(mg), Qt = Zi } catch {} } gt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = dg;
gt.createPortal = function(e, t) { var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null; if (!qs(t)) throw Error(E(200)); return sg(e, t, null, n) };
gt.createRoot = function(e, t) {
  if (!qs(e)) throw Error(E(299));
  var n = !1,
    r = "",
    i = km;
  return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (i = t.onRecoverableError)), t = $s(e, 1, !1, null, null, n, !1, r, i), e[ln] = t.current, fi(e.nodeType === 8 ? e.parentNode : e), new Hs(t)
};
gt.findDOMNode = function(e) { if (e == null) return null; if (e.nodeType === 1) return e; var t = e._reactInternals; if (t === void 0) throw typeof e.render == "function" ? Error(E(188)) : (e = Object.keys(e).join(","), Error(E(268, e))); return e = Ac(t), e = e === null ? null : e.stateNode, e };
gt.flushSync = function(e) { return Gn(e) };
gt.hydrate = function(e, t, n) { if (!Gl(t)) throw Error(E(200)); return Jl(null, e, t, !0, n) };
gt.hydrateRoot = function(e, t, n) {
  if (!qs(e)) throw Error(E(405));
  var r = n != null && n.hydratedSources || null,
    i = !1,
    o = "",
    a = km;
  if (n != null && (n.unstable_strictMode === !0 && (i = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onRecoverableError !== void 0 && (a = n.onRecoverableError)), t = xm(t, null, e, 1, n ?? null, i, !1, o, a), e[ln] = t.current, fi(e), r)
    for (e = 0; e < r.length; e++) n = r[e], i = n._getVersion, i = i(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, i] : t.mutableSourceEagerHydrationData.push(n, i);
  return new Zl(t)
};
gt.render = function(e, t, n) { if (!Gl(t)) throw Error(E(200)); return Jl(null, e, t, !1, n) };
gt.unmountComponentAtNode = function(e) { if (!Gl(e)) throw Error(E(40)); return e._reactRootContainer ? (Gn(function() { Jl(null, null, e, !1, function() { e._reactRootContainer = null, e[ln] = null }) }), !0) : !1 };
gt.unstable_batchedUpdates = _s;
gt.unstable_renderSubtreeIntoContainer = function(e, t, n, r) { if (!Gl(n)) throw Error(E(200)); if (e == null || e._reactInternals === void 0) throw Error(E(38)); return Jl(e, t, n, !1, r) };
gt.version = "18.2.0-next-9e3b772b8-20220608";
(function(e) {
  function t() { if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try { __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(t) } catch (n) { console.error(n) } } t(), e.exports = gt
})(up);
var bm, rc = Fo;
bm = rc.createRoot, rc.hydrateRoot;
var Ci = {},
  fg = { get exports() { return Ci }, set exports(e) { Ci = e } },
  Xl = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var pg = m,
  hg = Symbol.for("react.element"),
  gg = Symbol.for("react.fragment"),
  vg = Object.prototype.hasOwnProperty,
  yg = pg.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
  xg = { key: !0, ref: !0, __self: !0, __source: !0 };

function Cm(e, t, n) {
  var r, i = {},
    o = null,
    a = null;
  n !== void 0 && (o = "" + n), t.key !== void 0 && (o = "" + t.key), t.ref !== void 0 && (a = t.ref);
  for (r in t) vg.call(t, r) && !xg.hasOwnProperty(r) && (i[r] = t[r]);
  if (e && e.defaultProps)
    for (r in t = e.defaultProps, t) i[r] === void 0 && (i[r] = t[r]);
  return { $$typeof: hg, type: e, key: o, ref: a, props: i, _owner: yg.current }
}
Xl.Fragment = gg;
Xl.jsx = Cm;
Xl.jsxs = Cm;
(function(e) { e.exports = Xl })(fg);
const ut = Ci.Fragment,
  l = Ci.jsx,
  h = Ci.jsxs;
/**
 * @remix-run/router v1.5.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function wi() { return wi = Object.assign ? Object.assign.bind() : function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, wi.apply(this, arguments) }
var yn;
(function(e) { e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE" })(yn || (yn = {}));
const ic = "popstate";

function kg(e) {
  e === void 0 && (e = {});

  function t(i, o) { let { pathname: a = "/", search: s = "", hash: u = "" } = tr(i.location.hash.substr(1)); return Ea("", { pathname: a, search: s, hash: u }, o.state && o.state.usr || null, o.state && o.state.key || "default") }

  function n(i, o) {
    let a = i.document.querySelector("base"),
      s = "";
    if (a && a.getAttribute("href")) {
      let u = i.location.href,
        d = u.indexOf("#");
      s = d === -1 ? u : u.slice(0, d)
    }
    return s + "#" + (typeof o == "string" ? o : _l(o))
  }

  function r(i, o) { eo(i.pathname.charAt(0) === "/", "relative pathnames are not supported in hash history.push(" + JSON.stringify(o) + ")") }
  return Cg(t, n, r, e)
}

function Oe(e, t) { if (e === !1 || e === null || typeof e > "u") throw new Error(t) }

function eo(e, t) { if (!e) { typeof console < "u" && console.warn(t); try { throw new Error(t) } catch {} } }

function bg() { return Math.random().toString(36).substr(2, 8) }

function lc(e, t) { return { usr: e.state, key: e.key, idx: t } }

function Ea(e, t, n, r) { return n === void 0 && (n = null), wi({ pathname: typeof e == "string" ? e : e.pathname, search: "", hash: "" }, typeof t == "string" ? tr(t) : t, { state: n, key: t && t.key || r || bg() }) }

function _l(e) { let { pathname: t = "/", search: n = "", hash: r = "" } = e; return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t }

function tr(e) {
  let t = {};
  if (e) {
    let n = e.indexOf("#");
    n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
    let r = e.indexOf("?");
    r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
  }
  return t
}

function Cg(e, t, n, r) {
  r === void 0 && (r = {});
  let { window: i = document.defaultView, v5Compat: o = !1 } = r, a = i.history, s = yn.Pop, u = null, d = p();
  d == null && (d = 0, a.replaceState(wi({}, a.state, { idx: d }), ""));

  function p() { return (a.state || { idx: null }).idx }

  function v() {
    s = yn.Pop;
    let N = p(),
      y = N == null ? null : N - d;
    d = N, u && u({ action: s, location: b.location, delta: y })
  }

  function g(N, y) {
    s = yn.Push;
    let f = Ea(b.location, N, y);
    n && n(f, N), d = p() + 1;
    let x = lc(f, d),
      w = b.createHref(f);
    try { a.pushState(x, "", w) } catch { i.location.assign(w) } o && u && u({ action: s, location: b.location, delta: 1 })
  }

  function k(N, y) {
    s = yn.Replace;
    let f = Ea(b.location, N, y);
    n && n(f, N), d = p();
    let x = lc(f, d),
      w = b.createHref(f);
    a.replaceState(x, "", w), o && u && u({ action: s, location: b.location, delta: 0 })
  }

  function C(N) {
    let y = i.location.origin !== "null" ? i.location.origin : i.location.href,
      f = typeof N == "string" ? N : _l(N);
    return Oe(y, "No window.location.(origin|href) available to create URL for href: " + f), new URL(f, y)
  }
  let b = { get action() { return s }, get location() { return e(i, a) }, listen(N) { if (u) throw new Error("A history only accepts one active listener"); return i.addEventListener(ic, v), u = N, () => { i.removeEventListener(ic, v), u = null } }, createHref(N) { return t(i, N) }, createURL: C, encodeLocation(N) { let y = C(N); return { pathname: y.pathname, search: y.search, hash: y.hash } }, push: g, replace: k, go(N) { return a.go(N) } };
  return b
}
var oc;
(function(e) { e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error" })(oc || (oc = {}));

function wg(e, t, n) {
  n === void 0 && (n = "/");
  let r = typeof t == "string" ? tr(t) : t,
    i = Us(r.pathname || "/", n);
  if (i == null) return null;
  let o = wm(e);
  Ng(o);
  let a = null;
  for (let s = 0; a == null && s < o.length; ++s) a = Tg(o[s], _g(i));
  return a
}

function wm(e, t, n, r) {
  t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
  let i = (o, a, s) => {
    let u = { relativePath: s === void 0 ? o.path || "" : s, caseSensitive: o.caseSensitive === !0, childrenIndex: a, route: o };
    u.relativePath.startsWith("/") && (Oe(u.relativePath.startsWith(r), 'Absolute route path "' + u.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), u.relativePath = u.relativePath.slice(r.length));
    let d = Mn([r, u.relativePath]),
      p = n.concat(u);
    o.children && o.children.length > 0 && (Oe(o.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + d + '".')), wm(o.children, t, p, d)), !(o.path == null && !o.index) && t.push({ path: d, score: Rg(d, o.index), routesMeta: p })
  };
  return e.forEach((o, a) => {
    var s;
    if (o.path === "" || !((s = o.path) != null && s.includes("?"))) i(o, a);
    else
      for (let u of Nm(o.path)) i(o, a, u)
  }), t
}

function Nm(e) {
  let t = e.split("/");
  if (t.length === 0) return [];
  let [n, ...r] = t, i = n.endsWith("?"), o = n.replace(/\?$/, "");
  if (r.length === 0) return i ? [o, ""] : [o];
  let a = Nm(r.join("/")),
    s = [];
  return s.push(...a.map(u => u === "" ? o : [o, u].join("/"))), i && s.push(...a), s.map(u => e.startsWith("/") && u === "" ? "/" : u)
}

function Ng(e) { e.sort((t, n) => t.score !== n.score ? n.score - t.score : Eg(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex))) }
const Ig = /^:\w+$/,
  Sg = 3,
  Pg = 2,
  Mg = 1,
  Lg = 10,
  Bg = -2,
  ac = e => e === "*";

function Rg(e, t) {
  let n = e.split("/"),
    r = n.length;
  return n.some(ac) && (r += Bg), t && (r += Pg), n.filter(i => !ac(i)).reduce((i, o) => i + (Ig.test(o) ? Sg : o === "" ? Mg : Lg), r)
}

function Eg(e, t) { return e.length === t.length && e.slice(0, -1).every((r, i) => r === t[i]) ? e[e.length - 1] - t[t.length - 1] : 0 }

function Tg(e, t) {
  let { routesMeta: n } = e, r = {}, i = "/", o = [];
  for (let a = 0; a < n.length; ++a) {
    let s = n[a],
      u = a === n.length - 1,
      d = i === "/" ? t : t.slice(i.length) || "/",
      p = zg({ path: s.relativePath, caseSensitive: s.caseSensitive, end: u }, d);
    if (!p) return null;
    Object.assign(r, p.params);
    let v = s.route;
    o.push({ params: r, pathname: Mn([i, p.pathname]), pathnameBase: $g(Mn([i, p.pathnameBase])), route: v }), p.pathnameBase !== "/" && (i = Mn([i, p.pathnameBase]))
  }
  return o
}

function zg(e, t) {
  typeof e == "string" && (e = { path: e, caseSensitive: !1, end: !0 });
  let [n, r] = Og(e.path, e.caseSensitive, e.end), i = t.match(n);
  if (!i) return null;
  let o = i[0],
    a = o.replace(/(.)\/+$/, "$1"),
    s = i.slice(1);
  return {
    params: r.reduce((d, p, v) => {
      if (p === "*") {
        let g = s[v] || "";
        a = o.slice(0, o.length - g.length).replace(/(.)\/+$/, "$1")
      }
      return d[p] = Dg(s[v] || "", p), d
    }, {}),
    pathname: o,
    pathnameBase: a,
    pattern: e
  }
}

function Og(e, t, n) {
  t === void 0 && (t = !1), n === void 0 && (n = !0), eo(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
  let r = [],
    i = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^$?{}|()[\]]/g, "\\$&").replace(/\/:(\w+)/g, (a, s) => (r.push(s), "/([^\\/]+)"));
  return e.endsWith("*") ? (r.push("*"), i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? i += "\\/*$" : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"), [new RegExp(i, t ? void 0 : "i"), r]
}

function _g(e) { try { return decodeURI(e) } catch (t) { return eo(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e } }

function Dg(e, t) { try { return decodeURIComponent(e) } catch (n) { return eo(!1, 'The value for the URL param "' + t + '" will not be decoded because' + (' the string "' + e + '" is a malformed URL segment. This is probably') + (" due to a bad percent encoding (" + n + ").")), e } }

function Us(e, t) {
  if (t === "/") return e;
  if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
  let n = t.endsWith("/") ? t.length - 1 : t.length,
    r = e.charAt(n);
  return r && r !== "/" ? null : e.slice(n) || "/"
}

function Fg(e, t) { t === void 0 && (t = "/"); let { pathname: n, search: r = "", hash: i = "" } = typeof e == "string" ? tr(e) : e; return { pathname: n ? n.startsWith("/") ? n : jg(n, t) : t, search: Ag(r), hash: Hg(i) } }

function jg(e, t) { let n = t.replace(/\/+$/, "").split("/"); return e.split("/").forEach(i => { i === ".." ? n.length > 1 && n.pop() : i !== "." && n.push(i) }), n.length > 1 ? n.join("/") : "/" }

function zo(e, t, n, r) { return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.' }

function Im(e) { return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0) }

function Sm(e, t, n, r) {
  r === void 0 && (r = !1);
  let i;
  typeof e == "string" ? i = tr(e) : (i = wi({}, e), Oe(!i.pathname || !i.pathname.includes("?"), zo("?", "pathname", "search", i)), Oe(!i.pathname || !i.pathname.includes("#"), zo("#", "pathname", "hash", i)), Oe(!i.search || !i.search.includes("#"), zo("#", "search", "hash", i)));
  let o = e === "" || i.pathname === "",
    a = o ? "/" : i.pathname,
    s;
  if (r || a == null) s = n;
  else {
    let v = t.length - 1;
    if (a.startsWith("..")) {
      let g = a.split("/");
      for (; g[0] === "..";) g.shift(), v -= 1;
      i.pathname = g.join("/")
    }
    s = v >= 0 ? t[v] : "/"
  }
  let u = Fg(i, s),
    d = a && a !== "/" && a.endsWith("/"),
    p = (o || a === ".") && n.endsWith("/");
  return !u.pathname.endsWith("/") && (d || p) && (u.pathname += "/"), u
}
const Mn = e => e.join("/").replace(/\/\/+/g, "/"),
  $g = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
  Ag = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
  Hg = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;

function qg(e) { return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e }
/**
 * React Router v6.10.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function Ug(e, t) { return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t }
const Wg = typeof Object.is == "function" ? Object.is : Ug,
  { useState: Vg, useEffect: Qg, useLayoutEffect: Yg, useDebugValue: Kg } = Do;

function Zg(e, t, n) {
  const r = t(),
    [{ inst: i }, o] = Vg({ inst: { value: r, getSnapshot: t } });
  return Yg(() => { i.value = r, i.getSnapshot = t, Oo(i) && o({ inst: i }) }, [e, r, t]), Qg(() => (Oo(i) && o({ inst: i }), e(() => { Oo(i) && o({ inst: i }) })), [e]), Kg(r), r
}

function Oo(e) {
  const t = e.getSnapshot,
    n = e.value;
  try { const r = t(); return !Wg(n, r) } catch { return !0 }
}

function Gg(e, t, n) { return t() }
const Jg = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u",
  Xg = !Jg,
  e1 = Xg ? Gg : Zg;
"useSyncExternalStore" in Do && (e => e.useSyncExternalStore)(Do);
const Pm = m.createContext(null),
  Mm = m.createContext(null),
  Bi = m.createContext(null),
  to = m.createContext(null),
  Or = m.createContext({ outlet: null, matches: [] }),
  Lm = m.createContext(null);

function Ta() { return Ta = Object.assign ? Object.assign.bind() : function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Ta.apply(this, arguments) }

function t1(e, t) {
  let { relative: n } = t === void 0 ? {} : t;
  Ri() || Oe(!1);
  let { basename: r, navigator: i } = m.useContext(Bi), { hash: o, pathname: a, search: s } = Bm(e, { relative: n }), u = a;
  return r !== "/" && (u = a === "/" ? r : Mn([r, a])), i.createHref({ pathname: u, search: s, hash: o })
}

function Ri() { return m.useContext(to) != null }

function no() { return Ri() || Oe(!1), m.useContext(to).location }

function n1() {
  Ri() || Oe(!1);
  let { basename: e, navigator: t } = m.useContext(Bi), { matches: n } = m.useContext(Or), { pathname: r } = no(), i = JSON.stringify(Im(n).map(s => s.pathnameBase)), o = m.useRef(!1);
  return m.useEffect(() => { o.current = !0 }), m.useCallback(function(s, u) {
    if (u === void 0 && (u = {}), !o.current) return;
    if (typeof s == "number") { t.go(s); return }
    let d = Sm(s, JSON.parse(i), r, u.relative === "path");
    e !== "/" && (d.pathname = d.pathname === "/" ? e : Mn([e, d.pathname])), (u.replace ? t.replace : t.push)(d, u.state, u)
  }, [e, t, i, r])
}

function Bm(e, t) { let { relative: n } = t === void 0 ? {} : t, { matches: r } = m.useContext(Or), { pathname: i } = no(), o = JSON.stringify(Im(r).map(a => a.pathnameBase)); return m.useMemo(() => Sm(e, JSON.parse(o), i, n === "path"), [e, o, i, n]) }

function r1(e, t) {
  Ri() || Oe(!1);
  let { navigator: n } = m.useContext(Bi), r = m.useContext(Mm), { matches: i } = m.useContext(Or), o = i[i.length - 1], a = o ? o.params : {};
  o && o.pathname;
  let s = o ? o.pathnameBase : "/";
  o && o.route;
  let u = no(),
    d;
  if (t) {
    var p;
    let b = typeof t == "string" ? tr(t) : t;
    s === "/" || (p = b.pathname) != null && p.startsWith(s) || Oe(!1), d = b
  } else d = u;
  let v = d.pathname || "/",
    g = s === "/" ? v : v.slice(s.length) || "/",
    k = wg(e, { pathname: g }),
    C = a1(k && k.map(b => Object.assign({}, b, { params: Object.assign({}, a, b.params), pathname: Mn([s, n.encodeLocation ? n.encodeLocation(b.pathname).pathname : b.pathname]), pathnameBase: b.pathnameBase === "/" ? s : Mn([s, n.encodeLocation ? n.encodeLocation(b.pathnameBase).pathname : b.pathnameBase]) })), i, r || void 0);
  return t && C ? m.createElement(to.Provider, { value: { location: Ta({ pathname: "/", search: "", hash: "", state: null, key: "default" }, d), navigationType: yn.Pop } }, C) : C
}

function i1() {
  let e = d1(),
    t = qg(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
    n = e instanceof Error ? e.stack : null,
    i = { padding: "0.5rem", backgroundColor: "rgba(200,200,200, 0.5)" },
    o = null;
  return m.createElement(m.Fragment, null, m.createElement("h2", null, "Unexpected Application Error!"), m.createElement("h3", { style: { fontStyle: "italic" } }, t), n ? m.createElement("pre", { style: i }, n) : null, o)
}
class l1 extends m.Component { constructor(t) { super(t), this.state = { location: t.location, error: t.error } } static getDerivedStateFromError(t) { return { error: t } } static getDerivedStateFromProps(t, n) { return n.location !== t.location ? { error: t.error, location: t.location } : { error: t.error || n.error, location: n.location } } componentDidCatch(t, n) { console.error("React Router caught the following error during render", t, n) } render() { return this.state.error ? m.createElement(Or.Provider, { value: this.props.routeContext }, m.createElement(Lm.Provider, { value: this.state.error, children: this.props.component })) : this.props.children } }

function o1(e) { let { routeContext: t, match: n, children: r } = e, i = m.useContext(Pm); return i && i.static && i.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = n.route.id), m.createElement(Or.Provider, { value: t }, r) }

function a1(e, t, n) {
  if (t === void 0 && (t = []), e == null)
    if (n != null && n.errors) e = n.matches;
    else return null;
  let r = e,
    i = n == null ? void 0 : n.errors;
  if (i != null) {
    let o = r.findIndex(a => a.route.id && (i == null ? void 0 : i[a.route.id]));
    o >= 0 || Oe(!1), r = r.slice(0, Math.min(r.length, o + 1))
  }
  return r.reduceRight((o, a, s) => {
    let u = a.route.id ? i == null ? void 0 : i[a.route.id] : null,
      d = null;
    n && (a.route.ErrorBoundary ? d = m.createElement(a.route.ErrorBoundary, null) : a.route.errorElement ? d = a.route.errorElement : d = m.createElement(i1, null));
    let p = t.concat(r.slice(0, s + 1)),
      v = () => { let g = o; return u ? g = d : a.route.Component ? g = m.createElement(a.route.Component, null) : a.route.element && (g = a.route.element), m.createElement(o1, { match: a, routeContext: { outlet: o, matches: p }, children: g }) };
    return n && (a.route.ErrorBoundary || a.route.errorElement || s === 0) ? m.createElement(l1, { location: n.location, component: d, error: u, children: v(), routeContext: { outlet: null, matches: p } }) : v()
  }, null)
}
var sc;
(function(e) { e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator" })(sc || (sc = {}));
var Dl;
(function(e) { e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator" })(Dl || (Dl = {}));

function s1(e) { let t = m.useContext(Mm); return t || Oe(!1), t }

function u1(e) { let t = m.useContext(Or); return t || Oe(!1), t }

function c1(e) {
  let t = u1(),
    n = t.matches[t.matches.length - 1];
  return n.route.id || Oe(!1), n.route.id
}

function d1() {
  var e;
  let t = m.useContext(Lm),
    n = s1(Dl.UseRouteError),
    r = c1(Dl.UseRouteError);
  return t || ((e = n.errors) == null ? void 0 : e[r])
}

function za(e) { Oe(!1) }

function m1(e) {
  let { basename: t = "/", children: n = null, location: r, navigationType: i = yn.Pop, navigator: o, static: a = !1 } = e;
  Ri() && Oe(!1);
  let s = t.replace(/^\/*/, "/"),
    u = m.useMemo(() => ({ basename: s, navigator: o, static: a }), [s, o, a]);
  typeof r == "string" && (r = tr(r));
  let { pathname: d = "/", search: p = "", hash: v = "", state: g = null, key: k = "default" } = r, C = m.useMemo(() => { let b = Us(d, s); return b == null ? null : { location: { pathname: b, search: p, hash: v, state: g, key: k }, navigationType: i } }, [s, d, p, v, g, k, i]);
  return C == null ? null : m.createElement(Bi.Provider, { value: u }, m.createElement(to.Provider, { children: n, value: C }))
}

function f1(e) { let { children: t, location: n } = e, r = m.useContext(Pm), i = r && !t ? r.router.routes : Oa(t); return r1(i, n) }
var uc;
(function(e) { e[e.pending = 0] = "pending", e[e.success = 1] = "success", e[e.error = 2] = "error" })(uc || (uc = {}));
new Promise(() => {});

function Oa(e, t) {
  t === void 0 && (t = []);
  let n = [];
  return m.Children.forEach(e, (r, i) => {
    if (!m.isValidElement(r)) return;
    let o = [...t, i];
    if (r.type === m.Fragment) { n.push.apply(n, Oa(r.props.children, o)); return } r.type !== za && Oe(!1), !r.props.index || !r.props.children || Oe(!1);
    let a = { id: r.props.id || o.join("-"), caseSensitive: r.props.caseSensitive, element: r.props.element, Component: r.props.Component, index: r.props.index, path: r.props.path, loader: r.props.loader, action: r.props.action, errorElement: r.props.errorElement, ErrorBoundary: r.props.ErrorBoundary, hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null, shouldRevalidate: r.props.shouldRevalidate, handle: r.props.handle, lazy: r.props.lazy };
    r.props.children && (a.children = Oa(r.props.children, o)), n.push(a)
  }), n
}
/**
 * React Router DOM v6.10.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function _a() { return _a = Object.assign ? Object.assign.bind() : function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, _a.apply(this, arguments) }

function p1(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function h1(e) { return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) }

function g1(e, t) { return e.button === 0 && (!t || t === "_self") && !h1(e) }
const v1 = ["onClick", "relative", "reloadDocument", "replace", "state", "target", "to", "preventScrollReset"];

function y1(e) {
  let { basename: t, children: n, window: r } = e, i = m.useRef();
  i.current == null && (i.current = kg({ window: r, v5Compat: !0 }));
  let o = i.current,
    [a, s] = m.useState({ action: o.action, location: o.location });
  return m.useLayoutEffect(() => o.listen(s), [o]), m.createElement(m1, { basename: t, children: n, location: a.location, navigationType: a.action, navigator: o })
}
const x1 = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u",
  k1 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  b1 = m.forwardRef(function(t, n) {
    let { onClick: r, relative: i, reloadDocument: o, replace: a, state: s, target: u, to: d, preventScrollReset: p } = t, v = p1(t, v1), { basename: g } = m.useContext(Bi), k, C = !1;
    if (typeof d == "string" && k1.test(d) && (k = d, x1)) {
      let f = new URL(window.location.href),
        x = d.startsWith("//") ? new URL(f.protocol + d) : new URL(d),
        w = Us(x.pathname, g);
      x.origin === f.origin && w != null ? d = w + x.search + x.hash : C = !0
    }
    let b = t1(d, { relative: i }),
      N = C1(d, { replace: a, state: s, target: u, preventScrollReset: p, relative: i });

    function y(f) { r && r(f), f.defaultPrevented || N(f) }
    return m.createElement("a", _a({}, v, { href: k || b, onClick: C || o ? r : y, ref: n, target: u }))
  });
var cc;
(function(e) { e.UseScrollRestoration = "useScrollRestoration", e.UseSubmitImpl = "useSubmitImpl", e.UseFetcher = "useFetcher" })(cc || (cc = {}));
var dc;
(function(e) { e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration" })(dc || (dc = {}));

function C1(e, t) {
  let { target: n, replace: r, state: i, preventScrollReset: o, relative: a } = t === void 0 ? {} : t, s = n1(), u = no(), d = Bm(e, { relative: a });
  return m.useCallback(p => {
    if (g1(p, n)) {
      p.preventDefault();
      let v = r !== void 0 ? r : _l(u) === _l(d);
      s(e, { replace: v, state: i, preventScrollReset: o, relative: a })
    }
  }, [u, s, d, r, i, n, e, o, a])
}
const Ei = ke.createContext({ theme: "material", dark: !0, touchRipple: !0 });

function w1(e, t) { return typeof window > "u" ? m.useEffect(e, t) : m.useLayoutEffect(e, t) }
const Rm = (e, t = !0) => {
    const [n, r] = m.useState(e);
    return w1(() => {
      if (t) {
        if (e === "ios" || e === "material") n !== e && r(e);
        else if (n === "parent" && typeof window < "u" && typeof document < "u") {
          const i = document.documentElement;
          i && (i.classList.contains("ios") ? r("ios") : (i.classList.contains("md") || i.classList.contains("material")) && r("material"))
        }
      }
    }, [e]), t ? n : e
  },
  N1 = e => { const { theme: t, dark: n, touchRipple: r = !0, autoThemeDetection: i = !0, children: o } = e, a = Rm(t, i); return l(Ei.Provider, { value: { theme: a, dark: n, touchRipple: r }, children: o }) };

function c(...e) {
  const t = [];
  e.forEach(r => { typeof r == "object" && r.constructor === Object ? Object.keys(r).forEach(i => { r[i] && t.push(i) }) : Array.isArray(r) ? t.push(...r) : typeof r == "function" ? t.push(r()) : r && r.value ? t.push(r.value) : r && t.push(r) });
  const n = [];
  return t.forEach(r => { n.indexOf(r) < 0 && n.push(r) }), n.filter(r => !!r).join(" ")
}
const Se = (e, t = "") => !t || typeof t != "string" ? e : ["static", "relative", "absolute", "fixed", "sticky"].filter(i => t.indexOf(i) >= 0).length > 0 ? "" : e,
  I1 = (e, t, n) => { const { safeAreas: r } = e; return c(t === "ios" && "k-ios", t === "material" && "k-material", "k-app w-full h-full min-h-screen", r && "safe-areas", Se("relative", n), n) },
  Em = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, theme: i = "material", dark: o = !0, touchRipple: a = !0, safeAreas: s = !0, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      k = Rm(i),
      C = I1({ ...e, safeAreas: s }, k, r);
    return l(N1, { theme: k, dark: o, touchRipple: a, autoThemeDetection: !1, children: l(v, { ref: p, className: C, ...g, children: u }) })
  });
Em.displayName = "App";
const _o = (e, t, n) => { if (typeof e == "string") return e; const r = [e.common, e[t]]; return n && e[n] && (typeof e[n] == "string" ? r.push(e[n]) : r.push(e[n].common, e[n][t])), r },
  S1 = (e, t, n) => {
    const r = {},
      i = ["common", "ios", "material"];
    return Object.keys(e).forEach(o => {
      const a = o === "base" ? n : "";
      if (!(typeof e[o] != "string" && Object.keys(e[o]).filter(d => !i.includes(d)).length > 0)) { r[o] = c(_o(e[o], t), a); return } r[o] = {};
      const u = _o(e[o], t);
      r[o].default = c(u, a), Object.keys(e[o]).filter(d => !i.includes(d)).forEach(d => { r[o][d] = c(u, _o(e[o], t, d), a) })
    }), r
  },
  H = ({ ios: e, material: t } = {}) => { let r = m.useContext(Ei).theme || "ios"; return e && (r = "ios"), t && (r = "material"), (i, o) => S1(i, r, o) },
  P1 = (e, t) => ({ base: { common: c("transition-transform z-40 left-1/2 bottom-0 transform -translate-x-1/2 max-w-md w-full overflow-hidden", Se("fixed", t)), ios: "pt-2 px-2 pb-2-safe duration-300", material: "pb-safe last-child-hairline-b-none rounded-t-2xl duration-400 ease-material-in", opened: "", closed: "translate-y-full" }, backdrop: { common: "fixed z-40 w-full h-full left-0 top-0 bg-black bg-opacity-50 duration-300", opened: "", closed: "opacity-0 pointer-events-none" } }),
  Da = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, ios: i, material: o, opened: a, backdrop: s = !0, onBackdropClick: u, children: d, ...p } = e, v = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: v.current }));
    const g = a ? "opened" : "closed",
      k = n,
      C = { ...p },
      N = H({ ios: i, material: o })(P1(e, r), r);
    return h(ut, { children: [s && l("div", { className: N.backdrop[g], onClick: u }), l(k, { ref: v, className: N.base[g], ...C, children: d })] })
  });
Da.displayName = "Actions";
const M1 = e => { const { dividers: t } = e; return { base: { common: "relative", ios: "mt-2 first:mt-0 last-child-hairline-b-none", material: c(t && "hairline-b") } } },
  ul = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, ios: i, material: o, dividers: a = !0, children: s, ...u } = e, d = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: d.current }));
    const p = n,
      v = { ...u },
      k = H({ ios: i, material: o })(M1({ dividers: a, ...e }), r);
    return l(p, { ref: d, className: k.base, ...v, children: s })
  });
ul.displayName = "ActionsGroup";
const fe = ({ ios: e, material: t } = {}) => { let r = m.useContext(Ei).theme || "ios"; return e && (r = "ios"), t && (r = "material"), r };
class L1 {
  constructor(t, n, r) {
    const i = this;
    if (!t) return;
    i.el = t;
    const { left: o, top: a, width: s, height: u } = t.getBoundingClientRect(), d = { x: n - o, y: r - a };
    let p = Math.max((u ** 2 + s ** 2) ** .5, 48);
    const v = t.classList.contains("k-touch-ripple-inset");
    v && (p = Math.max(Math.min(s, u), 48));
    const g = typeof window < "u" && window.getComputedStyle(t, null).getPropertyValue("overflow") === "hidden";
    if (!v && g) {
      const C = ((d.x - s / 2) ** 2 + (d.y - u / 2) ** 2) ** .5,
        b = (p / 2 + C) / (p / 2);
      i.rippleTransform = `translate3d(0px, 0px, 0) scale(${b})`
    } else i.rippleTransform = `translate3d(${-d.x+s/2}px, ${-d.y+u/2}px, 0) scale(1)`;
    i.rippleWaveEl = document.createElement("span"), i.rippleWaveEl.classList.add("k-touch-ripple-wave"), i.rippleWaveEl.setAttribute("hidden", ""), i.rippleWaveEl.style = `
      width: ${p}px;
      height: ${p}px;
      margin-top:-${p/2}px;
      margin-left:-${p/2}px;
      left:${d.x}px;
      top:${d.y}px; --k-ripple-transform: ${i.rippleTransform}`, t.insertAdjacentElement("afterbegin", i.rippleWaveEl);
    const k = () => { i.rippleWaveEl.removeEventListener("animationend", k), i.rippleWaveEl && (i.rippleWaveEl.classList.contains("k-touch-ripple-wave-out") || (i.rippleWaveEl.classList.add("k-touch-ripple-wave-in"), i.shouldBeRemoved && i.out())) };
    return i.rippleWaveEl.addEventListener("animationend", k), i
  }
  destroy() {
    let t = this;
    t.rippleWaveEl && t.el.removeChild(t.rippleWaveEl), Object.keys(t).forEach(n => { t[n] = null, delete t[n] }), t = null
  }
  out() {
    const t = this,
      { rippleWaveEl: n } = this;
    clearTimeout(t.removeTimeout), n.classList.add("k-touch-ripple-wave-out"), t.removeTimeout = setTimeout(() => { t.destroy() }, 300);
    const r = () => { t.rippleWaveEl.removeEventListener("animationend", r), clearTimeout(t.removeTimeout), t.destroy() };
    t.rippleWaveEl.addEventListener("animationend", r)
  }
  remove() {
    const t = this;
    t.shouldBeRemoved || (t.removeTimeout = setTimeout(() => { t.destroy() }, 400), t.shouldBeRemoved = !0, t.rippleWaveEl.classList.contains("k-touch-ripple-wave-in") && t.out())
  }
}
const $t = (e, t, n) => {
    const r = m.useContext(Ei);
    n || (n = e);
    const i = m.useRef(null),
      o = () => { i.current && i.current.remove(), i.current = null },
      a = k => { i.current = new L1(e.current, k.pageX, k.pageY) },
      s = () => { o() },
      u = () => { o() },
      d = () => {
        if (!r.touchRipple) return;
        const k = n.current;
        k.addEventListener("pointerdown", a), k.addEventListener("pointermove", s), k.addEventListener("pointerup", u), k.addEventListener("pointercancel", u), k.addEventListener("contextmenu", u)
      },
      p = () => {
        const k = n.current;
        k.removeEventListener("pointerdown", a), k.removeEventListener("pointermove", s), k.removeEventListener("pointerup", u), k.removeEventListener("pointercancel", u), k.removeEventListener("contextmenu", u)
      },
      v = () => {!n || !n.current || !t || d() },
      g = () => {!n || !n.current || !t || p() };
    m.useEffect(() => (v(), () => g()))
  },
  Y = () => { const e = m.useContext(Ei); return t => e.dark ? t : "" },
  B1 = (e, t, n) => { const { fontSizeIos: r, fontSizeMaterial: i, bold: o, dividers: a } = e; return { base: { common: c("flex items-center w-full px-4 relative z-10 overflow-hidden", a && "hairline-b"), ios: c("h-14", t.textIos, t.bgIos, t.activeBgIos, r, "first:rounded-t-xl last:rounded-b-xl justify-center", o && "font-semibold"), material: c("h-12", t.textMaterial, t.bgMaterial, t.activeBgMaterial, i, "justify-start", n("dark:touch-ripple-white"), o && "font-medium") } } },
  R1 = (e = {}, t) => ({ bgIos: c("bg-white", t("dark:bg-neutral-800")), bgMaterial: c("bg-md-light-surface-3", t("dark:bg-md-dark-surface-3")), activeBgIos: c("active:bg-neutral-200", t("dark:active:bg-neutral-700")), activeBgMaterial: "", textIos: "text-primary", textMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), ...e }),
  Dn = m.forwardRef((e, t) => {
    const { component: n = "button", className: r, colors: i, ios: o, material: a, bold: s, boldIos: u = !1, boldMaterial: d = !1, fontSizeIos: p = "text-xl", fontSizeMaterial: v = "text-base", href: g, touchRipple: k = !0, dividers: C = void 0, children: b, ...N } = e, y = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: y.current }));
    let f = n;
    typeof e.component > "u" && (g || g === "") && (f = "a");
    const x = { href: g, ...N },
      w = fe({ ios: o, material: a }),
      S = H({ ios: o, material: a }),
      I = Y();
    $t(y, w === "material" && k);
    const M = R1(i, I),
      R = S(B1({ fontSizeIos: p, fontSizeMaterial: v, bold: typeof s > "u" ? w === "ios" ? u : d : s, dividers: typeof C > "u" ? w === "ios" : C, ...e }, M, I), r);
    return l(f, { ref: y, role: "button", tabIndex: "0", className: R.base, ...x, children: b })
  });
Dn.displayName = "ActionsButton";
const E1 = (e, t) => { const { fontSizeIos: n, fontSizeMaterial: r, dividers: i } = e; return { base: { common: c(`flex items-center w-full px-4 relative z-10 overflow-hidden ${t.activeBg}`, i && "hairline-b"), ios: c("h-14", t.bgIos, t.textIos, n, "first:rounded-t-xl last:rounded-b-xl justify-center"), material: c("h-12", t.bgMaterial, t.textMaterial, r, "font-medium", "justify-start") } } },
  T1 = (e = {}, t) => ({ bgIos: c("bg-white", t("dark:bg-neutral-800")), bgMaterial: c("bg-md-light-surface-3", t("dark:bg-md-dark-surface-3")), textIos: c("text-black text-opacity-55", t("dark:text-white dark:text-opacity-55")), textMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), ...e }),
  Fa = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, fontSizeIos: s = "text-sm", fontSizeMaterial: u = "text-sm", dividers: d = void 0, children: p, ...v } = e, g = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: g.current }));
    const k = n,
      C = { ...v },
      b = fe({ ios: o, material: a }),
      N = H({ ios: o, material: a }),
      y = Y(),
      f = T1(i, y),
      w = N(E1({ fontSizeIos: s, fontSizeMaterial: u, dividers: typeof d > "u" ? b === "ios" : d, ...e }, f), r);
    return l(k, { ref: g, className: w.base, ...C, children: p })
  });
Fa.displayName = "ActionsLabel";
const z1 = (e, t) => ({ base: { common: `${t.text} ${t.bg} inline-flex items-center justify-center rounded-full leading-none`, ios: "font-semibold", material: "font-medium", sm: "text-2xs min-w-4 min-h-4 px-0.5", md: "text-xs min-w-5 min-h-5 px-1.5 py-0.5" } }),
  O1 = (e = {}) => ({ bg: "bg-primary", text: "text-white", ...e }),
  qn = m.forwardRef((e, t) => {
    const { component: n = "span", className: r, colors: i, small: o, ios: a, material: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      k = H({ ios: a, material: s }),
      C = O1(i),
      b = o ? "sm" : "md",
      N = k(z1(e, C), r);
    return l(v, { ref: p, className: N.base[b], ...g, children: u })
  });
qn.displayName = "Badge";
const _1 = (e, t, n) => { const { inset: r, nested: i, margin: o, padding: a, strong: s, outline: u } = e; return { base: { common: c("text-sm z-10", Se("relative", n), !r && !i && u && "hairline-t hairline-b", r && u && "border", r && "px-4", !r && "pl-4-safe pr-4-safe", !i && o, (s || u) && a), ios: c(t.textIos, s && t.strongBgIos, r && u && t.outlineIos), material: c(t.textMaterial, s && t.strongBgMaterial, r && u && t.outlineMaterial) }, inset: { common: "ml-4-safe mr-4-safe overflow-hidden", ios: "rounded-lg", material: "rounded-2xl" } } },
  D1 = (e = {}, t) => ({ outlineIos: c("border-black border-opacity-20", t("dark:border-white dark:border-opacity-15")), outlineMaterial: c("border-md-light-outline", t("border-md-dark-outline")), strongBgIos: c("bg-ios-light-surface-1", t("dark:bg-ios-dark-surface-1")), strongBgMaterial: c("bg-md-light-surface-1", t("dark:bg-md-dark-surface-1")), textIos: "", textMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), ...e }),
  D = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, margin: o = "my-8", padding: a = "py-4", inset: s, insetIos: u, insetMaterial: d, strong: p, strongIos: v, strongMaterial: g, outline: k, outlineIos: C, outlineMaterial: b, nested: N, ios: y, material: f, children: x, ...w } = e, S = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: S.current }));
    const I = n,
      M = { ...w },
      L = fe({ ios: y, material: f }),
      B = H({ ios: y, material: f }),
      R = Y(),
      _ = D1(i, R),
      q = typeof p > "u" ? L === "ios" ? v : g : p,
      V = typeof k > "u" ? L === "ios" ? C : b : k,
      X = typeof s > "u" ? L === "ios" ? u : d : s,
      ue = B(_1({ ...e, margin: o, padding: a, inset: X, strong: q, outline: V }, _, r)),
      ee = c(ue.base, X && ue.inset, r);
    return l(I, { ref: S, className: ee, ...M, children: x })
  });
D.displayName = "Block";
const F1 = (e, t) => { const { inset: n } = e; return { base: { common: c("mb-8 flex items-center -mt-6 text-sm", n ? "pl-8-safe pr-8-safe" : "pl-4-safe pr-4-safe"), ios: t.textIos, material: t.textMaterial } } },
  j1 = (e = {}, t) => ({ textIos: c("text-black text-opacity-75", t("dark:text-white dark:text-opacity-75")), textMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), ...e }),
  Tm = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, inset: s, insetIos: u, insetMaterial: d, children: p, ...v } = e, g = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: g.current }));
    const k = fe(),
      C = typeof s > "u" ? k === "ios" ? u : d : s,
      b = n,
      N = { ...v },
      y = H({ ios: o, material: a }),
      f = Y(),
      x = j1(i, f),
      w = y(F1({ ...e, inset: C }, x), r);
    return l(b, { ref: g, className: w.base, ...N, children: p })
  });
Tm.displayName = "BlockFooter";
const $1 = (e, t) => { const { inset: n } = e; return { base: { common: c("mt-8 flex items-center -mb-6 text-sm", n ? "pl-8-safe pr-8-safe" : "pl-4-safe pr-4-safe"), ios: t.textIos, material: t.textMaterial } } },
  A1 = (e = {}, t) => ({ textIos: c("text-black", t("dark:text-white")), textMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), ...e }),
  Jn = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, inset: s, insetIos: u, insetMaterial: d, children: p, ...v } = e, g = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: g.current }));
    const k = n,
      C = { ...v },
      b = fe(),
      N = typeof s > "u" ? b === "ios" ? u : d : s,
      y = H({ ios: o, material: a }),
      f = Y(),
      x = A1(i, f),
      w = y($1({ ...e, inset: N }, x), r);
    return l(k, { ref: g, className: w.base, ...C, children: p })
  });
Jn.displayName = "BlockHeader";
const H1 = (e, t) => { const { withBlock: n, medium: r, large: i } = e; return { base: { common: `pl-4-safe pr-4-safe mt-8 flex justify-between items-center ${n?"-mb-6":"mb-2"}`, ios: c(`font-semibold ${t.textIos}`, i && "text-[1.5rem]", r && "text-[1.125rem]", !r && !i && "text-[1rem]"), material: c(`font-medium ${t.textMaterial}`, i && "text-[1.375rem]", r && "text-[1rem]", !r && !i && "text-[0.875rem]") } } },
  q1 = (e = {}, t) => ({ textIos: "", textMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), ...e }),
  z = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, withBlock: o = !0, medium: a, large: s, ios: u, material: d, children: p, ...v } = e, g = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: g.current }));
    const k = n,
      C = { ...v },
      b = H({ ios: u, material: d }),
      N = Y(),
      y = q1(i, N),
      f = b(H1({ ...e, withBlock: o }, y), r);
    return l(k, { ref: g, className: f.base, ...C, children: p })
  });
z.displayName = "BlockTitle";
const U1 = e => { const { fontSizeIos: t, fontSizeMaterial: n } = e; return { base: { common: "flex items-center justify-start overflow-auto whitespace-nowrap py-1 px-0 space-x-3 no-scrollbar rtl:space-x-reverse", ios: t, material: n } } },
  cl = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, fontSizeIos: i = "text-[17px]", fontSizeMaterial: o = "text-[14px]", ios: a, material: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      C = H({ ios: a, material: s })(U1({ ...e, fontSizeIos: i, fontSizeMaterial: o }), r);
    return l(v, { ref: p, className: C.base, ...g, children: u })
  });
cl.displayName = "Breadcrumbs";
const W1 = (e, t) => { const { active: n } = e; return { base: { common: c("flex items-center overflow-hidden"), ios: c(t.textIos, t.bgIos, n ? t.textActiveIos : t.textIos, n && "font-semibold"), material: c("font-medium px-2 py-1 rounded-lg", t.bgMaterial, n ? t.textActiveMaterial : t.textMaterial) } } },
  V1 = (e = {}, t) => ({ textIos: c("text-black text-opacity-55", t("dark:text-white dark:text-opacity-55")), textMaterial: c("text-md-light-on-secondary-container", t("dark:text-md-dark-on-secondary-container")), bgIos: "", bgMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), textActiveIos: c("text-black", t("dark:text-white")), textActiveMaterial: c("text-md-light-on-secondary-container", t("dark:text-md-dark-on-secondary-container")), ...e }),
  Rt = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, ios: i, material: o, colors: a, active: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      k = H({ ios: i, material: o }),
      C = Y(),
      b = V1(a, C),
      N = k(W1({ ...e }, b), r);
    return l(v, { ref: p, className: N.base, role: "menuitem", tabIndex: "0", ...g, children: u })
  });
Rt.displayName = "BreadcrumbsItem";
const Q1 = () => ({ base: { common: "w-3 opacity-35 flex justify-center", ios: "", material: "" }, icon: { common: "rtl:rotate-180", ios: "h-3", material: "h-2.5" } }),
  zm = e => l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "8", height: "14", viewBox: "0 0 12 20", fill: "currentcolor", ...e, children: l("path", { d: "M11.518406,10.5648622 C11.4831857,10.6163453 11.4426714,10.6653692 11.3968592,10.7111814 L2.5584348,19.5496058 C1.9753444,20.1326962 1.03186648,20.1345946 0.44199608,19.5447242 C-0.14379032,18.9589377 -0.14922592,18.0146258 0.43711448,17.4282854 L7.87507783,9.9903221 L0.4431923,2.5584366 C-0.1398981,1.9753462 -0.1417965,1.0318683 0.448074,0.4419979 C1.0338604,-0.1437886 1.9781723,-0.1492241 2.56451268,0.4371163 L11.4029371,9.2755407 C11.7556117,9.6282153 11.7969345,10.1725307 11.518406,10.5648622 Z" }) }),
  Zt = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, ios: i, material: o, children: a, ...s } = e, u = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: u.current }));
    const d = n,
      p = { ...s },
      g = H({ ios: i, material: o })(Q1({ ...e }), r);
    return h(d, { ref: u, className: g.base, ...p, children: [l(zm, { className: g.icon }), a] })
  });
Zt.displayName = "BreadcrumbsSeparator";
const Y1 = (e, t) => ({ base: { common: `flex items-center cursor-pointer space-x-0.75 rtl:space-x-reverse ${t.bg}`, ios: c("rounded active:opacity-30 px-1.5 h-[1em] duration-300 active:duration-0", t.bgIos), material: c("py-3 px-2 rounded-lg", t.bgMaterial) }, dot: { common: `w-1 h-1 rounded-full ${t.dotBg}`, ios: t.dotBgIos, material: t.dotBgMaterial } }),
  K1 = (e = {}, t) => ({ bgIos: c("bg-black bg-opacity-15", t("dark:bg-white dark:bg-opacity-15")), bgMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), dotBgIos: c("bg-black", t("dark:bg-white")), dotBgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), ...e }),
  Om = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, children: s, ...u } = e, d = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: d.current }));
    const p = Y(),
      v = K1(i, p),
      g = n,
      k = { ...u },
      b = H({ ios: o, material: a })(Y1({ ...e }, v), r);
    return h(g, { ref: d, role: "button", tabIndex: "0", className: b.base, ...k, children: [l("span", { className: b.dot }), l("span", { className: b.dot }), l("span", { className: b.dot }), s] })
  });
Om.displayName = "BreadcrumbsCollapsed";
const Z1 = (e, t, n, r) => { const { inline: i, segmented: o, segmentedStrong: a, segmentedActive: s, disabled: u } = e; return { base: { common: c("flex text-center justify-center items-center appearance-none py-1 transition-colors focus:outline-none cursor-pointer select-none overflow-hidden z-10", i ? "inline-flex" : "w-full flex", Se("relative", n), u && "pointer-events-none", a && s && "k-segmented-strong-button-active"), ios: "uppercase duration-100 font-semibold px-2", material: "duration-300 font-medium px-4", square: { ios: o && !a ? "first:rounded-s last:rounded-e" : "rounded", material: o && !a ? "first:rounded-lg-s last:rounded-lg-e" : "rounded-lg" }, rounded: o && !a ? "" : "rounded-full" }, style: { fill: { common: c(u && c(t.disabledBg, t.disabledText)), ios: c(u ? c(t.disabledBg, t.disabledText) : `${t.fillTextIos} ${t.fillBgIos} ${t.fillActiveBgIos}`), material: c(u ? c(t.disabledBg, t.disabledText) : c(t.fillTextMaterial, t.fillBgMaterial, t.fillActiveBgMaterial, t.fillTouchRipple)) }, outline: { common: c(u ? c(t.disabledText, t.disabledBorder) : c("active:bg-opacity-15", t.touchRipple)), ios: c(!o && "border-2", !u && !o && t.outlineBorderIos, !u && c(t.textIos, t.activeBgIos)), material: c(!o && "border", !u && !o && t.outlineBorderMaterial, !u && c(t.textMaterial, t.activeBgMaterial)) }, clear: { common: c(u ? t.disabledText : `active:bg-opacity-15 ${t.touchRipple}`), ios: !u && c(t.textIos, t.activeBgIos), material: !u && c(t.textMaterial, t.activeBgMaterial) }, tonal: { common: u ? c(t.disabledBg, t.disabledText) : c(t.touchRipple), ios: !u && c(t.tonalTextIos, t.tonalBgIos, t.activeBgIos, "bg-opacity-15 active:bg-opacity-25"), material: !u && c(t.tonalTextMaterial, t.tonalBgMaterial, t.activeBgMaterial) }, segmentedStrong: c("active:bg-black active:bg-opacity-10", r("dark:active:bg-white dark:active:bg-opacity-5 dark:touch-ripple-white")), segmentedStrongActive: "duration-0" }, size: { small: { ios: "text-xs h-7", material: "text-sm h-8" }, medium: { common: "text-sm", ios: "h-7", material: "h-10" }, large: { ios: "h-11", material: "h-12" } }, raised: "shadow active:shadow-lg" } },
  G1 = (e = {}, t) => ({ activeBgIos: "active:bg-primary", activeBgMaterial: "", textIos: "text-primary", textMaterial: c("text-md-light-primary", "dark:text-md-dark-primary"), fillTextIos: c("text-white"), fillTextMaterial: c("text-md-light-on-primary", t("dark:text-md-dark-on-primary")), fillActiveBgIos: "active:bg-ios-primary-shade", fillActiveBgMaterial: "", fillBgIos: "bg-primary", fillBgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), fillTouchRipple: c("touch-ripple-white", "dark:touch-ripple-primary"), outlineBorderIos: "border-primary", outlineBorderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), tonalBgIos: "bg-primary", tonalBgMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), tonalTextIos: "text-primary", tonalTextMaterial: c("text-md-light-on-secondary-container", t("dark:text-md-dark-on-secondary-container")), touchRipple: "touch-ripple-primary", disabledText: c("text-black text-opacity-30", t("dark:text-white dark:text-opacity-30")), disabledBg: c("bg-black bg-opacity-10", t("dark:bg-white dark:bg-opacity-10")), disabledBorder: c("border-black border-opacity-10", t("dark:border-white dark:border-opacity-10")), ...e }),
  O = m.forwardRef((e, t) => {
    const { component: n = "button", className: r, colors: i, ios: o, material: a, disabled: s, href: u, outline: d, outlineIos: p, outlineMaterial: v, clear: g, clearIos: k, clearMaterial: C, tonal: b, tonalIos: N, tonalMaterial: y, rounded: f, roundedIos: x, roundedMaterial: w, small: S, smallIos: I, smallMaterial: M, large: L, largeIos: B, largeMaterial: R, raised: _, raisedIos: q, raisedMaterial: V, inline: X, segmented: ue, segmentedStrong: ee, segmentedActive: ie, touchRipple: T = !0, children: j, ...$ } = e, G = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: G.current }));
    let J = n;
    typeof e.component > "u" && (u || u === "") && (J = "a");
    const Me = { href: u, ...$ },
      ce = fe({ ios: o, material: a }),
      de = H({ ios: o, material: a }),
      Ce = Y();
    $t(G, ce === "material" && T);
    const _e = (je => { const ct = {}; return Object.keys(je).forEach(dt => { ct[dt] = typeof je[dt] > "u" ? ce === "ios" ? e[`${dt}Ios`] : e[`${dt}Material`] : je[dt] }), ct })({ outline: d, clear: g, tonal: b, rounded: f, small: S, large: L, raised: _ }),
      ve = _e.large ? "large" : _e.small ? "small" : "medium";
    let qe = _e.outline ? "outline" : _e.clear || ue && !ie ? "clear" : _e.tonal ? "tonal" : "fill";
    ee && (qe = "segmentedStrong"), ee && ie && (qe = "segmentedStrongActive");
    const Mt = G1(i, Ce),
      Ze = de(Z1({ ...e, ..._e }, Mt, r, Ce)),
      yt = c(Ze.base[_e.rounded ? "rounded" : "square"], Ze.style[qe], Ze.size[ve], _e.raised && Ze.raised, r);
    return l(J, { ref: G, className: yt, disabled: s, role: "button", tabIndex: "0", ...Me, children: j })
  });
O.displayName = "Button";
const J1 = (e, t) => { const { margin: n, headerDivider: r, footerDivider: i, contentWrapPadding: o } = e; return { base: { common: c(n, "overflow-hidden"), ios: c("rounded-lg", t.bgIos, t.textIos), material: c("rounded-2xl", t.bgMaterial, t.textMaterial), plain: "", raised: "shadow", outline: { common: c("border"), ios: t.outlineIos, material: t.outlineMaterial } }, header: { common: c(r && "border-b", "p-4"), ios: c(r && t.outlineIos, e.headerFontSizeIos), material: c(r && t.outlineMaterial, e.headerFontSizeMaterial) }, content: c(o, "text-sm"), footer: { common: c(r && "border-t", "text-sm p-4"), ios: c(t.footerTextIos, i && t.outlineIos), material: c(t.footerTextMaterial, i && t.outlineMaterial) } } },
  X1 = (e = {}, t) => ({ textIos: c(""), textMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), bgIos: c("bg-ios-light-surface-1", t("dark:bg-ios-dark-surface-1")), bgMaterial: c("bg-md-light-surface-1", t("dark:bg-md-dark-surface-1")), footerTextIos: c("text-black text-opacity-55", t("dark:text-white dark:text-opacity-55")), footerTextMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), outlineIos: c("border-black border-opacity-20", t("dark:border-white dark:border-opacity-20")), outlineMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), ...e }),
  Je = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, margin: i = "m-4", colors: o, header: a, footer: s, ios: u, material: d, headerFontSizeIos: p = "text-[17px]", headerFontSizeMaterial: v = "text-[22px]", contentWrap: g = !0, contentWrapPadding: k = "p-4", raised: C, raisedIos: b, raisedMaterial: N, outline: y, outlineIos: f, outlineMaterial: x, headerDivider: w = !1, footerDivider: S = !1, children: I, ...M } = e, L = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: L.current }));
    const B = n,
      R = { ...M },
      _ = fe(),
      q = H({ ios: u, material: d }),
      V = Y(),
      X = X1(o, V),
      ue = typeof y > "u" ? _ === "ios" ? f : x : y,
      ee = typeof C > "u" ? _ === "ios" ? b : N : C,
      ie = ue ? "outline" : ee ? "raised" : "plain",
      T = q(J1({ ...e, margin: i, contentWrapPadding: k, headerDivider: w, footerDivider: S, headerFontSizeIos: p, headerFontSizeMaterial: v, outline: ue, raised: ee }, X), r);
    return h(B, { ref: L, className: T.base[ie], ...R, children: [a && l("div", { className: T.header, children: a }), g ? l("div", { className: T.content, children: I }) : I, s && l("div", { className: T.footer, children: s })] })
  });
Je.displayName = "Card";
const e0 = (e, t, n, r) => ({ base: c("cursor-pointer inline-flex align-middle", Se("relative", n), r("dark:touch-ripple-white")), iconWrap: { common: c("flex items-center justify-center text-white", r("dark:text-black")), ios: "w-5.5 h-5.5 rounded-full border", material: "w-4.5 h-4.5 rounded-sm border-2", notChecked: { ios: t.borderIos, material: t.borderMaterial }, checked: { ios: `${t.bgCheckedIos} ${t.borderCheckedIos}`, material: `${t.bgCheckedMaterial} ${t.borderCheckedMaterial}` } }, icon: { notChecked: "opacity-0", checked: "opacity-100" }, indeterminateIcon: { common: c("bg-white w-3/4", r("dark:bg-black")), ios: "h-0.5 rounded-full", material: "h-0.5" }, input: "hidden" }),
  t0 = (e = {}, t) => ({ borderIos: c("border-black border-opacity-30", t("dark:border-white dark:border-opacity-30")), borderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), bgCheckedIos: "bg-primary", bgCheckedMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), borderCheckedIos: "border-primary", borderCheckedMaterial: c("border-md-light-primary", t("dark:border-md-dark-primary")), ...e }),
  _m = e => { const { ios: t, material: n, fill: r, ...i } = e; return fe({ ios: t, material: n }) === "ios" ? l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 20 20", fill: "currentcolor", ...i, children: l("path", { fill: r || "currentColor", fillRule: "evenodd", d: "M10.6461792,0.119820016 C11.0022676,0.346673312 11.1070333,0.819240884 10.88018,1.17532923 L5.59004012,9.47918548 C5.44456028,9.70754308 5.19802823,9.83254199 4.94596825,9.83309245 C4.59813173,9.83364386 4.39457446,9.67360825 4.28105047,9.53831563 L1.17887189,5.84128316 C0.907480501,5.5178515 0.949667479,5.03565214 1.27309914,4.76426075 C1.59653081,4.49286936 2.07873017,4.53505633 2.35012156,4.858488 L4.8346263,7.81909046 L9.59067001,0.353820775 C9.81752331,-0.00226757161 10.2900909,-0.10703328 10.6461792,0.119820016 Z", transform: "translate(4 5.483)" }) }) : l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "14", height: "14", viewBox: "0 0 18 14", fill: "currentcolor", ...i, children: l("polygon", { fill: r, points: "6 11.17 1.83 7 .41 8.41 6 14 18 2 16.59 .59" }) }) },
  bt = m.forwardRef((e, t) => {
    const { component: n = "label", className: r, colors: i, defaultChecked: o, checked: a, indeterminate: s, name: u, value: d, disabled: p, readOnly: v, onChange: g, ios: k, material: C, touchRipple: b = !0, children: N, ...y } = e, f = m.useRef(null), x = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: x.current, inputEl: f.current }));
    const w = n,
      S = { ...y },
      I = fe({ ios: k, material: C }),
      M = H({ ios: k, material: C }),
      L = Y();
    $t(x, I === "material" && b);
    const B = t0(i, L),
      R = a || o && !g || s ? "checked" : "notChecked",
      _ = M(e0(e, B, r, L), r);
    return m.useEffect(() => { f.current && (f.current.indeterminate = !!s) }, [s]), h(w, { ref: x, className: _.base, ...S, children: [l("input", { ref: f, type: "checkbox", name: u, value: d, disabled: p, readOnly: v, checked: a, defaultChecked: o, onChange: g, className: _.input }), l("i", { className: _.iconWrap[R], children: s ? l("span", { className: _.indeterminateIcon }) : l(_m, { ios: k, material: C, className: _.icon[R] }) }), N] })
  });
bt.displayName = "Checkbox";
const n0 = (e, t) => ({ base: { common: "text-sm inline-flex items-center justify-center align-middle rounded-full px-3", ios: "rounded-full h-7", material: "rounded-lg h-8 font-medium", fill: { ios: c(t.fillBg || t.fillBgIos, t.fillText || t.fillTextIos), material: c(t.fillBg || t.fillBgMaterial, t.fillText || t.fillTextMaterial) }, outline: { common: "border", ios: c(t.outlineText || t.outlineTextIos, t.outlineBorder || t.outlineBorderIos), material: c(t.outlineText || t.outlineTextMaterial, t.outlineBorder || t.outlineBorderMaterial) } }, media: { common: "-my-1 me-1 select-none", ios: "-ms-3", material: "-ms-2" }, deleteButton: "-me-2 -my-1 ms-1 h-full flex items-center justify-center w-6 cursor-pointer opacity-50 active:opacity-100 select-none" }),
  r0 = (e = {}, t) => ({ fillTextIos: "text-current", fillTextMaterial: c("text-md-light-on-secondary-container", t("dark:text-md-dark-on-secondary-container")), fillBgIos: c("bg-black bg-opacity-10", t("dark:bg-white dark:bg-opacity-10")), fillBgMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), outlineTextIos: c("text-current"), outlineTextMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), outlineBorderIos: c("border-black border-opacity-20", t("dark:border-white dark:border-opacity-20")), outlineBorderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), ...e }),
  Ni = ({ theme: e, ...t }) => e === "ios" ? l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "28", height: "28", viewBox: "0 0 28 28", fill: "currentcolor", ...t, children: l("path", { d: "M14,0 C21.7319865,0 28,6.2680135 28,14 C28,21.7319865 21.7319865,28 14,28 C6.2680135,28 0,21.7319865 0,14 C0,6.2680135 6.2680135,0 14,0 Z M18.9393398,6.93933983 L14,11.8786797 L9.06066017,6.93933983 L6.93933983,9.06066017 L11.8786797,14 L6.93933983,18.9393398 L9.06066017,21.0606602 L14,16.1213203 L18.9393398,21.0606602 L21.0606602,18.9393398 L16.1213203,14 L21.0606602,9.06066017 L18.9393398,6.93933983 Z" }) }) : l("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", ...t, children: l("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M12 2C6.47 2 2 6.47 2 12C2 17.53 6.47 22 12 22C17.53 22 22 17.53 22 12C22 6.47 17.53 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20ZM12 10.59L15.59 7L17 8.41L13.41 12L17 15.59L15.59 17L12 13.41L8.41 17L7 15.59L10.59 12L7 8.41L8.41 7L12 10.59Z", fill: "currentcolor" }) }),
  pe = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, media: o, deleteButton: a, onDelete: s, ios: u, material: d, outline: p, children: v, ...g } = e, k = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: k.current }));
    const C = n,
      b = { ...g },
      N = H({ ios: u, material: d }),
      y = fe({ ios: u, material: d }),
      f = Y(),
      x = p ? "outline" : "fill",
      w = r0(i, f),
      S = N(n0(e, w), r);
    return h(C, { ref: k, className: S.base[x], ...b, children: [o && l("div", { className: S.media, children: o }), v, a && l("div", { className: S.deleteButton, role: "button", tabIndex: "0", onClick: s, children: l(Ni, { theme: y, className: "h-4 w-4" }) })] })
  });
pe.displayName = "Chip";
const i0 = (e, t, n, { hasButtons: r }) => { const { titleFontSizeMaterial: i, titleFontSizeIos: o, translucent: a, sizeIos: s, sizeMaterial: u } = e; return { base: { common: c("left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-40 max-h-full overflow-hidden duration-400", Se("fixed", n)), ios: c("rounded-xl max-w-full", s, t.bgIos, a && "translucent"), material: c("rounded-[1.75rem] p-6 max-w-[90%]", u, t.bgMaterial), opened: "", closed: "scale-[0.85] opacity-0 pointer-events-none" }, contentWrap: { common: "flex flex-col items-center justify-center", material: "space-y-3", ios: c("p-4 space-y-1 relative", r && "hairline-b") }, title: { common: c("w-full"), ios: c(t.titleIos, o, "font-semibold text-center"), material: c(t.titleMaterial, i) }, content: { common: c("text-sm w-full"), ios: c(t.contentTextIos, "text-center"), material: c(t.contentTextMaterial) }, buttons: { common: "flex items-center", ios: c("justify-center last-child-hairline-r-none"), material: c("justify-end pt-6 space-x-2 rtl:space-x-reverse") }, backdrop: { common: "fixed z-40 w-full h-full left-0 top-0 bg-black bg-opacity-50 duration-400", opened: "", closed: "opacity-0 pointer-events-none" } } },
  l0 = (e = {}, t) => ({ bgIos: c("bg-white", t("dark:bg-neutral-800")), bgMaterial: c("bg-md-light-surface-3", t("dark:bg-md-dark-surface-3")), titleIos: "", titleMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), contentTextIos: "", contentTextMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), ...e }),
  yr = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, opened: o, backdrop: a = !0, onBackdropClick: s, translucent: u = !0, sizeIos: d = "w-[16.875rem]", sizeMaterial: p = "w-[19.5rem]", titleFontSizeIos: v = "text-[18px]", titleFontSizeMaterial: g = "text-[24px]", title: k, content: C, buttons: b, ios: N, material: y, children: f, ...x } = e, w = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: w.current }));
    const S = o ? "opened" : "closed",
      I = n,
      M = { ...x },
      L = H({ ios: N, material: y }),
      B = Y(),
      R = l0(i, B),
      _ = L(i0({ ...e, titleFontSizeIos: v, titleFontSizeMaterial: g, translucent: u, sizeIos: d, sizeMaterial: p }, R, r, { hasButtons: !!b }), r);
    return h(ut, { children: [a && l("div", { className: _.backdrop[S], onClick: s }), h(I, { ref: w, className: _.base[S], ...M, children: [h("div", { className: _.contentWrap, children: [k && l("div", { className: _.title, children: k }), (C || f) && h("div", { className: _.content, children: [C, f] })] }), b && l("div", { className: _.buttons, children: b })] })] })
  });
yr.displayName = "Dialog";
const o0 = (e, t) => { const { strong: n, disabled: r } = e; return { base: { ios: c("text-center text-[17px] flex items-center justify-center h-11 w-full hairline-r rtl:hairline-l relative first:rounded-bl-xl last:rounded-br-xl rtl:first:rounded-br-xl rtl:first:rounded-bl-none rtl:last:rounded-bl-xl rtl:last:rounded-br-none", r ? t.disabledTextIos : t.textIos, n && "font-semibold", !r && t.activeBgIos) } } },
  a0 = (e = {}, t) => ({ activeBgIos: c("active:bg-black active:bg-opacity-10", t("dark:active:bg-white dark:active:bg-opacity-10")), textIos: "text-primary", disabledTextIos: c("text-black text-opacity-30", t("dark:text-white dark:text-opacity-30")), ...e }),
  fn = m.forwardRef((e, t) => {
    const { component: n = "button", className: r, colors: i, ios: o, material: a, disabled: s, strong: u, strongIos: d, strongMaterial: p, children: v, ...g } = e, k = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: k.current }));
    const C = { ...g },
      b = fe({ ios: o, material: a }),
      N = H({ ios: o, material: a }),
      y = Y(),
      f = a0(i, y),
      x = typeof u > "u" ? b === "ios" ? d : p : u,
      w = N(o0({ ...e, strong: x }, f), r),
      S = n;
    return b === "ios" ? l(S, { className: w.base, disabled: s, role: "button", tabIndex: "0", ...C, children: v }) : l(O, { component: n, inline: !0, rounded: !0, disabled: s, clear: !x, className: r, ...C, children: v })
  });
fn.displayName = "DialogButton";
const s0 = (e, t) => ({ base: { common: "flex items-center justify-center space-x-2 rtl:!space-x-reverse cursor-pointer overflow-hidden select-none", ios: `h-12 duration-100 rounded-full shadow-lg ${t.bgIos} ${t.activeBgIos} ${t.textIos}`, material: `duration-300 rounded-2xl shadow ${t.bgMaterial} ${t.activeBgMaterial} ${t.textMaterial} ${t.touchRipple}`, iconOnly: { ios: "w-12", material: "w-14 h-14" }, withText: { common: "px-4", material: "h-14" } }, text: { common: "text-sm", ios: "font-semibold uppercase", material: "font-medium" }, icon: { common: "h-1em w-1em", ios: "text-icon-ios", material: "text-icon-material" } }),
  u0 = (e = {}, t) => ({ bgIos: "bg-primary", bgMaterial: c("bg-md-light-primary-container", t("dark:bg-md-dark-primary-container")), activeBgIos: "active:bg-ios-primary-shade", activeBgMaterial: "", textIos: "text-white", textMaterial: c("text-md-light-on-primary-container", t("dark:text-md-dark-on-primary-container")), touchRipple: c("touch-ripple-primary", t("dark:touch-ripple-white")), ...e }),
  Fn = m.forwardRef((e, t) => {
    const { component: n = "a", className: r, colors: i, href: o, text: a, textPosition: s = "after", icon: u, ios: d, material: p, touchRipple: v = !0, children: g, ...k } = e, C = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: C.current }));
    const b = n,
      N = { ...k },
      y = fe({ ios: d, material: p }),
      f = H({ ios: d, material: p }),
      x = Y();
    $t(C, y === "material" && v);
    const w = u0(i, x),
      S = f(s0(e, w), r);
    return h(b, { className: a ? S.base.withText : S.base.iconOnly, href: o, ref: C, role: "button", tabIndex: "0", ...N, children: [a && s === "before" && l("span", { className: S.text, children: a }), u && l("span", { className: S.icon, children: u }), a && s === "after" && l("span", { className: S.text, children: a }), g] })
  });
Fn.displayName = "Fab";
const c0 = (e, t) => ({ base: `${Se("relative",t)} inline-block not-italic`, badge: "absolute -end-1.5 -top-0.5" }),
  Vt = m.forwardRef((e, t) => {
    const { component: n = "i", className: r, ios: i, material: o, badge: a, badgeColors: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      k = H(),
      C = fe(),
      b = k(c0(e, r), r);
    return h(v, { ref: p, className: b.base, ...g, children: [C === "ios" ? i : o, typeof a < "u" && a !== null && l(qn, { small: !0, className: b.badge, colors: s, children: a }), u] })
  });
Vt.displayName = "Icon";
const d0 = (e, { textColor: t, needsTouchRipple: n }, r) => { const { iconOnly: i, tabbar: o } = e; return { base: { common: c(!o && t, "inline-flex space-x-1 rtl:!space-x-reverse justify-center items-center cursor-pointer select-none", n && `touch-ripple-primary ${Se("relative",r)} z-10`), notTabbar: { ios: "active:opacity-30 duration-300 active:duration-0", material: n ? "" : "active:opacity-55" } }, tabbar: { common: c(Se("relative", r), "w-full h-full duration-300"), material: "font-medium text-sm z-10", active: "k-tabbar-link-active", inactive: "" }, toolbar: { common: c("h-full max-h-12", i && "k-touch-ripple-inset"), material: "px-3 text-sm font-medium" }, navbar: { common: c("h-full max-h-12", i && "k-touch-ripple-inset"), material: "px-3" } } },
  m0 = (e = {}, t) => ({ textIos: "text-primary", textMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), navbarTextIos: "text-primary", navbarTextMaterial: "", ...e }),
  te = m.forwardRef((e, t) => {
    const { component: n = "a", className: r, colors: i, navbar: o, toolbar: a, iconOnly: s, linkProps: u = {}, tabbar: d, tabbarActive: p, touchRipple: v = void 0, ios: g, material: k, onClick: C, children: b, ...N } = e, y = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: y.current }));
    const f = n,
      x = { ...u, ...N },
      w = fe({ ios: g, material: k }),
      S = H({ ios: g, material: k }),
      I = Y(),
      M = w === "material" && (v || (a || d || o) && typeof v > "u");
    $t(y, M);
    const L = m0(i, I),
      B = e.navbar ? w === "material" ? L.navbarTextMaterial : L.navbarTextIos : w === "material" ? L.textMaterial : L.textIos,
      R = d && !p ? L.tabbarInactive : B,
      _ = p ? "active" : "inactive",
      q = S(d0(e, { textColor: R, needsTouchRipple: M }, r)),
      V = c(q.base[d ? "default" : "notTabbar"], a && q.toolbar, o && q.navbar, d && q.tabbar[_], r);
    return l(f, { ref: y, className: V, ...x, role: "link", tabIndex: "0", onClick: C, children: b })
  });
te.displayName = "Link";
const f0 = (e, t, n) => { const { nested: r, margin: i, inset: o, strong: a, outline: s } = e; return { base: { common: c(!r && i, !o && !r && s && "hairline-t hairline-b", o && s && "border", Se("relative", n), "z-10"), ios: c(a && t.strongBgIos, o && s && t.outlineIos), material: c(a && t.strongBgMaterial, o && s && t.outlineMaterial) }, ul: { common: c(o && "no-safe-areas", "last-child-hairline-b-none") }, inset: { common: "ml-4-safe mr-4-safe overflow-hidden", ios: "rounded-lg", material: "rounded-2xl" }, menuList: { common: "py-1" } } },
  p0 = (e = {}, t) => ({ outlineIos: c("border-black border-opacity-20", t("dark:border-white dark:border-opacity-15")), outlineMaterial: c("border-md-light-outline", t("border-md-dark-outline")), strongBgIos: c("bg-ios-light-surface-1", t("dark:bg-ios-dark-surface-1")), strongBgMaterial: c("bg-md-light-surface-1", t("dark:bg-md-dark-surface-1")), ...e }),
  Dm = ke.createContext(!1),
  U = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, margin: o = "my-8", nested: a, menuList: s, dividers: u, dividersIos: d = !0, dividersMaterial: p = !1, inset: v, insetIos: g, insetMaterial: k, strong: C, strongIos: b, strongMaterial: N, outline: y, outlineIos: f, outlineMaterial: x, ios: w, material: S, children: I, ...M } = e, L = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: L.current }));
    const B = n,
      R = { ...M },
      _ = fe(),
      q = H({ ios: w, material: S }),
      V = Y(),
      X = typeof u > "u" ? _ === "ios" ? d : p : u,
      ue = typeof C > "u" ? _ === "ios" ? b : N : C,
      ee = typeof y > "u" ? _ === "ios" ? f : x : y,
      ie = typeof v > "u" ? _ === "ios" ? g : k : v,
      T = p0(i, V),
      j = q(f0({ ...e, margin: o, inset: ie, strong: ue, outline: ee }, T, r)),
      $ = c(j.base, ie && j.inset, s && j.menuList, r);
    return l(Dm.Provider, { value: X, children: l(B, { ref: L, className: $, ...R, children: l("ul", { className: j.ul, children: I }) }) })
  });
U.displayName = "List";
const xn = m.forwardRef((e, t) => {
  const { children: n, ...r } = e, i = m.useRef(null);
  m.useImperativeHandle(t, () => ({ el: i.current }));
  const o = { ...r };
  return l("li", { ref: i, children: l(U, { nested: !0, ...o, children: n }) })
});
xn.displayName = "ListGroup";
const h0 = (e, t, n) => { const { dividers: r } = e; return { base: "", button: { common: c(Se("relative", n), r && "hairline-b active:hairline-transparent", `flex items-center justify-center px-4 space-x-1 w-full duration-300 active:duration-0 focus:outline-none ${t.touchRipple} overflow-hidden select-none`), ios: c("h-11", t.textIos, t.activeBgIos, t.activeBgIos), material: c("h-12", t.textMaterial, t.activeBgMaterial) } } },
  g0 = (e = {}, t) => ({ textIos: "text-primary", textMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), activeBgIos: "active:bg-primary active:bg-opacity-15", activeBgMaterial: "", touchRipple: "touch-ripple-primary", ...e }),
  Fm = () => m.useContext(Dm),
  cn = m.forwardRef((e, t) => {
    const { component: n = "li", className: r, colors: i, href: o, target: a, type: s, value: u, linkComponent: d = "a", linkProps: p = {}, ios: v, material: g, touchRipple: k = !0, children: C, ...b } = e, N = m.useRef(null), y = m.useRef(null), f = Fm();
    m.useImperativeHandle(t, () => ({ el: N.current }));
    const x = n,
      w = { ...b },
      S = fe({ ios: v, material: g }),
      I = H({ ios: v, material: g });
    $t(y, S === "material" && k);
    const M = Y(),
      L = g0(i, M),
      B = I(h0({ ...e, dividers: f }, L, r), r),
      R = !!o || o === "",
      q = { href: !R || o === !0 || o === !1 ? void 0 : o || "", target: a, type: s, value: u, ...p },
      V = R ? d : "button";
    return l(x, { ref: N, className: B.base, ...w, children: l(V, { ref: y, className: B.button, ...q, children: C }) })
  });
cn.displayName = "ListButton";
const v0 = (e, t, { className: n, isMediaItem: r, theme: i, textColor: o, needsTouchRipple: a, isMenuListItemActive: s, autoStrongTitle: u }) => { const { menuListItem: d, dividers: p, mediaClassName: v = "", mediaClass: g = "", innerClassName: k = "", innerClass: C = "", contentClassName: b = "", contentClass: N = "", titleWrapClassName: y = "", titleWrapClass: f = "", titleFontSizeIos: x, titleFontSizeMaterial: w, strongTitle: S, contacts: I } = e; return { base: { common: d ? `${o} py-1` : "", material: I && "[&:nth-child(2)]:-mt-12" }, itemContent: { common: c(`flex items-center ${b||N}`), ios: c(!d && c(t.primaryTextIos, "ps-4-safe"), d && "rounded-lg ml-2-safe mr-2-safe ps-2"), material: c(!d && c(t.primaryTextMaterial, r ? "ml-2-safe mr-2-safe rounded-2xl ps-2" : "ps-4-safe", I && "ml-10"), d && "rounded-full min-h-[3.5rem] ml-4-safe mr-4-safe ps-4"), link: c("duration-300 active:duration-0 cursor-pointer select-none", p && i === "ios" && "active:hairline-transparent", a && c("relative overflow-hidden z-10", t.touchRipple), c(s ? i === "ios" ? t.menuListItemActiveBgIos : t.menuListItemActiveBgMaterial : d ? i === "ios" ? t.menuListItemBgIos : t.menuListItemBgMaterial : i === "ios" ? t.activeBgIos : t.activeBgMaterial)) }, media: { common: `shrink-0 flex ${v||g}`, ios: "py-2 me-4", material: c("py-3", d ? "me-3" : "me-4") }, inner: { common: c("w-full relative", !d && p && "hairline-b", k || C), ios: "py-2.5 pe-4-safe", material: c("py-3", r && !d ? "pe-2" : "pe-4-safe") }, titleWrap: { common: c(`flex justify-between items-center ${y||f}`), ios: c(!d && x), material: c(!d && w) }, title: { common: "shrink", menuListItem: c("text-sm", S === !0 || u ? "font-semibold" : "font-medium"), strong: { common: "", ios: "font-semibold", material: "font-medium" } }, after: { common: c("shrink-0 ms-auto ps-1 flex items-center space-x-1"), ios: t.secondaryTextIos, material: c(t.secondaryTextMaterial, "text-sm") }, chevron: "opacity-20 shrink-0 ms-3 rtl:rotate-180", subtitle: "text-sm", text: { common: c("text-sm line-clamp-2"), ios: t.secondaryTextIos, material: t.secondaryTextMaterial }, header: { common: "text-xs mb-0.5", ios: t.secondaryTextIos, material: t.secondaryTextMaterial }, footer: { common: c("text-xs mt-0.5"), ios: t.secondaryTextIos, material: t.secondaryTextMaterial }, groupTitle: { common: c("pl-4-safe pr-4-safe py-1 flex items-center z-20", Se("relative", n)), ios: `h-8${p?" hairline-t":""} -mt-px ${x} ${t.secondaryTextIos} ${t.groupTitleBgIos} ${I&&c("font-semibold top-11-safe sticky",t.groupTitleContactsTextIos,t.groupTitleContactsBgIos)}`, material: `h-12 ${w} ${t.secondaryTextMaterial} ${t.groupTitleBgMaterial} ${I&&c("pointer-events-none overflow-visible h-12 box-border text-xl font-medium flex max-w-full items-center px-4 top-16-safe sticky",t.groupTitleContactsTextMaterial,t.groupTitleContactsBgMaterial)}` } } },
  y0 = (e = {}, t) => ({ primaryTextIos: c("text-black", t("dark:text-white")), primaryTextMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), secondaryTextIos: c("text-black text-opacity-55", t("dark:text-white dark:text-opacity-55")), secondaryTextMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), activeBgIos: c("active:bg-black active:bg-opacity-10", t("dark:active:bg-white dark:active:bg-opacity-10")), activeBgMaterial: "", groupTitleBgIos: c("bg-ios-light-surface-variant", t("dark:bg-ios-dark-surface-variant")), groupTitleBgMaterial: c("bg-md-light-surface-2", t("dark:bg-md-dark-surface-2")), menuListItemTextIos: c("text-black", t("dark:text-white")), menuListItemTextMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), menuListItemBgIos: c("active:bg-black active:bg-opacity-10", t("dark:active:bg-white dark:active:bg-opacity-10")), menuListItemBgMaterial: c("bg-md-light-surface-1", t("dark:bg-md-dark-surface-1")), menuListItemActiveTextIos: c("text-primary", t("dark:text-white")), menuListItemActiveTextMaterial: c("text-md-light-on-secondary-container", t("dark:text-md-dark-on-secondary-container")), menuListItemActiveBgIos: c("bg-primary bg-opacity-15", t("dark:bg-primary")), menuListItemActiveBgMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), touchRipple: c("touch-ripple-black", t("dark:touch-ripple-white")), groupTitleContactsTextIos: c("text-opacity-90", t("dark:text-opacity-90")), groupTitleContactsTextMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), groupTitleContactsBgIos: c(t("dark:bg-[#323234]")), groupTitleContactsBgMaterial: c("bg-transparent", t("dark:bg-transparent")), ...e }),
  P = m.forwardRef((e, t) => {
    const { component: n = "li", colors: r, className: i, mediaClassName: o = "", innerClassName: a = "", innerChildren: s, contentClassName: u = "", contentChildren: d, titleWrapClassName: p = "", titleFontSizeIos: v = "text-[17px]", titleFontSizeMaterial: g = "text-[16px]", title: k, subtitle: C, text: b, after: N, media: y, header: f, footer: x, menuListItem: w, menuListItemActive: S, groupTitle: I, strongTitle: M = "auto", label: L, chevron: B = void 0, chevronIos: R = !0, chevronMaterial: _ = !0, chevronIcon: q, href: V, target: X, link: ue, linkComponent: ee = "a", linkProps: ie = {}, dividers: T, contacts: j, ios: $, material: G, touchRipple: J = !0, children: Me, ...ce } = e, de = m.useRef(null), Ce = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: Ce.current }));
    const ge = n,
      _e = { ...ce },
      ve = typeof T > "u" ? Fm() : T,
      qe = fe({ ios: $, material: G }),
      Mt = H({ ios: $, material: G }),
      Ze = Y(),
      yt = typeof B > "u" ? qe === "ios" ? R : _ : B,
      je = y0(r, Ze),
      ct = w && S,
      dt = je[`${ct?"menuListItemActiveText":w?"menuListItemText":"text"}${qe==="ios"?"Ios":"Material"}`],
      Ue = !!V || V === "" || w || ue,
      Lt = !!L,
      oe = qe === "material" && (Lt || Ue) && J;
    $t(de, oe);
    const Ge = V === !0 || V === !1 || typeof V > "u" ? void 0 : V || "",
      xt = Ue ? ee : Lt ? "label" : "div",
      At = Ue ? { href: Ge, target: X, ...ie } : {},
      rt = k && (C || b),
      kt = M === "auto" && rt,
      Le = Mt(v0({ ...e, titleFontSizeIos: v, titleFontSizeMaterial: g, dividers: ve, strongTitle: M, mediaClassName: o, innerClassName: a, contentClassName: u, titleWrapClassName: p }, je, { isMediaItem: rt, theme: qe, textColor: dt, needsTouchRipple: oe, isMenuListItemActive: ct, darkClasses: Ze, autoStrongTitle: kt, className: i }), i),
      io = Ue || Lt ? Le.itemContent.link : Le.itemContent.default,
      lo = w ? Le.title.menuListItem : M === !0 || kt ? Le.title.strong : Le.title.default;
    return I ? h(ge, { className: c(Le.groupTitle, i), children: [k, Me] }) : h(ge, { ref: Ce, className: Le.base, ..._e, children: [h(xt, { ref: de, className: io, ...At, children: [y && l("div", { className: Le.media, children: y }), h("div", { className: Le.inner, children: [f && l("div", { className: Le.header, children: f }), (k || N) && h("div", { className: Le.titleWrap, children: [k && l("div", { className: lo, children: k }), N && l("div", { className: Le.after, children: N }), Ue && yt && !w && (q || l(zm, { className: Le.chevron }))] }), C && l("div", { className: Le.subtitle, children: C }), b && l("div", { className: Le.text, children: b }), x && l("div", { className: Le.footer, children: x }), s] }), d] }), Me] })
  });
P.displayName = "ListItem";
const x0 = e => l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "8", height: "5", viewBox: "0 0 8 5", fill: "currentcolor", ...e, children: l("polygon", { fillRule: "evenodd", points: "0 0 8 0 4 5" }) }),
  k0 = (e, t, { isFloatingTransformed: n, isFocused: r, darkClasses: i, getLabelColor: o, hasLabel: a }) => { const { error: s, type: u, outline: d, inputClassName: p = "", inputClass: v = "" } = e; return { base: { common: "", ios: c(d && "my-4"), material: c("py-2") }, itemContent: { common: "relative", ios: c(d && "ml-4 mr-4 rounded-lg", !d && t.bgIos), material: c("min-h-[56px] ml-4 mr-4", d ? c("rounded") : c(t.bgMaterial, "rounded-t relative ")) }, inner: { common: "", material: c(d ? "pt-4 pb-4" : "pt-2 pb-2"), stacked: "", floating: "" }, label: { common: c("duration-200 text-xs", o(), d && "flex"), ios: c(d && "-mt-4"), material: c(d && "-mt-4"), stacked: "", floating: { common: c("pointer-events-none duration-200 transform origin-left rtl:origin-right max-w-[66%]", n && "scale-133"), ios: n ? d ? "translate-y-6" : "translate-y-4" : "", material: n ? d ? "translate-y-8" : "translate-y-3" : "" } }, labelText: { common: c(d && "relative p-1 block -m-1"), ios: c(d && c("-top-1", t.outlineLabelBgIos)), material: c(d && c("-top-2", t.outlineLabelBgMaterial)) }, inputWrap: { common: "relative", ios: c((!a || d) && "-mt-2.5", "-mb-2.5"), stacked: "", floating: "" }, media: { material: "" }, titleWrap: { material: `duration-200 ${o()}` }, input: { common: `block text-base appearance-none w-full focus:outline-none bg-transparent ${p||v}`, ios: "h-10", material: "h-6", notFloating: { common: c("placeholder-black placeholder-opacity-30", i("dark:placeholder-white dark:placeholder-opacity-30")), material: c(u === "textarea" && "py-1"), ios: c(u === "textarea" && "py-2") }, floating: n ? "placeholder-transparent" : c("placeholder-black placeholder-opacity-30", i("dark:placeholder-white dark:placeholder-opacity-30")) }, errorInfo: { common: "text-xs relative z-10", ios: "mt-1", material: "" }, error: t.errorText, info: "opacity-50", clearButton: { common: "absolute end-0 top-1/2 transform -translate-y-1/2 cursor-pointer", ios: c("w-3.5 h-3.5 opacity-45 active:opacity-30", t.labelTextIos), material: c("w-6 h-6 active:opacity-55", t.labelTextMaterial) }, dropdown: "absolute end-0 top-1/2 transform -translate-y-1/2 pointer-events-none opacity-50", border: { common: "pointer-events-none absolute start-0 bottom-0 duration-200 w-full", ios: d && c(s ? t.errorBorder : r ? t.outlineBorderFocusIos : t.outlineBorderIos, "h-full border rounded-lg -z-10"), material: c(s ? t.errorBorder : r ? t.outlineBorderFocusMaterial : t.outlineBorderMaterial, d && c("h-full border rounded -z-10", r && "border-2"), !d && c("border-b h-px origin-bottom", r && "scale-y-[2]")) } } },
  b0 = (e = {}, t) => ({ bgIos: "", bgMaterial: c("bg-md-light-surface-variant", t("dark:bg-md-dark-surface-variant")), outlineBorderIos: c("border-black border-opacity-30", t("dark:border-white dark:border-opacity-30")), outlineBorderFocusIos: "border-primary", outlineBorderMaterial: c("border-md-light-on-surface", t("dark:border-md-dark-on-surface")), outlineBorderFocusMaterial: c("border-md-light-primary", t("dark:border-md-dark-primary")), outlineLabelBgIos: c("bg-ios-light-surface-1", t("dark:bg-ios-dark-surface-1")), outlineLabelBgMaterial: c("bg-md-light-surface", t("dark:bg-md-dark-surface")), labelTextIos: "", labelTextFocusIos: "", labelTextMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), labelTextFocusMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), errorText: "text-red-500", errorBorder: "border-red-500", ...e }),
  Q = m.forwardRef((e, t) => {
    const { component: n = "li", className: r, colors: i, label: o, floatingLabel: a, outline: s, outlineIos: u, outlineMaterial: d, media: p, input: v, info: g, error: k, clearButton: C, dropdown: b, inputId: N, inputStyle: y, inputClassName: f = "", name: x, value: w, defaultValue: S, type: I = "text", inputMode: M, readOnly: L, required: B, disabled: R, placeholder: _, size: q, accept: V, autoComplete: X, autoCorrect: ue, autoCapitalize: ee, spellCheck: ie, autoFocus: T, autoSave: j, max: $, min: G, step: J, maxLength: Me, minLength: ce, multiple: de, pattern: Ce, tabIndex: ge, onInput: _e, onChange: ve, onFocus: qe, onBlur: Mt, onClear: Ze, ios: yt, material: je, children: ct, ...dt } = e, Ue = m.useRef(null), Lt = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: Lt.current, inputEl: Ue.current }));
    const [oe, Ge] = m.useState(!1), xt = fe({ ios: yt, material: je }), At = H({ ios: yt, material: je }), rt = Y(), kt = b0(i, rt), Le = o && a ? "floating" : "stacked", io = Le === "floating" ? "floating" : "notFloating", lo = () => { if (Ue.current) return Ue.current.value }, _f = o && a && !(() => { const Kt = lo(); return typeof w > "u" ? Kt || Kt === 0 : w || w === 0 })() && !oe, Df = () => k ? kt.errorText : xt === "material" ? oe ? kt.labelTextFocusMaterial : kt.labelTextMaterial : xt === "ios" ? oe ? kt.labelTextFocusIos : kt.labelTextIos : "", Ff = Kt => { Ge(!0), qe && qe(Kt) }, jf = Kt => { Ge(!1), Mt && Mt(Kt) }, oo = typeof s > "u" ? xt === "ios" ? u : d : s, We = At(k0({ ...e, outline: oo }, kt, { isFloatingTransformed: _f, isFocused: oe, darkClasses: rt, getLabelColor: Df, inputClassName: f, hasLabel: !!o })), $f = { ...dt }, Af = () => {
      if (v) return v;
      const Kt = I === "select" || I === "textarea" ? I : "input",
        Uf = Kt === "input";
      return l(Kt, { id: N, ref: Ue, className: We.input[io], style: y, name: x, type: Uf ? I : void 0, placeholder: _, inputMode: M, size: q, accept: V, autoComplete: X, autoCorrect: ue, autoCapitalize: ee, spellCheck: ie, autoFocus: T, autoSave: j, disabled: R, max: $, maxLength: Me, min: G, minLength: ce, step: J, multiple: de, readOnly: L, required: B, pattern: Ce, tabIndex: ge, value: w, defaultValue: S, onInput: _e, onChange: ve, onFocus: Ff, onBlur: jf, children: I === "select" ? ct : null })
    }, Hf = h(ut, { children: [k && k !== !0 && l("div", { className: c(We.errorInfo, We.error), children: k }), g && !k && l("div", { className: c(We.errorInfo, We.info), children: g })] }), qf = h(ut, { children: [o && l("div", { className: We.label[Le], children: l("div", { className: We.labelText, children: o }) }), h("div", { className: We.inputWrap[Le], children: [Af(), C && l(Ni, { theme: xt, onClick: Ze, className: We.clearButton }), b && l(x0, { className: We.dropdown })] }), Hf] });
    return l(P, { ref: Lt, component: n, media: p, className: We.base, title: null, mediaClassName: We.media, innerClassName: We.inner[Le], contentClassName: We.itemContent, titleWrapClassName: We.titleWrap, innerChildren: qf, contentChildren: (oo || xt === "material") && l("span", { className: We.border }), dividers: xt === "material" || oo ? !1 : void 0, ...$f, children: I !== "select" ? ct : null })
  });
Q.displayName = "ListInput";
const ja = m.forwardRef((e, t) => {
  const { children: n, ...r } = e, i = m.useRef(null);
  m.useImperativeHandle(t, () => ({ el: i.current }));
  const o = { ...r };
  return l(U, { ref: i, menuList: !0, ...o, children: n })
});
ja.displayName = "MenuList";
const jn = m.forwardRef((e, t) => {
  const { active: n, href: r, children: i, ...o } = e, a = m.useRef(null);
  m.useImperativeHandle(t, () => ({ el: a.current }));
  const s = { ...o };
  return l(P, { ref: a, menuListItem: !0, menuListItemActive: n, href: r || !1, ...s, children: i })
});
jn.displayName = "MenuListItem";
const C0 = (e, t) => { const { type: n } = e; return { message: { common: "max-w-[70%] box-border flex relative z-1 transform translate-z-0 mb-2 first:mt-2" }, messageSent: { common: c("self-end", t.messageSent) }, messageReceived: { common: t.messageReceived }, messageName: { common: "text-xs", ios: c("mb-0.5 ms-4", t.messageNameIos), material: c("ms-4 mb-0.5", t.messageNameMd) }, messageHeader: { common: "text-xs", ios: c("mb-0.5 ms-4", t.messageNameIos), material: c("ms-4 mb-0.5", t.messageNameMd) }, messageFooter: { common: "text-xs", ios: c("mb-0.5 ms-4", t.messageNameIos), material: c("ms-4 mb-0.5", t.messageNameMd) }, messageAvatar: { common: c("rounded-full relative bg-cover self-end shrink-0 me-1.5 w-8 h-8") }, messageContent: { common: "flex flex-col" }, messageBubble: { ...n === "sent" && { ios: c("rounded-3xl box-border break-words flex flex-col relative rounded-2xl py-1.5 px-4", t.bubbleSentIos), material: c("box-border break-words flex flex-col relative rounded-3xl py-2.5 px-4", t.bubbleSentMd) }, ...n === "received" && { ios: c("rounded-2xl box-border break-words flex flex-col relative rounded-2xl py-1.5 px-4", t.bubbleReceivedIos), material: c("box-border break-words flex flex-col relative rounded-3xl py-2.5 px-4 ", t.bubbleReceivedMd) } }, messageTextHeader: { common: "w-full text-left leading-tight text-sm opacity-80" }, messageTextFooter: { common: "w-full text-left leading-tight text-sm opacity-80" }, messageText: { common: "w-full text-left leading-tight" } } },
  w0 = (e = {}, t) => ({ messageSent: "text-white", messageReceived: "text-inherit", messageNameIos: c("text-black text-opacity-45", t("dark:text-white dark:text-opacity-45")), messageNameMd: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), bubbleSentIos: c("bg-primary"), bubbleSentMd: c("bg-md-light-primary", t("dark:bg-md-dark-primary dark:text-md-dark-on-primary")), bubbleReceivedIos: c("bg-[#e5e5ea]", t("dark:bg-[#252525]")), bubbleReceivedMd: c(t("dark:bg-md-dark-surface-variant"), "bg-[#e5e5ea]"), ...e }),
  jm = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, id: o, text: a, name: s, type: u = "sent", header: d, footer: p, textHeader: v, textFooter: g, avatar: k, ios: C, material: b, children: N, ...y } = e, f = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: f.current }));
    const x = H({ ios: C, material: b }),
      w = Y(),
      S = w0(i, w),
      I = x(C0({ ...e }, S)),
      M = n,
      L = { ...y },
      B = c(r, I.message, {
        [I.messageSent]: u === "sent",
        [I.messageReceived]: u === "received"
      });
    return h(M, { id: o, ref: f, className: B, ...L, children: [k && l("div", { className: I.messageAvatar, children: k }), h("div", { className: I.messageContent, children: [s && l("div", { className: I.messageName, children: s }), d && l("div", { className: I.messageHeader, children: d }), h("div", { className: I.messageBubble, children: [v && l("div", { className: I.messageTextHeader, children: v }), a && l("div", { className: I.messageText, children: a }), g && l("div", { className: I.messageTextFooter, children: g })] }), p && l("div", { className: I.messageFooter, children: p })] })] })
  });
jm.displayName = "Message";
const N0 = (e, t, { isFocused: n }) => { const { rightClassName: r = "", rightClass: i = "", leftClassName: o = "", leftClass: a = "" } = e; return { base: { common: "fixed bottom-0 start-0 w-full" }, toolbar: { material: t.bgMessage }, left: { common: c("mt-1 -ms-2", o || a), ios: c("px-2", t.toolbarIconIos), material: c("", t.toolbarIconMd) }, right: { common: c("mt-1 -me-2", r || i), ios: c("px-2", t.toolbarIconIos) }, messagebarArea: { common: "w-full" }, messagebarInput: { common: c("block w-full focus:outline-none resize-none", n && "outline-offset-0"), ios: c("border h-8 rounded-3xl px-4 leading-4 py-1.5", t.inputBgIos, t.borderIos, t.placeholderIos), material: c("rounded-3xl h-12 px-4 py-4 leading-4 ", t.inputBgMd, t.placeholderMd) } } },
  I0 = (e = {}, t) => ({ toolbarIconIos: c("fill-primary", t("dark:fill-md-dark-primary")), toolbarIconMd: c("fill-black"), inputBgIos: c("bg-transparent"), borderIos: c("border-[#c8c8cd]", t("dark:border-white dark:border-opacity-30")), inputBgMd: c("bg-md-light-surface-2", t("dark:bg-md-dark-surface-variant")), placeholderIos: c(t("dark:placeholder-white dark:placeholder-opacity-40")), placeholderMd: c("placeholder-md-light-on-surface-variant", t("dark:placeholder-md-dark-on-surface-variant")), bgIos: c("bg-white", t("dark:bg-black")), bgMaterial: c("bg-md-light-surface", t("dark:bg-md-dark-surface")), ...e }),
  S0 = (e, t, n) => { const { bgClassName: r = "", bgClass: i = "", outline: o, translucent: a, innerClassName: s = "", innerClass: u = "", tabbar: d, tabbarIcons: p, top: v } = e; return { base: { common: c("w-full z-20", Se("relative", n), !v && "pb-safe") }, bg: { common: c("absolute w-full h-full left-0 top-0", o && (v ? "hairline-b" : "hairline-t"), r || i), ios: c(t.bgIos, a && "translucent"), material: c(`${t.bgMaterial}`) }, inner: { common: c("flex relative justify-between items-center w-full overflow-hidden", s || u), ios: c("pl-2-safe pr-2-safe", p ? "h-12.5" : "h-11"), material: c(d ? "" : "pl-2-safe pr-2-safe", p ? "h-20" : "h-14") }, highlight: { common: c(v ? "bottom-0" : "top-0", "absolute left-0 w-full h-0.5 duration-200 pointer-events-none transition-transform"), ios: t.tabbarHighlightBgIos, material: t.tabbarHighlightBgMaterial } } },
  P0 = (e = {}, t) => ({ bgIos: c("bg-ios-light-surface-2", t("dark:bg-ios-dark-surface-2")), bgMaterial: c("bg-md-light-surface-2", t("dark:bg-md-dark-surface-2")), tabbarHighlightBgIos: "bg-primary", tabbarHighlightBgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), ...e }),
  Ti = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, translucent: o = !0, bgClassName: a = "", innerClassName: s = "", outline: u, tabbar: d, tabbarIcons: p, tabbarLabels: v, top: g, ios: k, material: C, children: b, ...N } = e, y = m.useRef(null), f = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: f.current }));
    const x = n,
      [w, S] = m.useState({ transform: "", width: "" }),
      I = fe({ ios: k, material: C }),
      M = H({ ios: k, material: C }),
      L = Y(),
      B = { ...N },
      R = P0(i, L),
      q = M(S0({ ...e, outline: typeof u > "u" ? I === "ios" : u, translucent: o, bgClassName: a, innerClassName: s }, R, r), r),
      V = I === "material" && d && !p;
    return m.useEffect(() => {
      if (V && y.current) {
        const X = y.current.previousElementSibling,
          ue = 1 / X.children.length * 100,
          ee = [...X.children].indexOf(X.querySelector(".k-tabbar-link-active"));
        S({ ...w, width: `${ue}%`, transform: `translateX(${ee*100}%)` })
      }
    }, [b]), h(x, { ref: f, className: q.base, ...B, children: [l("div", { className: q.bg }), l("div", { className: q.inner, children: b }), V && l("span", { className: q.highlight, style: w, ref: y })] })
  });
Ti.displayName = "Toolbar";
const $m = m.forwardRef((e, t) => {
  const { component: n = "div", className: r, colors: i, id: o, style: a, name: s, placeholder: u = "Message", value: d, outline: p = !1, leftClassName: v = "", rightClassName: g = "", textareaId: k, disabled: C, size: b, left: N, right: y, ios: f, material: x, onInput: w, onChange: S, onFocus: I, children: M, ...L } = e, B = m.useRef(null), R = m.useRef(null);
  m.useImperativeHandle(t, () => ({ el: B.current, areaElRef: R.current }));
  const [_, q] = m.useState(!1), V = H({ ios: f, material: x }), X = Y(), ue = I0(i, X), ee = $ => { q(!0), I && I($) }, ie = V(N0({ ...e }, ue, { isFocused: _ })), T = n, j = { ...L };
  return l(T, { ref: B, id: o, style: a, className: ie.base, ...j, children: h(Ti, { colors: ue, outline: p, children: [N && l("div", { className: ie.left, children: N }), l("div", { className: ie.messagebarArea, children: l("textarea", { id: k, ref: R, type: "textarea", className: ie.messagebarInput, placeholder: u, name: s, size: b, disabled: C, onInput: w, onChange: S, onFocus: ee, value: d }) }), y && l("div", { className: ie.right, children: y })] }) })
});
$m.displayName = "Messagebar";
const M0 = () => ({ base: { common: c("flex flex-col relative z-1 px-2"), ios: "mb-12", material: "mb-16" } }),
  Am = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, id: o, ios: a, material: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const g = H({ ios: a, material: s })(M0({ ...e })),
      k = n,
      C = { ...d };
    return l(k, { id: o, className: g.base, ref: p, ...C, children: u })
  });
Am.displayName = "Messages";
const L0 = (e, t) => ({ base: { common: c("text-center text-xs leading-none"), ios: c("w-full mt-2.5", t.titleIos), material: c("mt-4", t.titleMd) } }),
  B0 = (e = {}, t) => ({ titleIos: c("text-black text-opacity-45", t("dark:text-white dark:text-opacity-45")), titleMd: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), ...e }),
  Hm = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, id: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = H({ ios: o, material: a }),
      g = Y(),
      k = B0(i, g),
      C = v(L0({ ...e }, k)),
      b = n,
      N = { ...d };
    return l(b, { id: s, className: C.base, ref: p, ...N, children: u })
  });
Hm.displayName = "MessagesTitle";
const R0 = (e, t, n) => { const { outline: r, translucent: i, large: o, medium: a, transparent: s, left: u, right: d, fontSizeIos: p, fontSizeMaterial: v, titleFontSizeIos: g, titleFontSizeMaterial: k, titleLargeFontSizeIos: C, titleLargeFontSizeMaterial: b, titleMediumFontSizeIos: N, titleMediumFontSizeMaterial: y, bgClassName: f = "", bgClass: x = "", subnavbarClassName: w = "", subnavbarClass: S = "", innerClassName: I = "", innerClass: M = "", leftClassName: L = "", leftClass: B = "", titleClassName: R = "", titleClass: _ = "", subtitleClassName: q = "", subtitleClass: V = "", rightClassName: X = "", rightClass: ue = "", centerTitle: ee } = e; return { base: { common: c("w-full z-20 top-0 pt-safe", (o || a) && "pointer-events-none", Se("sticky", n)), ios: c(p, t.textIos), material: c(v, t.textMaterial) }, bg: { common: c("absolute w-full h-full left-0 top-0", r && "hairline-b", f || x), ios: c(t.bgIos, i && "translucent"), material: `${t.bgMaterial}` }, subnavbar: { common: c("relative flex items-center", w || S, (o || a) && "pointer-events-auto"), ios: "h-11 pl-2-safe pr-2-safe", material: "h-14 pl-4-safe pr-4-safe" }, inner: { common: c("flex relative items-center w-full overflow-hidden", I || M, (o || a) && "pointer-events-auto z-10"), ios: c("pl-2-safe pr-2-safe h-11", !u && d ? "justify-end" : "justify-between"), material: "justify-start h-16 pl-safe pr-safe" }, titleContainer: { common: c("flex items-center px-4 relative", (o || a) && "pointer-events-auto"), ios: c(a && c(N, "h-11 font-semibold"), o && c(C, "h-13 font-bold")), material: c(a && c(y, "h-12 pb-4"), o && c(b, "h-[5.5rem]")) }, left: { common: c("flex justify-center items-center h-full", L || B), ios: "me-2 transform transform-gpu", material: "mx-1" }, title: { common: c("whitespace-nowrap leading-tight", R || _, (o || a || s) && "opacity-0", ee ? "absolute top-1/2 left-1/2 transform-gpu -translate-x-1/2 -translate-y-1/2 text-center" : "text-start"), ios: c(`${g} font-semibold`, !ee && "first:mx-2"), material: c(`${k} font-normal`, !ee && "first:mx-4") }, subtitle: { common: c("font-normal leading-none", q || V), ios: "text-2xs opacity-55", material: "text-sm opacity-85" }, right: { common: c("flex justify-center items-center h-full", X || ue), ios: c("transform transform-gpu", ee ? "ms-2" : "ms-auto"), material: "ms-auto me-1" } } },
  E0 = (e, t) => ({ bgIos: c("bg-ios-light-surface-2", t("dark:bg-ios-dark-surface-2")), bgMaterial: c("bg-md-light-surface-2", t("dark:bg-md-dark-surface-2")), textIos: c("text-black", t("dark:text-white")), textMaterial: c("text-md-light-on-surface", t("dark:text-md-dark-on-surface")), ...e }),
  K = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, bgClassName: i = "", innerClassName: o = "", leftClassName: a = "", titleClassName: s = "", subtitleClassName: u = "", rightClassName: d = "", subnavbarClassName: p = "", centerTitle: v, colors: g, translucent: k = !0, outline: C, medium: b, large: N, transparent: y, fontSizeIos: f = "text-[17px]", fontSizeMaterial: x = "text-[16px]", titleFontSizeIos: w = "text-[17px]", titleFontSizeMaterial: S = "text-[22px]", titleMediumFontSizeIos: I = "text-[24px]", titleMediumFontSizeMaterial: M = "text-[24px]", titleLargeFontSizeIos: L = "text-[34px]", titleLargeFontSizeMaterial: B = "text-[28px]", scrollEl: R, left: _, title: q, subtitle: V, right: X, subnavbar: ue, ios: ee, material: ie, children: T, ...j } = e, $ = m.useRef(null), G = m.useRef(0), J = m.useRef(null), Me = m.useRef(null), ce = m.useRef(null), de = m.useRef(null), Ce = m.useRef(null), ge = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: $.current }));
    const _e = n,
      ve = fe({ ios: ee, material: ie }),
      qe = H({ ios: ee, material: ie }),
      Mt = Y(),
      Ze = { ...j },
      yt = E0(g, Mt),
      je = Ge => {
        const { scrollTop: xt } = Ge.target;
        if (!y && !N && !b) { ge.current && (de.current && (de.current.style.opacity = ""), J.current && (J.current.style.opacity = "")); return }
        const At = G.current,
          rt = Math.max(Math.min(xt / At, 1), 0);
        J.current.style.opacity = y ? -.5 + rt * 1.5 : "", (b || N) && (J.current.style.transform = `translateY(-${rt*At}px)`), ce.current && (ce.current.style.transform = `translateY(-${rt*At}px)`, ce.current.style.opacity = 1 - rt * 2), de.current && (de.current.style.opacity = -.5 + rt * 1.5), (b || N) && Ce.current && (Ce.current.style.transform = `translateY(-${rt*At}px)`)
      },
      ct = () => typeof R > "u" ? $.current && $.current.parentNode : R.current || R,
      dt = () => {
        if (!N && !b && !y) { ge.current && (je({ target: { scrollTop: 0 } }), ge.current = !1); return } ge.current = !0, ce.current ? G.current = ce.current.offsetHeight : G.current = Me.current.offsetHeight;
        const Ge = ct();
        Ge ? (Ge.addEventListener("scroll", je), je({ target: Ge })) : je({ target: { scrollTop: 0 } })
      },
      Ue = () => {
        const Ge = ct();
        Ge && Ge.removeEventListener("scroll", je)
      };
    m.useEffect(() => (dt(), Ue));
    const oe = qe(R0({ ...e, centerTitle: typeof v > "u" ? ve === "ios" : v, translucent: k, outline: typeof C > "u" ? ve === "ios" : C, fontSizeIos: f, fontSizeMaterial: x, titleFontSizeIos: w, titleFontSizeMaterial: S, titleMediumFontSizeIos: I, titleMediumFontSizeMaterial: M, titleLargeFontSizeIos: L, titleLargeFontSizeMaterial: B, bgClassName: i, innerClassName: o, leftClassName: a, titleClassName: s, subtitleClassName: u, rightClassName: d, subnavbarClassName: p }, yt, r), r);
    return h(_e, { ref: $, className: oe.base, ...Ze, children: [l("div", { className: oe.bg, ref: J }), h("div", { className: oe.inner, ref: Me, children: [_ && l("div", { className: oe.left, children: _ }), (q || V) && h("div", { className: oe.title, ref: de, children: [q, V && l("div", { className: oe.subtitle, children: V })] }), X && l("div", { className: oe.right, children: X }), T] }), (N || b) && l("div", { className: oe.titleContainer, ref: ce, children: q }), ue && l("div", { className: oe.subnavbar, ref: Ce, children: ue })] })
  });
K.displayName = "Navbar";
const qm = ({ theme: e, ...t }) => e === "ios" ? l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "12", height: "20", viewBox: "0 0 12 20", fill: "currentcolor", ...t, children: l("path", { d: "M0.18261596,9.4221638 C0.21783626,9.37068075 0.25835058,9.32165682 0.30416276,9.27584463 L9.1425872,0.4374202 C9.7256776,-0.14567018 10.6691555,-0.1475686 11.2590259,0.44230183 C11.8448123,1.02808827 11.8502479,1.97240019 11.2639075,2.55874056 L3.82594417,9.9967039 L11.2578297,17.4285894 C11.8409201,18.0116798 11.8428185,18.9551577 11.252948,19.5450281 C10.6671616,20.1308146 9.7228497,20.1362501 9.13650932,19.5499097 L0.2980849,10.7114853 C-0.0545897,10.3588107 -0.0959125,9.8144953 0.18261596,9.4221638 Z" }) }) : l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 16 16", fill: "currentcolor", ...t, children: l("polygon", { points: "16 7 3.83 7 9.42 1.41 8 0 0 8 8 16 9.41 14.59 3.83 9 16 9" }) }),
  T0 = () => ({ base: { common: "cursor-pointer", material: "min-w-12 k-touch-ripple-inset" }, icon: "rtl:rotate-180" }),
  re = m.forwardRef((e, t) => {
    const { component: n = "a", className: r, text: i = "Back", showText: o = "auto", ios: a, material: s, onClick: u, children: d, ...p } = e, v = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: v.current }));
    const g = { ...p },
      k = fe({ ios: a, material: s }),
      C = H({ ios: a, material: s }),
      b = o === "auto" && k === "ios" || o === !0,
      N = C(T0(), r);
    return h(te, { ref: v, component: n, className: N.base, navbar: !0, ...g, onClick: u, children: [l("span", { className: N.icon, children: l(qm, { theme: k }) }), b && l("span", { children: i }), d] })
  });
re.displayName = "NavbarBackLink";
const z0 = (e, t, n) => { const { opened: r, translucent: i } = e; return { base: { common: c(Se("absolute", n), "z-50 transform transition-transform-opacity box-border duration-500", !r && "-translate-y-full opacity-0 pointer-events-none transition duration-500", "md:w-[568px] md:end-auto md:start-1/2 md:-ms-[256px]"), ios: c("rounded-xl px-2.5 py-2.5 start-2 end-2 top-2 shadow-lg", t.bgIos, i && "translucent"), material: c("rounded-2xl py-5 px-4 start-4 end-4 top-4", t.bgMaterial) }, content: { common: "", ios: "mt-2.5 ", material: c("mt-2") }, header: { common: c("flex justify-start"), ios: "items-center", material: "items-start" }, icon: { ios: c("me-2"), material: "me-4" }, contentTitle: { material: c("flex flex-row items-center") }, title: { ios: c("tracking-wide text-[13px] uppercase", t.titleIos), material: c("font-medium") }, titleRightText: { ios: c("me-1 ms-auto text-[13px]", t.titleRightIos), material: c("ms-1 text-xs before:w-0.75 before:h-0.75 before:rounded-full before:inline-block before:align-middle before:me-1", t.titleRightMd) }, button: { ios: c("me-1 ms-auto cursor-pointer"), material: c("ms-auto cursor-pointer") }, deleteIcon: { ios: c("w-5 h-5", t.deleteIconIos), material: c("w-6 h-6", t.deleteIconMd) }, subtitle: { ios: c("text-[15px] font-semibold", t.subtitleIos), material: c("text-sm") }, text: { ios: c("text-[15px]"), material: c("text-sm", t.textMaterial) } } },
  O0 = (e, t) => ({ bgIos: c("bg-white", t("dark:bg-[#1e1e1e]")), bgMaterial: c("bg-md-light-surface-5", t("dark:bg-md-dark-surface-5")), titleIos: c("text-black", t("dark:text-white")), titleRightIos: c("text-opacity-45 text-black", t("dark:text-white dark:text-opacity-45")), titleRightMd: c("text-md-light-on-surface-variant before:bg-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant before:dark:bg-md-dark-on-surface-variant")), subtitleIos: c("text-black ", t("dark:text-white")), textMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant ")), deleteIconIos: c("fill-stone-400 active:fill-stone-200", t("dark:fill-stone-500 dark:active:fill-stone-700")), deleteIconMd: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), ...e }),
  Yr = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, button: o, icon: a, title: s, titleRightText: u, subtitle: d, text: p, translucent: v = !0, opened: g, onClose: k, ios: C, material: b, children: N, ...y } = e, f = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: f.current }));
    const x = n,
      w = { ...y },
      S = fe({ ios: C, material: b }),
      I = H({ ios: C, material: b }),
      M = Y(),
      L = O0(i, M),
      B = I(z0({ ...e, translucent: v }, L, r), r);
    return S === "ios" ? h(x, { ref: f, className: B.base, ...w, children: [h("div", { className: B.header, children: [a && l("div", { className: B.icon, children: a }), s && l("div", { className: B.title, children: s }), u && l("div", { className: B.titleRightText, children: u }), o && l("div", { className: B.button, role: "button", tabIndex: "0", onClick: k, children: l(Ni, { theme: S, className: B.deleteIcon }) })] }), h("div", { className: B.content, children: [d && l("div", { className: B.subtitle, children: d }), p && l("div", { className: B.text, children: p }), N] })] }) : l(x, { ref: f, className: B.base, ...w, children: h("div", { className: B.header, children: [a && l("div", { className: B.icon, children: a }), h("div", { className: B.contentWrapper, children: [h("div", { className: B.contentTitle, children: [s && l("div", { className: B.title, children: s }), u && l("div", { className: B.titleRightText, children: u })] }), h("div", { className: B.content, children: [d && l("div", { className: B.subtitle, children: d }), p && l("div", { className: B.text, children: p }), N] })] }), o && l("div", { className: B.button, role: "button", tabIndex: "0", onClick: k, children: l(Ni, { theme: S, className: B.deleteIcon }) })] }) })
  });
Yr.displayName = "Notification";
const _0 = (e, t, n) => ({ base: { common: c("h-full w-full left-0 top-0 overflow-auto", Se("absolute", n)), ios: t.bgIos, material: t.bgMaterial } }),
  D0 = (e = {}, t) => ({ bgIos: c("bg-ios-light-surface", t("dark:bg-ios-dark-surface")), bgMaterial: c("bg-md-light-surface", t("dark:bg-md-dark-surface")), ...e }),
  Z = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, children: s, ...u } = e, d = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: d.current }));
    const p = n,
      v = { ...u },
      g = H({ ios: o, material: a }),
      k = Y(),
      C = D0(i, k),
      b = g(_0(e, C, r), r);
    return l(p, { ref: d, className: b.base, ...v, children: s })
  });
Z.displayName = "Page";
const F0 = (e, t, n) => { const { size: r, floating: i } = e; return { base: { common: c("transition-transform transform duration-400 z-40 max-w-full overflow-hidden", i ? "top-2-safe bottom-2-safe !h-auto" : "top-0 max-h-full", t.bg, Se("fixed", n), r), ios: "", material: "ease-material-in" }, left: { common: c("no-safe-areas-right", i ? "right-full -mr-2 rounded-2xl" : "right-full"), material: c(!i && "rounded-r-2xl"), opened: "translate-x-full", closed: "-translate-x-2" }, right: { common: c("no-safe-areas-left", i ? "left-full -ml-2 rounded-2xl" : "left-full"), material: c(!i && "rounded-l-2xl"), opened: "-translate-x-full", closed: "translate-x-2" }, backdrop: { common: "fixed z-40 w-full h-full left-0 top-0 bg-black bg-opacity-50 duration-400", opened: "", closed: "opacity-0 pointer-events-none" } } },
  j0 = (e = {}, t) => ({ bg: c("bg-white", t("dark:bg-black")), ...e }),
  Kr = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, size: o = "w-72 h-screen", side: a = "left", opened: s, backdrop: u = !0, floating: d = !1, onBackdropClick: p, ios: v, material: g, children: k, ...C } = e, b = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: b.current }));
    const N = s ? "opened" : "closed",
      y = n,
      f = { ...C },
      x = H({ ios: v, material: g }),
      w = Y(),
      S = j0(i, w),
      I = x(F0({ ...e, size: o, floating: d }, S, r), r),
      M = c(I.base, I[a][N]);
    return h(ut, { children: [u && l("div", { className: I.backdrop[N], onClick: p }), l(y, { ref: b, className: M, ...f, children: k })] })
  });
Kr.displayName = "Panel";
const $0 = ({ popoverEl: e, targetEl: t, angleEl: n, needsAngle: r, targetX: i, targetY: o, targetWidth: a = 0, targetHeight: s = 0, theme: u }) => {
    t.current ? t = t.current : t.value ? t = t.value : t.el ? t = t.el : t.$el && (t = t.$el), typeof t == "string" && (t = document.querySelector(t));
    let d = document.body.offsetWidth,
      p = document.body.offsetHeight;
    d === 0 && (d = window.innerWidth), p === 0 && (p = window.innerHeight);
    const [v, g] = [e.offsetWidth, e.offsetHeight];
    let k = 0,
      C, b, N = "";
    r && (k = n.offsetWidth / 2);
    let y, f;
    const x = window.getComputedStyle(t);
    let w = parseInt(x.getPropertyValue("--k-safe-area-top"), 10) || 0,
      S = parseInt(x.getPropertyValue("--k-safe-area-left"), 10) || 0,
      I = parseInt(x.getPropertyValue("--k-safe-area-right"), 10) || 0;
    if (Number.isNaN(w) && (w = 0), Number.isNaN(S) && (S = 0), Number.isNaN(I) && (I = 0), t) {
      a = t.offsetWidth, s = t.offsetHeight;
      const X = t.getBoundingClientRect();
      y = X.left, f = X.top
    } else typeof i < "u" && o !== "undefined" && (y = i, f = o);
    let [M, L, B] = [0, 0, 0];
    const R = u === "ios" ? 13 : 23;
    let _ = "top";
    g + k < f - w ? L = f - g - k : g + k < p - f - s ? (_ = "bottom", L = f + s + k) : (_ = "middle", L = s / 2 + f - g / 2, B = L, L = Math.max(5, Math.min(L, p - g - 5)), B -= L), _ === "top" || _ === "bottom" ? (M = a / 2 + y - v / 2, B = M, M = Math.max(5, Math.min(M, d - v - 5)), S && (M = Math.max(M, S)), I && M + v > d - 5 - I && (M = d - 5 - I - v), _ === "top" && (N = "bottom"), _ === "bottom" && (N = "top"), B -= M, C = v / 2 - k + B, C = Math.max(Math.min(C, v - k * 2 - R), R)) : _ === "middle" && (M = y - v - k, N = "right", (M < 5 || M + v + I > d || M < S) && (M < 5 && (M = y + a + k), M + v + I > d && (M = d - v - 5 - I), M < S && (M = S), N = "left"), b = g / 2 - k + B, b = Math.max(Math.min(b, g - k * 2 - R), R));
    const q = _,
      V = M < y ? "left" : "right";
    return { set: !0, angleTop: typeof b > "u" ? void 0 : `${b}px`, angleLeft: typeof C > "u" ? void 0 : `${C}px`, anglePosition: N, popoverTop: `${L}px`, popoverLeft: `${M}px`, popoverPosition: `${q}-${V}` }
  },
  A0 = (e, t, n) => { const { size: r, translucent: i, angleClassName: o, angleClass: a } = e; return { base: { common: c("transition-transform-opacity z-40 no-safe-areas", Se("fixed", n), r), ios: "duration-300", material: "duration-400 ease-material-in", opened: "", closed: { common: "opacity-0 pointer-events-none", ios: "", material: "scale-x-90 scale-y-75" } }, inner: { common: c("overflow-hidden relative"), ios: c("rounded-xl", i && "translucent", t.bgIos), material: c("rounded-[1.75rem]", t.bgMaterial) }, angleWrap: { common: c(o || a || "", "pointer-events-none"), ios: c("absolute w-6.5 h-6.5 z-50 overflow-hidden", i && "opacity-80"), material: c("absolute w-6.5 h-6.5 z-50 overflow-hidden"), bottom: "top-full", top: "bottom-full", left: "right-full", right: "left-full" }, angleArrow: { common: c("absolute rounded w-full h-full transform rotate-45"), ios: t.bgIos, material: t.bgMaterial, bottom: "-top-4.75", top: "top-4.75", left: "left-4.75", right: "-left-4.75" }, backdrop: { common: "fixed z-40 w-full h-full left-0 top-0 bg-black bg-opacity-50 duration-300", opened: "", closed: "opacity-0 pointer-events-none" } } },
  H0 = (e = {}, t) => ({ bgIos: c("bg-ios-light-surface-3", t("dark:bg-ios-dark-surface-3")), bgMaterial: c("bg-md-light-surface-3", t("dark:bg-md-dark-surface-3")), ...e }),
  ro = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, angle: i = !0, angleClassName: o = "", colors: a, size: s = "w-64", opened: u, backdrop: d = !0, onBackdropClick: p, target: v, targetX: g, targetY: k, targetWidth: C, targetHeight: b, translucent: N = !0, ios: y, material: f, children: x, style: w = {}, ...S } = e, I = m.useRef(null), M = m.useRef(null), [L, B] = m.useState({ set: !1, angleTop: 0, angleLeft: 0, anglePosition: "bottom", popoverTop: 0, popoverLeft: 0, popoverPosition: "top-left" });
    m.useImperativeHandle(t, () => ({ el: I.current }));
    const R = u ? "opened" : "closed",
      _ = n,
      q = { ...S },
      V = fe({ ios: y, material: f }),
      X = H({ ios: y, material: f }),
      ue = Y(),
      ee = H0(a, ue),
      ie = X(A0({ ...e, size: s, angleClassName: o, translucent: N }, ee, r), r),
      T = () => {!v || !I.current || !u || B($0({ popoverEl: I.current, targetEl: v, angleEl: M.current, needsAngle: i, targetX: g, targetY: k, targetHeight: b, targetWidth: C, theme: V })) },
      j = () => { typeof window > "u" || window.addEventListener("resize", T) },
      $ = () => { typeof window > "u" || window.removeEventListener("resize", T) };
    m.useEffect(() => (j(), () => $())), m.useEffect(() => { T() }, [u]);
    const G = L.set ? { ...w || {}, left: L.popoverLeft, top: L.popoverTop } : w,
      J = L.set ? { left: L.angleLeft, top: L.angleTop } : void 0,
      Me = { "top-right": "origin-bottom-left", "top-left": "origin-bottom-right", "middle-left": "origin-right", "middle-right": "origin-left", "bottom-right": "origin-top-left", "bottom-left": "origin-top-right" },
      ce = c(ie.base[R], V === "material" && Me[L.popoverPosition]);
    return h(ut, { children: [d && l("div", { className: ie.backdrop[R], onClick: p }), h(_, { ref: I, className: ce, style: G, ...q, children: [i && l("div", { ref: M, style: J, className: ie.angleWrap[L.anglePosition], children: l("div", { className: ie.angleArrow[L.anglePosition] }) }), l("div", { className: ie.inner, children: x })] })] })
  });
ro.displayName = "Popover";
const q0 = (e, t, n) => { const { size: r } = e; return { base: { common: c("left-1/2 top-1/2 transition-transform transform -translate-x-1/2 z-40 max-w-full max-h-full overflow-hidden md:no-safe-areas", t.bg, Se("fixed", n), r), ios: "duration-400 md:rounded-lg", material: " md:rounded-[1.75rem]", opened: { common: "-translate-y-1/2", material: c("ease-material-in-popup duration-[600ms]") }, closed: { common: "translate-y-full", material: "duration-400" } }, backdrop: { common: "fixed z-40 w-full h-full left-0 top-0 bg-black bg-opacity-50 duration-400", opened: "", closed: "opacity-0 pointer-events-none" } } },
  U0 = (e = {}, t) => ({ bg: c("bg-white", t("dark:bg-black")), ...e }),
  Um = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, size: o = "w-screen h-screen md:w-160 md:h-160", opened: a, backdrop: s = !0, onBackdropClick: u, ios: d, material: p, children: v, ...g } = e, k = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: k.current }));
    const C = a ? "opened" : "closed",
      b = n,
      N = { ...g },
      y = H({ ios: d, material: p }),
      f = Y(),
      x = U0(i, f),
      w = y(q0({ ...e, size: o }, x, r), r);
    return h(ut, { children: [s && l("div", { className: w.backdrop[C], onClick: u }), l(b, { ref: k, className: w.base[C], ...N, children: v })] })
  });
Um.displayName = "Popup";
const W0 = e => h("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 20 20", fill: "currentcolor", ...e, children: [l("path", { d: "M10,0 C10.5522847,0 11,0.44771525 11,1 L11,6 C11,6.55228475 10.5522847,7 10,7 C9.44771525,7 9,6.55228475 9,6 L9,1 C9,0.44771525 9.44771525,0 10,0 Z" }), l("path", { d: "M10,13 C10.5522847,13 11,13.4477153 11,14 L11,19 C11,19.5522847 10.5522847,20 10,20 C9.44771525,20 9,19.5522847 9,19 L9,14 C9,13.4477153 9.44771525,13 10,13 Z", opacity: ".64" }), l("path", { d: "M13,10 C13,9.44771525 13.4477153,9 14,9 L19,9 C19.5522847,9 20,9.44771525 20,10 C20,10.5522847 19.5522847,11 19,11 L14,11 C13.4477153,11 13,10.5522847 13,10 Z", opacity: ".82" }), l("path", { d: "M-3.8285687e-16,10 C-3.8285687e-16,9.44771525 0.44771525,9 1,9 L6,9 C6.55228475,9 7,9.44771525 7,10 C7,10.5522847 6.55228475,11 6,11 L1,11 C0.44771525,11 -3.8285687e-16,10.5522847 -3.8285687e-16,10 Z", opacity: ".46" }), l("path", { d: "M2.92912627,2.92912627 C3.31965056,2.53860197 3.95281554,2.53860197 4.34333983,2.92912627 L7.87887373,6.46466017 C8.26939803,6.85518446 8.26939803,7.48834944 7.87887373,7.87887373 C7.48834944,8.26939803 6.85518446,8.26939803 6.46466017,7.87887373 L2.92912627,4.34333983 C2.53860197,3.95281554 2.53860197,3.31965056 2.92912627,2.92912627 Z", opacity: ".37" }), l("path", { d: "M12.1211263,12.1211263 C12.5116506,11.730602 13.1448155,11.730602 13.5353398,12.1211263 L17.0708737,15.6566602 C17.461398,16.0471845 17.461398,16.6803494 17.0708737,17.0708737 C16.6803494,17.461398 16.0471845,17.461398 15.6566602,17.0708737 L12.1211263,13.5353398 C11.730602,13.1448155 11.730602,12.5116506 12.1211263,12.1211263 Z", opacity: ".73" }), l("path", { d: "M12.1211263,7.87887373 C11.730602,7.48834944 11.730602,6.85518446 12.1211263,6.46466017 L15.6566602,2.92912627 C16.0471845,2.53860197 16.6803494,2.53860197 17.0708737,2.92912627 C17.461398,3.31965056 17.461398,3.95281554 17.0708737,4.34333983 L13.5353398,7.87887373 C13.1448155,8.26939803 12.5116506,8.26939803 12.1211263,7.87887373 Z", opacity: ".91" }), l("path", { d: "M2.92912627,17.0708737 C2.53860197,16.6803494 2.53860197,16.0471845 2.92912627,15.6566602 L6.46466017,12.1211263 C6.85518446,11.730602 7.48834944,11.730602 7.87887373,12.1211263 C8.26939803,12.5116506 8.26939803,13.1448155 7.87887373,13.5353398 L4.34333983,17.0708737 C3.95281554,17.461398 3.31965056,17.461398 2.92912627,17.0708737 Z", opacity: ".55" })] }),
  V0 = e => l("svg", { viewBox: "0 0 36 36", ...e, fill: "none", stroke: "currentcolor", children: l("circle", { cx: "18", cy: "18", r: "16" }) }),
  Q0 = (e, t, n) => { const { size: r } = e; return { base: { common: c(n === "ios" ? "k-ios-preloader" : "k-material-preloader", `inline-block ${r}`), ios: t.iconIos, material: `stroke-4 ${t.iconMaterial}` }, inner: { common: "block w-full h-full" } } },
  Y0 = (e = {}, t) => ({ iconIos: "text-primary", iconMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), ...e }),
  qt = m.forwardRef((e, t) => {
    const { component: n = "span", className: r, colors: i, size: o = "w-8 h-8", ios: a, material: s, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      k = fe({ ios: a, material: s }),
      C = H({ ios: a, material: s }),
      b = Y(),
      N = Y0(i, b),
      y = k === "ios" ? W0 : V0,
      f = C(Q0({ ...e, size: o }, N, k), r);
    return h(v, { ref: p, className: f.base, ...g, children: [l("span", { className: f.inner, children: l(y, { className: "w-full h-full" }) }), u] })
  });
qt.displayName = "Preloader";
const K0 = e => ({ base: { common: "block h-1 bg-opacity-30 dark:bg-opacity-30 overflow-hidden rtl:rotate-180", ios: "bg-black rounded-full", material: e.bgMaterial }, inner: { common: "block duration-200 w-full h-full", ios: e.bgIos, material: e.bgMaterial } }),
  Z0 = (e = {}, t) => ({ bgIos: "bg-primary", bgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), ...e }),
  ir = m.forwardRef((e, t) => {
    const { component: n = "span", className: r, colors: i, ios: o, material: a, progress: s = 0, children: u, ...d } = e, p = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: p.current }));
    const v = n,
      g = { ...d },
      k = H({ ios: o, material: a }),
      C = Y(),
      b = Z0(i, C),
      N = k(K0(b), r);
    return h(v, { ref: p, className: N.base, ...g, children: [l("span", { className: N.inner, style: { transform: `translateX(-${100-s/1*100}%)` } }), u] })
  });
ir.displayName = "Progressbar";
const G0 = (e, t, n, r) => ({ base: c("cursor-pointer inline-flex align-middle", Se("relative", n), r("dark:touch-ripple-white")), iconWrap: { common: "flex items-center justify-center rounded-full", ios: "w-5.5 h-5.5 border", material: "w-5 h-5 border-2", notChecked: { ios: t.borderIos, material: t.borderMaterial }, checked: { ios: t.borderCheckedIos, material: t.borderCheckedMaterial } }, icon: { ios: "text-primary", material: `w-3 h-3 rounded-full ${t.bgCheckedMaterial}`, notChecked: "opacity-0", checked: "opacity-100" }, indeterminateIcon: { common: "bg-white w-3/4", ios: "h-0.25", material: "h-0.5" }, input: { common: "sr-only" } }),
  J0 = (e = {}, t) => ({ borderIos: c("border-black border-opacity-30", t("dark:border-white dark:border-opacity-30")), borderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), bgCheckedIos: "bg-primary", bgCheckedMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), borderCheckedIos: "border-primary", borderCheckedMaterial: c("border-md-light-primary", t("dark:border-md-dark-primary")), ...e }),
  Ee = m.forwardRef((e, t) => {
    const { component: n = "label", className: r, colors: i, defaultChecked: o, checked: a, name: s, value: u, disabled: d, readOnly: p, onChange: v, ios: g, material: k, touchRipple: C = !0, children: b, ...N } = e, y = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: y.current }));
    const f = n,
      x = { ...N },
      w = fe({ ios: g, material: k }),
      S = H({ ios: g, material: k }),
      I = Y();
    $t(y, w === "material" && C);
    const M = J0(i, I),
      L = a || o && !v ? "checked" : "notChecked",
      B = S(G0(e, M, r, I), r);
    return h(f, { ref: y, className: B.base, ...x, children: [l("input", { type: "radio", name: s, value: u, disabled: d, readOnly: p, checked: a, defaultChecked: o, onChange: v, className: B.input }), l("i", { className: B.iconWrap[L], children: w === "ios" ? l(_m, { className: B.icon[L] }) : l("span", { className: B.icon[L] }) }), b] })
  });
Ee.displayName = "Radio";
const X0 = (e, t, n) => ({ base: { common: "block relative select-none w-full self-center touch-pan-y", ios: "h-7", material: "h-5" }, trackBg: { common: c("absolute top-1/2 left-0 w-full transform -translate-y-1/2 bg-black bg-opacity-20", n("dark:bg-white dark:bg-opacity-20")), ios: "h-1 rounded-full", material: "h-0.5" }, trackValue: { common: "absolute top-1/2 start-0 w-full transform -translate-y-1/2", ios: `h-1 rounded-full ${t.valueBgIos}`, material: `h-0.5 ${t.valueBgMaterial}` }, input: { common: "appearance-none w-full bg-transparent cursor-pointer block focus:outline-none relative", ios: "h-7", material: "h-5" }, inputThumb: { common: "range-thumb:relative range-thumb:appearance-none range-thumb:rounded-full range-thumb:border-none", ios: `range-thumb:w-7 range-thumb:h-7 range-thumb:-mt-3.5 ${t.thumbBgIos} range-thumb:shadow-ios-toggle`, material: `range-thumb:w-3 range-thumb:h-3 ${t.thumbBgMaterial} range-thumb:-mt-1.5 range-thumb:transform range-thumb:duration-200 active:range-thumb:scale-150` }, inputTrack: { common: "range-track:appearance-none range-track:h-px" } }),
  ev = (e = {}, t) => ({ valueBgIos: "bg-primary", valueBgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), thumbBgIos: "range-thumb:bg-white", thumbBgMaterial: c("range-thumb:bg-md-light-primary", t("dark:range-thumb:bg-md-dark-primary")), ...e }),
  lr = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, children: s, inputId: u, name: d, value: p = void 0, defaultValue: v, readOnly: g, disabled: k, step: C = 1, min: b = 0, max: N = 100, onInput: y, onChange: f, onFocus: x, onBlur: w, ...S } = e, I = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: I.current }));
    const M = n,
      L = { ...S },
      B = H({ ios: o, material: a }),
      R = Y(),
      _ = ev(i, R),
      q = B(X0(e, _, R), r),
      V = ((p || 0) - b) / (N - b) * 100;
    return h(M, { ref: I, className: q.base, ...L, children: [l("span", { className: q.trackBg }), l("span", { className: q.trackValue, style: { width: `${V}%` } }), l("input", { className: c(q.input, q.inputThumb, q.inputTrack), type: "range", id: u, name: d, min: b, max: N, step: C, value: p, defaultValue: v, readOnly: g, disabled: k, onInput: y, onChange: f, onFocus: x, onBlur: w })] })
  });
lr.displayName = "Range";
const tv = (e, t, { isEnabled: n, darkClasses: r }) => ({ base: { common: "relative flex overflow-hidden items-center", ios: "px-2 w-full", material: "px-0 py-2 -mx-2 w-[calc(100%+32px)]" }, inner: { common: "w-full shrink-1 relative", ios: "transition-all duration-300" }, searchIconWrap: { common: "absolute inset-y-0 flex items-center z-40", ios: "start-2", material: "start-4" }, clearButton: { common: "absolute justify-center inset-y-0 flex items-center z-40 cursor-pointer end-0", ios: "w-8 h-8", material: "w-12 h-12" }, input: { common: "block appearance-none  w-full py-2  focus:outline-none z-30", ios: c("h-8 bg-black/10 pl-7 pr-7 rounded-lg text-base", r("dark:placeholder-white dark:placeholder-opacity-30 dark:bg-white/10"), t.placeholderIos, t.inputBgIos), material: c("h-12 ps-12 pe-4 rounded-full", t.placeholderMaterial, t.inputBgMaterial) }, deleteIcon: { common: "", ios: "w-3.5 h-3.5 opacity-45", material: "w-6 h-6 active:opacity-20" }, searchIcon: { common: "", ios: c("w-4 h-4 opacity-45"), material: c("w-5 h-5 z-30", n ? "opacity-0 transform rotate-90 scale-50 transition-transform-opacity  duration-400 " : "block transform transition-transform-opacity scale-100 rotate-0 duration-400") }, cancelButton: { ios: c("ps-2 flex items-center h-8 cursor-pointer bg-transparent text-primary shrink-0 z-40 transition-all duration-300 active:opacity-30", n ? "" : "opacity-0"), material: c("absolute left-4 cursor-pointer", n ? "z-40 transform scale-100 rotate-0 transition-transform-opacity  duration-400" : "opacity-0 transform -rotate-90 scale-50 transition-transform-opacity duration-400") } }),
  nv = (e = {}, t) => ({ inputBgIos: "", inputBgMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), placeholderIos: "", placeholderMaterial: c("placeholder-md-light-on-surface-variant", t("dark:placeholder-md-dark-on-surface-variant")), ...e }),
  rv = ({ theme: e, ...t }) => e === "ios" ? l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "13", height: "13", viewBox: "0 0 56 56", fill: "currentcolor", ...t, children: l("path", { d: "M 23.9570 41.7695 C 27.8476 41.7695 31.4804 40.5039 34.4336 38.3945 L 45.5429 49.5039 C 46.0585 50.0195 46.7382 50.2774 47.4414 50.2774 C 48.9648 50.2774 50.0664 49.1055 50.0664 47.6055 C 50.0664 46.9023 49.8322 46.2461 49.3162 45.7305 L 38.2773 34.6679 C 40.5976 31.6211 41.9804 27.8476 41.9804 23.7461 C 41.9804 13.8320 33.8710 5.7226 23.9570 5.7226 C 14.0195 5.7226 5.9336 13.8320 5.9336 23.7461 C 5.9336 33.6601 14.0195 41.7695 23.9570 41.7695 Z M 23.9570 37.8789 C 16.1992 37.8789 9.8242 31.4805 9.8242 23.7461 C 9.8242 16.0117 16.1992 9.6133 23.9570 9.6133 C 31.6914 9.6133 38.0898 16.0117 38.0898 23.7461 C 38.0898 31.4805 31.6914 37.8789 23.9570 37.8789 Z" }) }) : l("svg", { xmlns: "http://www.w3.org/2000/svg", width: "48", height: "48", viewBox: "0 0 56 56", fill: "currentcolor", ...t, children: l("path", { d: "M 23.9570 41.7695 C 27.8476 41.7695 31.4804 40.5039 34.4336 38.3945 L 45.5429 49.5039 C 46.0585 50.0195 46.7382 50.2774 47.4414 50.2774 C 48.9648 50.2774 50.0664 49.1055 50.0664 47.6055 C 50.0664 46.9023 49.8322 46.2461 49.3162 45.7305 L 38.2773 34.6679 C 40.5976 31.6211 41.9804 27.8476 41.9804 23.7461 C 41.9804 13.8320 33.8710 5.7226 23.9570 5.7226 C 14.0195 5.7226 5.9336 13.8320 5.9336 23.7461 C 5.9336 33.6601 14.0195 41.7695 23.9570 41.7695 Z M 23.9570 37.8789 C 16.1992 37.8789 9.8242 31.4805 9.8242 23.7461 C 9.8242 16.0117 16.1992 9.6133 23.9570 9.6133 C 31.6914 9.6133 38.0898 16.0117 38.0898 23.7461 C 38.0898 31.4805 31.6914 37.8789 23.9570 37.8789 Z" }) }),
  Wm = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, placeholder: o = "Search", value: a, inputId: s, inputStyle: u, disableButton: d = !1, disableButtonText: p = "Cancel", clearButton: v = !0, onInput: g, onChange: k, onFocus: C, onBlur: b, onClear: N, onDisable: y, ios: f, material: x, ...w } = e, S = m.useRef(null), I = m.useRef(null), M = m.useRef(null), [L, B] = m.useState(0), R = m.useRef(null), _ = m.useRef(!1);
    m.useImperativeHandle(t, () => ({ el: I.current, searchEl: S.current }));
    const [q, V] = m.useState(!1), X = fe({ ios: f, material: x }), ue = H({ ios: f, material: x }), ee = Y(), ie = nv(i, ee), T = ve => { g && g(ve) }, j = ve => { k && k(ve) }, $ = ve => { V(!0), C && C(ve) }, G = ve => { b && b(ve) }, J = () => { a || (R.current = setTimeout(() => { V(!1) })) }, Me = () => { clearTimeout(R.current) }, ce = ve => { ve.preventDefault(), V(!1), S.current && S.current.blur(), y && y(), N && N() };
    m.useEffect(() => { M.current && B(M.current.offsetWidth), requestAnimationFrame(() => { requestAnimationFrame(() => { _.current = !0 }) }) }, []);
    const de = ue(tv({ ...e }, ie, { isEnabled: q, darkClasses: ee })),
      Ce = X === "ios" ? l("button", { type: "button", ref: M, style: { marginRight: q ? 0 : `-${L}px`, transitionDuration: _.current ? "" : "0ms" }, className: de.cancelButton, onClick: ce, onPointerDown: ve => ve.preventDefault(), children: p }) : l(qm, { theme: X, onClick: ce, className: c(de.cancelButton), onPointerDown: ve => ve.preventDefault() }),
      ge = n,
      _e = { ...w };
    return h(ge, { ref: I, className: de.base, ..._e, onBlurCapture: J, onFocusCapture: Me, children: [h("div", { className: de.inner, children: [l("span", { className: de.searchIconWrap, children: l(rv, { ios: f, material: x, className: de.searchIcon }) }), l("input", { id: s, ref: S, className: c(de.input), style: u, type: "text", name: "search", placeholder: o, value: a, onInput: T, onChange: j, onFocus: $, onBlur: G }), a && v && l("button", { className: de.clearButton, onClick: N, type: "button", children: l(Ni, { theme: X, className: de.deleteIcon }) })] }), d && Ce] })
  });
Wm.displayName = "Searchbar";
const iv = (e, t, n) => { const { outline: r, rounded: i } = e; return { base: { common: "flex justify-center items-center overflow-hidden w-full", square: { ios: "rounded", material: "rounded-lg" }, rounded: "rounded-full" }, raised: r ? "shadow" : "shadow divide-x divide-black divide-opacity-10 rtl:divide-x-reverse", outline: { common: "", ios: `${t.borderIos} border-2`, material: `${t.borderMaterial} border` }, outlineInner: { common: "-m-0.5 flex w-full justify-center items-center rtl:divide-x-reverse", ios: `divide-x-2 ${t.divideIos}`, material: `divide-x ${t.divideMaterial}` }, strong: { common: c("p-0.5 space-x-1 relative"), ios: t.strongBgIos, material: t.strongBgMaterial }, strongHighlight: { common: c("absolute start-0.5 top-0.5 bottom-0.5 !ms-0 pointer-events-none duration-200", i && "rounded-full", "bg-white shadow", n("dark:bg-opacity-15 dark:touch-ripple-white")), ios: c(!i && "rounded"), material: c(!i && "rounded-md") } } },
  lv = (e = {}, t) => ({ strongBgIos: c("bg-black bg-opacity-5", t("dark:bg-white dark:bg-opacity-10")), strongBgMaterial: c("bg-md-light-surface-variant", t("dark:bg-md-dark-surface-variant")), borderIos: "border-primary", borderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), divideIos: "divide-primary", divideMaterial: c("divide-md-light-outline", t("dark:divide-md-dark-outline")), ...e }),
  zt = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, ios: o, material: a, raised: s, outline: u, strong: d, rounded: p, children: v, ...g } = e, k = m.useRef(null), C = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: k.current }));
    const [b, N] = m.useState({ transform: "", width: "" }), y = n, f = { ...g }, x = H({ ios: o, material: a }), w = Y(), S = lv(i, w), I = x(iv(e, S, w)), M = c(p ? I.base.rounded : I.base.square, s && I.raised, u && I.outline, d && I.strong, r);
    return m.useEffect(() => {
      if (d && C.current) {
        const L = C.current.parentElement,
          B = L.children.length - 1,
          R = [...L.children].indexOf(L.querySelector(".k-segmented-strong-button-active")),
          _ = "4px";
        N({ ...b, width: `calc((100% - 2px * 2 - ${_} * (${B} - 1)) / ${B})`, transform: `translateX(calc((${R} * 100% + ${R} * ${_}) * var(--k-rtl-reverse)))` })
      }
    }, [v]), h(y, { ref: k, className: M, ...f, children: [u ? l("span", { className: I.outlineInner, children: v }) : v, d && l("span", { ref: C, className: I.strongHighlight, style: b })] })
  });
zt.displayName = "Segmented";
const se = m.forwardRef((e, t) => { const { active: n, children: r, outline: i, strong: o, clear: a, rounded: s, ...u } = e, d = m.useRef(null); return m.useImperativeHandle(t, () => ({ el: d.current })), l(O, { ref: d, segmented: !0, segmentedActive: n, segmentedStrong: o, rounded: s && o, ...u, children: r }) });
se.displayName = "SegmentedButton";
const ov = (e, t, n) => ({ base: { common: c("left-0 top-full transition-transform duration-400 z-40 overflow-hidden", Se("fixed", n)), ios: "", material: `rounded-t-2xl ease-material-in ${t.bgIos}`, opened: `-translate-y-full ${t.bgMaterial}`, closed: "" }, backdrop: { common: "fixed z-40 w-full h-full left-0 top-0 bg-black bg-opacity-50 duration-400", opened: "", closed: "opacity-0 pointer-events-none" } }),
  av = (e = {}, t) => ({ bgIos: c("bg-white", t("dark:bg-black")), bgMaterial: c("bg-md-light-surface", t("dark:bg-md-dark-surface")), ...e }),
  Vm = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, opened: o, backdrop: a = !0, onBackdropClick: s, ios: u, material: d, children: p, ...v } = e, g = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: g.current }));
    const k = o ? "opened" : "closed",
      C = n,
      b = { ...v },
      N = H({ ios: u, material: d }),
      y = Y(),
      f = av(i, y),
      x = N(ov(e, f, r), r);
    return h(ut, { children: [a && l("div", { className: x.backdrop[k], onClick: s }), l(C, { ref: g, className: x.base[k], ...b, children: p })] })
  });
Vm.displayName = "Sheet";
const sv = (e, t) => { const { buttonsOnly: n } = e; return { base: `${t.text} inline-flex items-stretch`, raised: "shadow", size: { small: { ios: "h-6", material: "h-8" }, medium: { ios: "h-7", material: "h-10" }, large: { ios: "h-11", material: "h-12" } }, shape: { square: { ios: "rounded", material: "rounded-lg" }, rounded: "rounded-full" }, button: { common: "relative flex items-center justify-center w-10 cursor-pointer overflow-hidden z-10 select-none" }, buttonLeftShape: { square: { ios: "rounded-s", material: "rounded-s-lg" }, rounded: "rounded-s-full" }, buttonRightShape: { square: { ios: "rounded-e", material: "rounded-e-lg" }, rounded: "rounded-e-full" }, buttonStyle: { fill: { common: c(t.fillTouchRipple, n && "first:border-r border-black border-opacity-10 rtl:first:border-l rtl:first:border-r-0"), ios: c(t.fillBgIos, t.fillTextIos, t.fillActiveBgIos), material: c(t.fillBgMaterial, t.fillTextMaterial, t.fillActiveBgMaterial) }, outline: { common: c(t.touchRipple, "active:bg-opacity-15", n && "first:border-r-0 rtl:last:border-r-0"), ios: c("border-2", t.textIos, t.activeBgIos, t.outlineBorderIos, n && "rtl:first:border-r-2"), material: c("border", t.textMaterial, t.activeBgMaterial, t.outlineBorderMaterial, n && "rtl:first:border-r") }, clear: { common: `${t.touchRipple} active:bg-opacity-15 last:border-l rtl:last:border-l-0 rtl:first:border-l border-black border-opacity-10`, ios: c(t.textIos, t.activeBgIos), material: c(t.textMaterial, t.activeBgMaterial) } }, input: { common: "focus:outline-none text-center appearance-none bg-transparent" }, value: { common: "w-11 flex items-center justify-center font-medium", ios: `text-base ${t.textIos}`, material: `text-sm ${t.textMaterial}`, fill: { common: "", ios: `border-t-2 border-b-2 ${t.outlineBorderIos}`, material: `border-t border-b ${t.outlineBorderMaterial}` }, outline: { common: "", ios: `border-t-2 border-b-2 ${t.outlineBorderIos}`, material: `border-t border-b ${t.outlineBorderMaterial}` }, clear: "border-l border-black border-opacity-10" }, hBar: "w-4 h-0.5 bg-current block", vBar: "w-0.5 h-4 bg-current block absolute inset-1/2 transform -translate-x-1/2 rtl:translate-x-1/2 -translate-y-1/2" } },
  uv = (e = {}, t) => ({ activeBgIos: "active:bg-primary", activeBgMaterial: "", textIos: "text-primary", textMaterial: c("text-md-light-primary", "dark:text-md-dark-primary"), fillTextIos: c("text-white"), fillTextMaterial: c("text-md-light-on-primary", t("dark:text-md-dark-on-primary")), fillBgIos: "bg-primary", fillBgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), fillActiveBgIos: "active:bg-ios-primary-shade", fillActiveBgMaterial: "", fillTouchRipple: c("touch-ripple-white", "dark:touch-ripple-primary"), outlineBorderIos: "border-primary", outlineBorderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), touchRipple: "touch-ripple-primary", ...e }),
  le = m.forwardRef((e, t) => {
    const { component: n = "span", className: r, colors: i, value: o = 0, defaultValue: a, input: s = !1, inputType: u = "text", inputPlaceholder: d, inputDisabled: p, inputReadOnly: v, buttonsOnly: g, rounded: k, roundedIos: C, roundedMaterial: b, small: N, smallIos: y, smallMaterial: f, large: x, largeIos: w, largeMaterial: S, raised: I, raisedIos: M, raisedMaterial: L, outline: B, outlineIos: R, outlineMaterial: _, onInput: q, onChange: V, onFocus: X, onBlur: ue, onMinus: ee, onPlus: ie, ios: T, material: j, touchRipple: $ = !0, children: G, ...J } = e, Me = m.useRef(null), ce = m.useRef(null), de = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: Me.current }));
    const Ce = n,
      ge = fe({ ios: T, material: j }),
      _e = H({ ios: T, material: j });
    $t(ce, ge === "material" && $), $t(de, ge === "material" && $);
    const ve = typeof k > "u" ? ge === "ios" ? C : b : k,
      qe = typeof N > "u" ? ge === "ios" ? y : f : N,
      Mt = typeof x > "u" ? ge === "ios" ? w : S : x,
      Ze = typeof I > "u" ? ge === "ios" ? M : L : I,
      yt = typeof B > "u" ? ge === "ios" ? R : _ : B,
      je = Y(),
      ct = uv(i, je),
      dt = Mt ? "large" : qe ? "small" : "medium",
      Ue = yt && Ze ? "clear" : yt ? "outline" : "fill",
      Lt = ve ? "rounded" : "square",
      oe = _e(sv({ ...e, rounded: ve, small: qe, large: Mt, raised: Ze, outline: yt }, ct)),
      Ge = { ...J },
      xt = c(oe.base, Ze && oe.raised, oe.size[dt], oe.shape[Lt], r),
      At = c(oe.button, oe.buttonStyle[Ue], oe.buttonLeftShape[Lt]),
      rt = c(oe.button, oe.buttonStyle[Ue], oe.buttonRightShape[Lt]),
      kt = c(s && oe.input, oe.value[Ue]);
    return h(Ce, { ref: Me, className: xt, ...Ge, children: [l("span", { ref: ce, className: At, role: "button", tabIndex: "0", onClick: ee, children: l("span", { className: oe.hBar }) }), s && !g && l("input", { className: kt, placeholder: d, type: u, value: o, defaultValue: a, disabled: p, readOnly: v, onInput: q, onChange: V, onFocus: X, onBlur: ue }), !s && !g && l("span", { className: kt, children: o }), h("span", { ref: de, className: rt, role: "button", tabIndex: "0", onClick: ie, children: [l("span", { className: oe.hBar }), l("span", { className: oe.vBar })] })] })
  });
le.displayName = "Stepper";
const Ws = m.forwardRef((e, t) => {
  const { labels: n, icons: r, children: i, ...o } = e, a = m.useRef(null);
  m.useImperativeHandle(t, () => ({ el: a.current }));
  const s = { ...o };
  return l(Ti, { ref: a, tabbar: !0, tabbarIcons: r, tabbarLabels: n, ...s, children: i })
});
Ws.displayName = "Tabbar";
const cv = ({ hasIcon: e, hasLabel: t, active: n } = {}, r = {}) => ({ content: { common: "flex flex-col items-center justify-center h-full", ios: c("py-1", n ? r.textActiveIos : r.textIos), material: c("py-2", e && t && "space-y-1", n ? r.textActiveMaterial : r.textMaterial) }, iconContainer: { common: "flex items-center justify-center k-tabbar-link-icon relative", ios: c("w-7 h-7"), material: c("w-16 h-8 rounded-full") }, iconBg: { common: "absolute left-0 top-0 w-full h-full rounded-full duration-200 -z-10 pointer-events-none", ios: c(n ? r.iconBgActiveIos : r.iconBgIos), material: c(n ? r.iconBgActiveMaterial : r.iconBgMaterial, !n && "scale-x-[0.5] opacity-0") }, label: { ios: c(e ? "text-xs font-medium" : "", ""), material: c(e ? "text-xs" : "text-sm", "font-medium") } }),
  dv = (e = {}, t) => ({ textIos: c("text-black text-opacity-40", t("dark:text-white dark:text-opacity-55")), textActiveIos: "text-primary", textMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), textActiveMaterial: c("text-md-light-on-secondary-container", t("dark:text-md-dark-on-secondary-container")), iconBgIos: "", iconBgActiveIos: "", iconBgMaterial: "", iconBgActiveMaterial: c("bg-md-light-secondary-container", t("dark:bg-md-dark-secondary-container")), ...e }),
  Vn = m.forwardRef((e, t) => {
    const { className: n, active: r, ios: i, material: o, colors: a, linkProps: s = {}, icon: u, label: d, children: p, ...v } = e, g = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: g.current }));
    const k = { ...s, ...v },
      C = Y(),
      b = dv(a, C),
      N = H({ ios: i, material: o }),
      y = !!u,
      f = d || p && p.length,
      x = N(cv({ hasLabel: f, hasIcon: y, active: r }, b));
    return l(te, { ref: g, tabbar: !0, tabbarActive: r, className: n, ...k, children: h("span", { className: x.content, children: [u && h("span", { className: x.iconContainer, children: [l("span", { className: x.iconBg }), u] }), (d || p && p.length) && h("span", { className: x.label, children: [d, p] })] }) })
  });
Vn.displayName = "TabbarLink";
const mv = () => ({ base: { common: "w-full border-none p-0 m-0 border-collapse text-left table", ios: "", material: "" } }),
  $a = m.forwardRef((e, t) => {
    const { className: n, ios: r, material: i, children: o, ...a } = e, s = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: s.current }));
    const d = H({ ios: r, material: i })(mv({ ...e })),
      p = { ...a };
    return l("table", { className: d.base, ref: s, ...p, children: o })
  });
$a.displayName = "Table";
const fv = () => ({ base: { common: "text-sm", ios: "", material: "" } }),
  Aa = m.forwardRef((e, t) => {
    const { className: n, ios: r, material: i, children: o, ...a } = e, s = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: s.current }));
    const d = H({ ios: r, material: i })(fv({ ...e })),
      p = { ...a };
    return l("tbody", { className: d.base, ref: s, ...p, children: o })
  });
Aa.displayName = "TableBody";
const pv = (e, t, n) => { const { header: r } = e; return { base: { common: c("align-middle", n), ios: c(r ? `text-xs font-semibold overflow-hidden whitespace-nowrap leading-4 h-11 bg-transparent ${t.textHeaderIos} py-0 px-4` : "h-11 relative py-0 px-4"), material: c(r ? `${t.textHeaderMaterial} px-6 py-0  text-xs font-medium overflow-hidden text-ellipsis whitespace-nowrap leading-4 h-14 bg-transparent` : "py-0 first:px-6 px-7 h-12") } } },
  hv = (e = {}, t) => ({ textHeaderIos: c("text-black/45", t("dark:text-white/55")), textHeaderMaterial: c("text-md-light-on-surface-variant", t("dark:text-md-dark-on-surface-variant")), ...e }),
  W = m.forwardRef((e, t) => {
    const { className: n, colors: r, header: i, ios: o, material: a, children: s, ...u } = e, d = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: d.current }));
    const p = i ? "th" : "td",
      v = H({ ios: o, material: a }),
      g = Y(),
      k = hv(r, g),
      C = v(pv({ ...e }, k, n)),
      b = { ...u };
    return l(p, { className: C.base, ref: d, ...b, children: s })
  });
W.displayName = "TableCell";
const gv = () => ({ base: { common: "align-middle relative", ios: "hairline-b", material: "" } }),
  Ha = m.forwardRef((e, t) => {
    const { className: n, ios: r, material: i, children: o, ...a } = e, s = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: s.current }));
    const d = H({ ios: r, material: i })(gv({ ...e })),
      p = { ...a };
    return l("thead", { className: d.base, ref: s, ...p, children: o })
  });
Ha.displayName = "TableHead";
const vv = (e, t) => { const { header: n } = e; return { base: { common: "align-middle relative", ios: n ? "" : c(t.bgIos, "hairline-b last:hairline-transparent"), material: n ? "" : c(t.bgMaterial, `border-t ${t.dividerMaterial}`) } } },
  yv = (e = {}, t) => ({ bgIos: c("hover:bg-black/5", t("dark:hover:bg-white/10")), bgMaterial: c("hover:bg-md-light-secondary-container", t("dark:hover:bg-md-dark-secondary-container")), dividerMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), ...e }),
  Et = m.forwardRef((e, t) => {
    const { className: n, colors: r, header: i, ios: o, material: a, children: s, ...u } = e, d = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: d.current }));
    const p = H({ ios: o, material: a }),
      v = Y(),
      g = yv(r, v),
      k = p(vv({ ...e }, g)),
      C = { ...u };
    return l("tr", { className: k.base, ref: d, ...C, children: s })
  });
Et.displayName = "TableRow";
const xv = (e, t, n) => { const { translucent: r, opened: i } = e; return { base: { common: c(Se("fixed", n), "z-50 transform transition-transform-opacity w-full sm:w-auto start-0 bottom-0 sm:max-w-lg", !i && "translate-y-full opacity-0 pointer-events-none"), ios: c("sm:rounded-lg duration-300", t.textIos, t.bgIos, r && "translucent"), material: c("sm:rounded-2xl duration-200", t.textMaterial, t.bgMaterial), left: "sm:start-4-safe sm:bottom-4-safe", right: "sm:end-4-safe sm:bottom-4-safe sm:start-auto", center: "sm:left-1/2 sm:bottom-4-safe sm:-translate-x-1/2" }, content: { common: "flex items-center justify-between", ios: "pl-4-safe pr-4-safe pt-3 pb-3-safe sm:px-4 sm:py-3", material: "pl-6-safe pr-6-safe py-3.5 pb-3.5-safe sm:px-6 sm:py-3.5" }, button: { common: "-my-2 shrink-0 ms-4", ios: "", material: "-me-2" } } },
  kv = (e = {}, t) => ({ bgIos: "bg-black", bgMaterial: c("bg-md-light-surface-5", t("dark:bg-md-dark-surface-5")), textIos: "text-white", textMaterial: c("text-md-light-primary", t("dark:text-md-dark-primary")), ...e }),
  dl = m.forwardRef((e, t) => {
    const { component: n = "div", className: r, colors: i, translucent: o = !0, button: a, position: s = "left", opened: u, ios: d, material: p, children: v, ...g } = e, k = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: k.current }));
    const C = n,
      b = { ...g },
      N = H({ ios: d, material: p }),
      y = Y(),
      f = kv(i, y),
      x = N(xv({ ...e, translucent: o }, f, r), r);
    return l(C, { ref: k, className: x.base[s], ...b, children: h("div", { className: x.content, children: [v, a && l("div", { className: x.button, children: a })] }) })
  });
dl.displayName = "Toast";
const bv = (e, t, n, r) => ({ base: { common: c(Se("relative", n), "cursor-pointer select-none inline-block align-middle relative duration-300 rounded-full group", r("dark:touch-ripple-white")), ios: "h-8 w-13 p-0.5", material: "w-13 h-8 border-2", notChecked: { ios: t.bgIos, material: c(t.bgMaterial, t.borderMaterial) }, checked: { ios: `${t.checkedBgIos}`, material: c(t.checkedBgMaterial, t.checkedBorderMaterial) } }, inner: { ios: c("w-full h-full bg-white rounded-full block duration-300 transform", r("dark:bg-opacity-0")), notChecked: {}, checked: { ios: "scale-0" } }, thumbWrap: { common: "rounded-full absolute duration-300 transform", ios: "w-7 h-7 start-0.5 top-0.5", material: "w-6 h-6 start-0.5 top-0.5", checked: { ios: c("translate-x-5 rtl:!-translate-x-5"), material: c("translate-x-5 rtl:!-translate-x-5") }, notChecked: "" }, thumb: { common: "w-full h-full rounded-full absolute duration-300 transform start-0 top-0", ios: "shadow-ios-toggle", material: "group-active:scale-[1.1]", checked: { ios: c(t.checkedThumbBgIos), material: c(t.checkedThumbBgMaterial) }, notChecked: { ios: t.thumbBgIos, material: c("scale-[0.666]", t.thumbBgMaterial) } }, input: { common: "sr-only" } }),
  Cv = (e = {}, t) => ({ bgIos: c("bg-black bg-opacity-10", t("dark:bg-white dark:bg-opacity-20")), checkedBgIos: "bg-primary", thumbBgIos: "bg-white", checkedThumbBgIos: "bg-white", bgMaterial: c("bg-md-light-surface-variant", t("dark:bg-md-dark-surface-variant")), checkedBgMaterial: c("bg-md-light-primary", t("dark:bg-md-dark-primary")), borderMaterial: c("border-md-light-outline", t("dark:border-md-dark-outline")), checkedBorderMaterial: c("border-md-light-primary", t("dark:border-md-dark-primary")), thumbBgMaterial: c("bg-md-light-outline", t("dark:bg-md-dark-outline")), checkedThumbBgMaterial: c("bg-md-light-on-primary", t("dark:bg-md-dark-on-primary")), ...e }),
  tn = m.forwardRef((e, t) => {
    const { component: n = "label", className: r, colors: i, defaultChecked: o, checked: a, name: s, value: u, disabled: d, readOnly: p, onChange: v, touchRipple: g = !0, ios: k, material: C, children: b, ...N } = e, y = m.useRef(null), f = m.useRef(null);
    m.useImperativeHandle(t, () => ({ el: y.current }));
    const x = n,
      w = { ...N },
      S = fe({ ios: k, material: C }),
      I = H({ ios: k, material: C }),
      M = Y();
    $t(f, S === "material" && g, y);
    const L = Cv(i, M),
      B = a || o && !v ? "checked" : "notChecked",
      R = I(bv(e, L, r, M), r);
    return h(x, { ref: y, className: R.base[B], ...w, children: [l("input", { type: "checkbox", name: s, value: u, disabled: d, readOnly: p, checked: a, defaultChecked: o, onChange: v, className: R.input }), l("span", { className: R.inner[B] }), l("span", { ref: f, className: R.thumbWrap[B], children: l("span", { className: R.thumb[B] }) }), b] })
  });
tn.displayName = "Toggle";

function Qm() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    [r, i] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Action Sheet", left: !e && l(re, { onClick: () => history.back() }) }), l(D, { strong: !0, inset: !0, className: "space-y-4", children: l("p", { children: "Action Sheet is a slide-up pane for presenting the user with a set of alternatives for how to proceed with a given task. SmoothX" }) }), l(z, { children: "Open Action Sheet" }), h(D, { strong: !0, inset: !0, className: "flex space-x-4 rtl:space-x-reverse", children: [l(O, { onClick: () => n(!0), children: "One group" }), l(O, { onClick: () => i(!0), children: "Two groups" })] }), l(Da, { opened: t, onBackdropClick: () => n(!1), children: h(ul, { children: [l(Fa, { children: "Do something" }), l(Dn, { onClick: () => n(!1), bold: !0, children: "Button 1" }), l(Dn, { onClick: () => n(!1), children: "Button 2" }), l(Dn, { onClick: () => n(!1), children: "Cancel" })] }) }), h(Da, { opened: r, onBackdropClick: () => i(!1), children: [h(ul, { children: [l(Fa, { children: "Do something" }), l(Dn, { onClick: () => i(!1), bold: !0, children: "Button 1" }), l(Dn, { onClick: () => i(!1), children: "Button 2" })] }), l(ul, { children: l(Dn, { onClick: () => i(!1), children: "Cancel" }) })] })] })
}
Qm.displayName = "ActionSheetPage";

function qa() { return qa = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, qa.apply(this, arguments) }

function wv(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Nv(e) { e.children; var t = wv(e, ["children"]); return ke.createElement("svg", qa({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { d: "M 27.9999 51.9063 C 41.0546 51.9063 51.9063 41.0781 51.9063 28 C 51.9063 14.9453 41.0312 4.0937 27.9765 4.0937 C 14.8983 4.0937 4.0937 14.9453 4.0937 28 C 4.0937 41.0781 14.9218 51.9063 27.9999 51.9063 Z M 27.9999 14.8516 C 28.5624 14.8516 29.0077 15.0859 29.5234 15.5781 L 38.1483 24.2266 C 38.4530 24.5547 38.6874 25 38.6874 25.5390 C 38.6874 26.5937 37.8671 27.4141 36.8124 27.4141 C 36.2499 27.4141 35.7812 27.2031 35.4530 26.8516 L 32.3124 23.6641 L 29.7109 20.5703 L 29.9218 25.9844 L 29.9218 39.2734 C 29.9218 40.3984 29.1249 41.1719 27.9999 41.1719 C 26.8749 41.1719 26.0780 40.3984 26.0780 39.2734 L 26.0780 25.9844 L 26.2655 20.5937 L 23.7109 23.6641 L 20.5468 26.8516 C 20.2187 27.1797 19.7265 27.4141 19.1874 27.4141 C 18.1093 27.4141 17.3358 26.5937 17.3358 25.5390 C 17.3358 25 17.5234 24.5547 17.8514 24.2266 L 26.4999 15.5781 C 27.0155 15.0625 27.4374 14.8516 27.9999 14.8516 Z" })) }

function Ua() { return Ua = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Ua.apply(this, arguments) }

function Iv(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Ym(e) { e.children; var t = Iv(e, ["children"]); return ke.createElement("svg", Ua({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { d: "M 11.9923 49.5742 L 44.0079 49.5742 C 48.9066 49.5742 51.3671 47.1367 51.3671 42.3086 L 51.3671 13.6914 C 51.3671 8.8633 48.9066 6.4258 44.0079 6.4258 L 11.9923 6.4258 C 7.1173 6.4258 4.6329 8.8398 4.6329 13.6914 L 4.6329 42.3086 C 4.6329 47.1602 7.1173 49.5742 11.9923 49.5742 Z M 11.6642 45.8008 C 9.5782 45.8008 8.4064 44.6992 8.4064 42.5195 L 8.4064 20.4180 C 8.4064 18.2617 9.5782 17.1367 11.6642 17.1367 L 44.3126 17.1367 C 46.3985 17.1367 47.5938 18.2617 47.5938 20.4180 L 47.5938 42.5195 C 47.5938 44.6992 46.3985 45.8008 44.3126 45.8008 Z M 23.4064 25.5508 L 24.7892 25.5508 C 25.6095 25.5508 25.8907 25.3164 25.8907 24.4961 L 25.8907 23.1133 C 25.8907 22.2930 25.6095 22.0352 24.7892 22.0352 L 23.4064 22.0352 C 22.5860 22.0352 22.3282 22.2930 22.3282 23.1133 L 22.3282 24.4961 C 22.3282 25.3164 22.5860 25.5508 23.4064 25.5508 Z M 31.2111 25.5508 L 32.5704 25.5508 C 33.4142 25.5508 33.6720 25.3164 33.6720 24.4961 L 33.6720 23.1133 C 33.6720 22.2930 33.4142 22.0352 32.5704 22.0352 L 31.2111 22.0352 C 30.3907 22.0352 30.1095 22.2930 30.1095 23.1133 L 30.1095 24.4961 C 30.1095 25.3164 30.3907 25.5508 31.2111 25.5508 Z M 38.9923 25.5508 L 40.3751 25.5508 C 41.1954 25.5508 41.4767 25.3164 41.4767 24.4961 L 41.4767 23.1133 C 41.4767 22.2930 41.1954 22.0352 40.3751 22.0352 L 38.9923 22.0352 C 38.1720 22.0352 37.8907 22.2930 37.8907 23.1133 L 37.8907 24.4961 C 37.8907 25.3164 38.1720 25.5508 38.9923 25.5508 Z M 15.6251 33.2149 L 17.0079 33.2149 C 17.8282 33.2149 18.1095 32.9805 18.1095 32.1602 L 18.1095 30.7774 C 18.1095 29.9571 17.8282 29.7227 17.0079 29.7227 L 15.6251 29.7227 C 14.8048 29.7227 14.5235 29.9571 14.5235 30.7774 L 14.5235 32.1602 C 14.5235 32.9805 14.8048 33.2149 15.6251 33.2149 Z M 23.4064 33.2149 L 24.7892 33.2149 C 25.6095 33.2149 25.8907 32.9805 25.8907 32.1602 L 25.8907 30.7774 C 25.8907 29.9571 25.6095 29.7227 24.7892 29.7227 L 23.4064 29.7227 C 22.5860 29.7227 22.3282 29.9571 22.3282 30.7774 L 22.3282 32.1602 C 22.3282 32.9805 22.5860 33.2149 23.4064 33.2149 Z M 31.2111 33.2149 L 32.5704 33.2149 C 33.4142 33.2149 33.6720 32.9805 33.6720 32.1602 L 33.6720 30.7774 C 33.6720 29.9571 33.4142 29.7227 32.5704 29.7227 L 31.2111 29.7227 C 30.3907 29.7227 30.1095 29.9571 30.1095 30.7774 L 30.1095 32.1602 C 30.1095 32.9805 30.3907 33.2149 31.2111 33.2149 Z M 38.9923 33.2149 L 40.3751 33.2149 C 41.1954 33.2149 41.4767 32.9805 41.4767 32.1602 L 41.4767 30.7774 C 41.4767 29.9571 41.1954 29.7227 40.3751 29.7227 L 38.9923 29.7227 C 38.1720 29.7227 37.8907 29.9571 37.8907 30.7774 L 37.8907 32.1602 C 37.8907 32.9805 38.1720 33.2149 38.9923 33.2149 Z M 15.6251 40.9024 L 17.0079 40.9024 C 17.8282 40.9024 18.1095 40.6445 18.1095 39.8242 L 18.1095 38.4414 C 18.1095 37.6211 17.8282 37.3867 17.0079 37.3867 L 15.6251 37.3867 C 14.8048 37.3867 14.5235 37.6211 14.5235 38.4414 L 14.5235 39.8242 C 14.5235 40.6445 14.8048 40.9024 15.6251 40.9024 Z M 23.4064 40.9024 L 24.7892 40.9024 C 25.6095 40.9024 25.8907 40.6445 25.8907 39.8242 L 25.8907 38.4414 C 25.8907 37.6211 25.6095 37.3867 24.7892 37.3867 L 23.4064 37.3867 C 22.5860 37.3867 22.3282 37.6211 22.3282 38.4414 L 22.3282 39.8242 C 22.3282 40.6445 22.5860 40.9024 23.4064 40.9024 Z M 31.2111 40.9024 L 32.5704 40.9024 C 33.4142 40.9024 33.6720 40.6445 33.6720 39.8242 L 33.6720 38.4414 C 33.6720 37.6211 33.4142 37.3867 32.5704 37.3867 L 31.2111 37.3867 C 30.3907 37.3867 30.1095 37.6211 30.1095 38.4414 L 30.1095 39.8242 C 30.1095 40.6445 30.3907 40.9024 31.2111 40.9024 Z" })) }

function Wa() { return Wa = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Wa.apply(this, arguments) }

function Sv(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Pv(e) { e.children; var t = Sv(e, ["children"]); return ke.createElement("svg", Wa({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { d: "M 7.8086 50.3477 L 48.1914 50.3477 C 53.0663 50.3477 55.5508 47.9102 55.5508 43.0820 L 55.5508 18.5430 C 55.5508 13.7149 53.0663 11.3008 48.1914 11.3008 L 42.7069 11.3008 C 40.8789 11.3008 40.3164 10.9258 39.2617 9.7539 L 37.3633 7.6445 C 36.2149 6.3555 35.0196 5.6523 32.5820 5.6523 L 23.2539 5.6523 C 20.8398 5.6523 19.6445 6.3555 18.4727 7.6445 L 16.5742 9.7539 C 15.5430 10.9023 14.9571 11.3008 13.1289 11.3008 L 7.8086 11.3008 C 2.9336 11.3008 .4492 13.7149 .4492 18.5430 L .4492 43.0820 C .4492 47.9102 2.9336 50.3477 7.8086 50.3477 Z M 27.9883 42.8477 C 20.9102 42.8477 15.2149 37.1523 15.2149 30.0273 C 15.2149 22.9023 20.9102 17.2071 27.9883 17.2071 C 35.1133 17.2071 40.7852 22.9023 40.7852 30.0273 C 40.7852 37.1523 35.0898 42.8477 27.9883 42.8477 Z M 44.8400 24.3086 C 43.2460 24.3086 41.9336 23.0195 41.9336 21.4258 C 41.9336 19.8086 43.2460 18.5195 44.8400 18.5195 C 46.4336 18.5195 47.7460 19.8086 47.7460 21.4258 C 47.7460 23.0195 46.4336 24.3086 44.8400 24.3086 Z M 27.9883 39.2852 C 33.0977 39.2852 37.2461 35.1602 37.2461 30.0273 C 37.2461 24.8945 33.0977 20.7695 27.9883 20.7695 C 22.8789 20.7695 18.7539 24.8945 18.7539 30.0273 C 18.7539 35.1602 22.9024 39.2852 27.9883 39.2852 Z" })) }

function Va() { return Va = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Va.apply(this, arguments) }

function Mv(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Km(e) { e.children; var t = Mv(e, ["children"]); return ke.createElement("svg", Va({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { fillRule: "evenodd", d: "M29.956181,36.8524845 L29.956181,43.5739817 C29.956181,44.6785512 29.0607505,45.5739817 27.956181,45.5739817 C26.8516115,45.5739817 25.956181,44.6785512 25.956181,43.5739817 L25.956181,36.8524845 L10.8722742,36.8524845 C5.16179086,36.8524845 0.532529419,32.223223 0.532529419,26.5127397 C0.532529419,21.6045779 3.95235292,17.4951588 8.5391803,16.4373019 C8.53657409,16.3495183 8.53526178,16.2614098 8.53526178,16.1729948 C8.53526178,11.3440365 12.449906,7.42939227 17.2788644,7.42939227 C18.1407721,7.42939227 18.9735519,7.5541039 19.7601433,7.7864667 C22.5068558,3.56329032 27.2678994,0.770663069 32.6811961,0.770663069 C41.1876691,0.770663069 48.0835279,7.66652189 48.0835279,16.1729948 C48.0835279,16.6568639 48.0612156,17.1355216 48.0175636,17.6079953 C52.3210371,18.6221788 55.524131,22.4871994 55.524131,27.1003427 C55.524131,32.4863019 51.1579484,36.8524845 45.7719893,36.8524845 L29.956181,36.8524845 L29.956181,36.8524845 Z M27.944431,17.0584061 C27.475631,17.0584061 27.053831,17.2224061 26.585031,17.6912061 L18.663131,25.3318061 C18.311631,25.6834061 18.124131,26.0584061 18.124131,26.5740061 C18.124131,27.5349061 18.850631,28.2146061 19.835031,28.2146061 C20.280331,28.2146061 20.772531,28.0271061 21.100631,27.6521061 L24.639731,23.8787061 L26.233531,22.2146061 L26.092831,25.7068061 L26.092831,35.6869731 C26.092831,36.6712731 26.936631,37.4916731 27.944431,37.4916731 C28.952231,37.4916731 29.819431,36.6712731 29.819431,35.6869731 L29.819431,25.7068061 L29.655331,22.2146061 L31.249131,23.8787061 L34.811631,27.6521061 C35.139731,28.0271061 35.631931,28.2146061 36.100631,28.2146061 C37.085031,28.2146061 37.788231,27.5349061 37.788231,26.5740061 C37.788231,26.0584061 37.577231,25.6834061 37.225631,25.3318061 L29.303831,17.6912061 C28.835031,17.2224061 28.436631,17.0584061 27.944431,17.0584061 Z", transform: "translate(0 3)" })) }

function Qa() { return Qa = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Qa.apply(this, arguments) }

function Lv(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Zm(e) { e.children; var t = Lv(e, ["children"]); return ke.createElement("svg", Qa({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { d: "M 28.0468 30.7070 C 29.0312 30.7070 29.9218 30.2617 30.9296 29.2305 L 51.3200 9.0508 C 50.4532 8.2070 48.8360 7.8086 46.5157 7.8086 L 8.7812 7.8086 C 6.8124 7.8086 5.4296 8.1836 4.6562 8.9570 L 25.1640 29.2305 C 26.1718 30.2383 27.0858 30.7070 28.0468 30.7070 Z M 2.7109 44.4180 L 19.2812 28.0352 L 2.6640 11.6523 C 2.3124 12.3086 2.1249 13.4336 2.1249 15.0508 L 2.1249 40.9258 C 2.1249 42.5898 2.3358 43.7617 2.7109 44.4180 Z M 53.3360 44.3945 C 53.6874 43.7148 53.8751 42.5664 53.8751 40.9258 L 53.8751 15.0508 C 53.8751 13.4805 53.7109 12.3555 53.3591 11.7227 L 36.8124 28.0352 Z M 9.4843 48.1914 L 47.2184 48.1914 C 49.1874 48.1914 50.5468 47.8164 51.3200 47.0664 L 34.4452 30.3320 L 32.8749 31.9023 C 31.2812 33.4492 29.7577 34.1523 28.0468 34.1523 C 26.3358 34.1523 24.8124 33.4492 23.2187 31.9023 L 21.6484 30.3320 L 4.7968 47.0430 C 5.6874 47.8164 7.2577 48.1914 9.4843 48.1914 Z" })) }

function Ya() { return Ya = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Ya.apply(this, arguments) }

function Bv(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Rv(e) { e.children; var t = Bv(e, ["children"]); return ke.createElement("svg", Ya({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { d: "M 27.9999 51.9062 C 41.0546 51.9062 51.9063 41.0547 51.9063 28.0000 C 51.9063 14.9219 41.0312 4.0938 27.9765 4.0938 C 14.8983 4.0938 4.0937 14.9219 4.0937 28.0000 C 4.0937 41.0547 14.9218 51.9062 27.9999 51.9062 Z M 27.9999 26.6875 C 24.7421 26.6640 22.1640 23.9453 22.1640 20.3125 C 22.1640 16.9140 24.7421 14.0781 27.9999 14.0781 C 31.2343 14.0781 33.8124 16.9140 33.8124 20.3125 C 33.8124 23.9453 31.2343 26.7344 27.9999 26.6875 Z M 17.6171 39.7422 C 16.7030 39.7422 16.2577 39.1328 16.2577 38.3125 C 16.2577 35.8047 20.0312 29.3594 27.9999 29.3594 C 35.9687 29.3594 39.7187 35.8047 39.7187 38.3125 C 39.7187 39.1328 39.2733 39.7422 38.3827 39.7422 Z" })) }

function Ka() { return Ka = Object.assign || function(e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]) } return e }, Ka.apply(this, arguments) }

function Ev(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    i, o;
  for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n
}

function Tv(e) { e.children; var t = Ev(e, ["children"]); return ke.createElement("svg", Ka({ fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", width: "1em", height: "1em", viewBox: "0 0 56 56" }, t), ke.createElement("path", { d: "M 27.9883 47.7344 C 29.1367 47.7344 30.0976 46.8203 30.0976 45.6953 L 30.0976 30.1094 L 45.2383 30.1094 C 46.3633 30.1094 47.3476 29.1484 47.3476 28 C 47.3476 26.8516 46.3633 25.9141 45.2383 25.9141 L 30.0976 25.9141 L 30.0976 10.3047 C 30.0976 9.1797 29.1367 8.2656 27.9883 8.2656 C 26.8398 8.2656 25.9024 9.1797 25.9024 10.3047 L 25.9024 25.9141 L 10.7617 25.9141 C 9.6367 25.9141 8.6524 26.8516 8.6524 28 C 8.6524 29.1484 9.6367 30.1094 10.7617 30.1094 L 25.9024 30.1094 L 25.9024 45.6953 C 25.9024 46.8203 26.8398 47.7344 27.9883 47.7344 Z" })) }
var Gm = { color: void 0, size: void 0, className: void 0, style: void 0, attr: void 0 },
  mc = ke.createContext && ke.createContext(Gm),
  Ln = globalThis && globalThis.__assign || function() { return Ln = Object.assign || function(e) { for (var t, n = 1, r = arguments.length; n < r; n++) { t = arguments[n]; for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]) } return e }, Ln.apply(this, arguments) },
  zv = globalThis && globalThis.__rest || function(e, t) {
    var n = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function")
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
    return n
  };

function Jm(e) { return e && e.map(function(t, n) { return ke.createElement(t.tag, Ln({ key: n }, t.attr), Jm(t.child)) }) }

function nr(e) { return function(t) { return ke.createElement(Ov, Ln({ attr: Ln({}, e.attr) }, t), Jm(e.child)) } }

function Ov(e) {
  var t = function(n) {
    var r = e.attr,
      i = e.size,
      o = e.title,
      a = zv(e, ["attr", "size", "title"]),
      s = i || n.size || "1em",
      u;
    return n.className && (u = n.className), e.className && (u = (u ? u + " " : "") + e.className), ke.createElement("svg", Ln({ stroke: "currentColor", fill: "currentColor", strokeWidth: "0" }, n.attr, r, a, { className: u, style: Ln(Ln({ color: e.color || n.color }, n.style), e.style), height: s, width: s, xmlns: "http://www.w3.org/2000/svg" }), o && ke.createElement("title", null, o), e.children)
  };
  return mc !== void 0 ? ke.createElement(mc.Consumer, null, function(n) { return t(n) }) : t(Gm)
}

function Xm(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "path", attr: { d: "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19a2 2 0 002 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z" } }] })(e) }

function ef(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "path", attr: { d: "M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" } }] })(e) }

function _v(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "path", attr: { d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" } }] })(e) }

function Dv(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "path", attr: { d: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" } }] })(e) }

function tf(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "path", attr: { d: "M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z" } }] })(e) }

function Fv(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "circle", attr: { cx: "12", cy: "12", r: "3.2" } }, { tag: "path", attr: { d: "M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z" } }] })(e) }

function jv(e) { return nr({ tag: "svg", attr: { viewBox: "0 0 24 24" }, child: [{ tag: "path", attr: { fill: "none", d: "M0 0h24v24H0z" } }, { tag: "path", attr: { d: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" } }] })(e) }
const $v = "" + new URL("https://konstaui.com/kitchen-sink/react/dist/assets/demo-icon-f0653699.png", import.meta.url).href,
  A = () => l("img", { src: $v, alt: "icon", className: "ios:w-7 material:w-6" });

function nf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Badge", left: !e && l(re, { onClick: () => history.back() }), right: l(te, { navbar: !0, iconOnly: !0, children: l(Vt, { ios: l(Rv, { className: "w-7 h-7" }), material: l(jv, { className: "w-6 h-6" }), badge: "5", badgeColors: { bg: "bg-red-500" } }) }) }), h(Ws, { labels: !0, icons: !0, className: "left-0 bottom-0 fixed", children: [l(Vn, { active: !0, icon: l(Vt, { ios: l(Zm, { className: "w-7 h-7" }), material: l(ef, { className: "w-6 h-6" }), badge: "5", badgeColors: { bg: "bg-green-500" } }), label: "Inbox" }), l(Vn, { icon: l(Vt, { ios: l(Ym, { className: "w-7 h-7" }), material: l(Xm, { className: "w-6 h-6" }), badge: "7", badgeColors: { bg: "bg-red-500" } }), label: "Calendar" }), l(Vn, { icon: l(Vt, { ios: l(Km, { className: "w-7 h-7" }), material: l(tf, { className: "w-6 h-6" }), badge: "1", badgeColors: { bg: "bg-red-500" } }), label: "Upload" })] }), h(U, { strong: !0, inset: !0, children: [l(P, { media: l(A, {}), title: "Foo Bar", after: l(qn, { colors: { bg: "bg-gray-500" }, children: "0" }) }), l(P, { media: l(A, {}), title: "Ivan Petrov", after: l(qn, { children: "CEO" }) }), l(P, { media: l(A, {}), title: "John Doe", after: l(qn, { colors: { bg: "bg-green-500" }, children: "5" }) }), l(P, { media: l(A, {}), title: "Jane Doe", after: l(qn, { colors: { bg: "bg-yellow-500" }, children: "NEW" }) })] })] }) } nf.displayName = "BadgePage";

function rf() {
  const e = document.location.href.includes("examplePreview"),
    t = m.useRef(null),
    [n, r] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Breadcrumbs", left: !e && l(re, { onClick: () => history.back() }) }), l(D, { strong: !0, inset: !0, children: "Breadcrumbs allow users to keep track and maintain awareness of their locations within the app or website. They should be used for large sites and apps with hierarchically arranged pages." }), l(z, { children: "Basic" }), l(D, { strongIos: !0, outlineIos: !0, children: h(cl, { children: [l(Rt, { children: l(te, { children: "Home" }) }), l(Zt, {}), l(Rt, { children: l(te, { children: "Catalog" }) }), l(Zt, {}), l(Rt, { active: !0, children: "Phones" })] }) }), l(z, { children: "Scrollable" }), l(Jn, { children: "Breadcrumbs will be scrollable if they don't fit the screen" }), l(D, { strongIos: !0, outlineIos: !0, children: h(cl, { children: [l(Rt, { children: l(te, { children: "Home" }) }), l(Zt, {}), l(Rt, { children: l(te, { children: "Catalog" }) }), l(Zt, {}), l(Rt, { children: l(te, { children: "Phones" }) }), l(Zt, {}), l(Rt, { children: l(te, { children: "Apple" }) }), l(Zt, {}), l(Rt, { active: !0, children: "iPhone 12" })] }) }), l(z, { children: "Collapsed" }), l(D, { strongIos: !0, outlineIos: !0, children: h(cl, { children: [l(Rt, { children: l(te, { children: "Home" }) }), l(Zt, {}), l(Om, { ref: t, onClick: () => r(!0) }), l(Zt, {}), l(Rt, { active: !0, children: "iPhone 12" })] }) }), l(ro, { opened: n, className: "breadcrumbs-popover", style: { width: "120px" }, target: t.current, onBackdropClick: () => r(!1), children: h(U, { nested: !0, children: [l(P, { link: !0, title: "Catalog", onClick: () => r(!1) }), l(P, { link: !0, title: "Phones", onClick: () => r(!1) }), l(P, { link: !0, title: "Apple", onClick: () => r(!1) })] }) })] })
}
rf.displayName = "BreadcrumbsPage";

function lf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Buttons", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Default Buttons" }), h(D, { strong: !0, outlineIos: !0, className: "space-y-2", children: [h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { children: "Button" }), l(O, { className: "k-color-brand-red", children: "Button" }), l(O, { children: "Button" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { outline: !0, children: "Outline" }), l(O, { className: "k-color-brand-red", outline: !0, children: "Outline" }), l(O, { outline: !0, children: "Outline" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { clear: !0, children: "Clear" }), l(O, { className: "k-color-brand-red", clear: !0, children: "Clear" }), l(O, { clear: !0, children: "Clear" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { tonal: !0, children: "Tonal" }), l(O, { className: "k-color-brand-red", tonal: !0, children: "Tonal" }), l(O, { tonal: !0, children: "Tonal" })] })] }), l(z, { children: "Rounded Buttons" }), h(D, { strong: !0, outlineIos: !0, className: "space-y-2", children: [h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { rounded: !0, children: "Button" }), l(O, { rounded: !0, className: "k-color-brand-green", children: "Button" }), l(O, { rounded: !0, children: "Button" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { rounded: !0, outline: !0, children: "Outline" }), l(O, { rounded: !0, outline: !0, className: "k-color-brand-green", children: "Outline" }), l(O, { rounded: !0, outline: !0, children: "Outline" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { rounded: !0, clear: !0, children: "Clear" }), l(O, { rounded: !0, clear: !0, className: "k-color-brand-green", children: "Clear" }), l(O, { rounded: !0, clear: !0, children: "Clear" })] })] }), l(z, { children: "Large Buttons" }), h(D, { strong: !0, outlineIos: !0, className: "space-y-2", children: [h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { large: !0, children: "Button" }), l(O, { large: !0, className: "k-color-brand-yellow", children: "Button" }), l(O, { large: !0, rounded: !0, children: "Button" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { large: !0, outline: !0, children: "Outline" }), l(O, { large: !0, outline: !0, className: "k-color-brand-yellow", children: "Outline" }), l(O, { large: !0, rounded: !0, outline: !0, children: "Outline" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { large: !0, clear: !0, children: "Clear" }), l(O, { large: !0, clear: !0, className: "k-color-brand-yellow", children: "Clear" }), l(O, { large: !0, rounded: !0, clear: !0, children: "Clear" })] })] }), l(z, { children: "Small Buttons" }), h(D, { strong: !0, outlineIos: !0, className: "space-y-2", children: [h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { small: !0, children: "Button" }), l(O, { small: !0, children: "Button" }), l(O, { small: !0, rounded: !0, children: "Button" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { small: !0, outline: !0, children: "Outline" }), l(O, { small: !0, outline: !0, children: "Outline" }), l(O, { small: !0, rounded: !0, outline: !0, children: "Outline" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { small: !0, clear: !0, children: "Clear" }), l(O, { small: !0, clear: !0, children: "Clear" }), l(O, { small: !0, rounded: !0, clear: !0, children: "Clear" })] })] }), l(z, { children: "Raised Buttons" }), h(D, { strong: !0, outlineIos: !0, className: "space-y-2", children: [h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { raised: !0, children: "Button" }), l(O, { raised: !0, children: "Button" }), l(O, { raised: !0, rounded: !0, children: "Button" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { raised: !0, outline: !0, children: "Outline" }), l(O, { raised: !0, outline: !0, children: "Outline" }), l(O, { raised: !0, rounded: !0, outline: !0, children: "Outline" })] }), h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { raised: !0, clear: !0, children: "Clear" }), l(O, { raised: !0, clear: !0, children: "Clear" }), l(O, { raised: !0, rounded: !0, clear: !0, children: "Clear" })] })] }), l(z, { children: "Disabled Buttons" }), l(D, { strong: !0, outlineIos: !0, className: "space-y-2", children: h("div", { className: "grid grid-cols-3 gap-x-4", children: [l(O, { disabled: !0, children: "Button" }), l(O, { disabled: !0, outline: !0, children: "Outline" }), l(O, { disabled: !0, clear: !0, children: "Clear" })] }) })] }) } lf.displayName = "ButtonsPage";

function of() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Cards", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { withBlock: !1, children: "Simple Cards" }), l(Je, { children: "This is a simple card with plain text, but cards can also contain their own header, footer, list view, image, or any other element." }), l(Je, { header: "Card header", footer: "Card footer", children: "Card with header and footer. Card headers are used to display card titles and footers for additional information or just for custom actions." }), l(Je, { children: "Another card. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse feugiat sem est, non tincidunt ligula volutpat sit amet. Mauris aliquet magna justo." }), l(z, { withBlock: !1, children: "Outline Cards" }), l(Je, { outline: !0, children: "This is a simple card with plain text, but cards can also contain their own header, footer, list view, image, or any other element." }), l(Je, { outline: !0, header: "Card header", footer: "Card footer", children: "Card with header and footer. Card headers are used to display card titles and footers for additional information or just for custom actions." }), h(Je, { outline: !0, children: ["Another card. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse feugiat sem est, non tincidunt ligula volutpat sit amet. Mauris aliquet magna justo.", " "] }), l(z, { withBlock: !1, children: "Outline With Dividers" }), l(Je, { outline: !0, header: "Card header", footer: "Card footer", headerDivider: !0, footerDivider: !0, children: "Card with header and footer. Card headers are used to display card titles and footers for additional information or just for custom actions." }), l(z, { withBlock: !1, children: "Raised Cards" }), l(Je, { raised: !0, children: "This is a simple card with plain text, but cards can also contain their own header, footer, list view, image, or any other element." }), l(Je, { raised: !0, header: "Card header", footer: "Card footer", children: "Card with header and footer. Card headers are used to display card titles and footers for additional information or just for custom actions." }), h(Je, { raised: !0, children: ["Another card. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse feugiat sem est, non tincidunt ligula volutpat sit amet. Mauris aliquet magna justo.", " "] }), l(z, { withBlock: !1, children: "Card With List View" }), l(Je, { children: h(U, { nested: !0, className: "-m-4", children: [l(P, { href: !0, title: "Link 1" }), l(P, { href: !0, title: "Link 2" }), l(P, { href: !0, title: "Link 3" }), l(P, { href: !0, title: "Link 4" }), l(P, { href: !0, title: "Link 5" })] }) }), l(z, { withBlock: !1, children: "Styled Cards" }), h("div", { className: "lg:grid lg:grid-cols-2", children: [h(Je, { outline: !0, footer: h(ut, { children: [h("div", { className: "flex justify-between material:hidden", children: [l(te, { children: "Like" }), l(te, { children: "Read more" })] }), h("div", { className: "flex justify-start ios:hidden space-x-2 rtl:space-x-reverse", children: [l(O, { rounded: !0, inline: !0, children: "Like" }), l(O, { rounded: !0, inline: !0, outline: !0, children: "Read more" })] })] }), children: [l("div", { className: "ios:-mx-4 ios:-mt-4 h-48 p-4 flex items-end text-white ios:font-bold bg-cover bg-center material:rounded-xl mb-4 material:text-[22px]", style: { backgroundImage: "url(https://cdn.framework7.io/placeholder/nature-1000x600-3.jpg)" }, children: "Journey To Mountains" }), l("div", { className: "text-gray-500 mb-3", children: "Posted on January 21, 2021" }), l("p", { children: "Quisque eget vestibulum nulla. Quisque quis dui quis ex ultricies efficitur vitae non felis. Phasellus quis nibh hendrerit..." })] }), h(Je, { footer: h(ut, { children: [h("div", { className: "flex justify-between material:hidden", children: [l(te, { children: "Like" }), l(te, { children: "Read more" })] }), h("div", { className: "flex justify-start ios:hidden space-x-2 rtl:space-x-reverse", children: [l(O, { rounded: !0, inline: !0, children: "Like" }), l(O, { rounded: !0, inline: !0, outline: !0, children: "Read more" })] })] }), children: [l("div", { className: "ios:-mx-4 ios:-mt-4 h-48 p-4 flex items-end text-white ios:font-bold bg-cover bg-center material:rounded-xl mb-4 material:text-[22px]", style: { backgroundImage: "url(https://cdn.framework7.io/placeholder/people-1000x600-3.jpg)" }, children: "Journey To Mountains" }), l("div", { className: "text-gray-500 mb-3", children: "Posted on January 21, 2021" }), l("p", { children: "Quisque eget vestibulum nulla. Quisque quis dui quis ex ultricies efficitur vitae non felis. Phasellus quis nibh hendrerit..." })] })] })] }) } of.displayName = "CardsPage";

function af() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    [r, i] = m.useState(!0),
    [o, a] = m.useState(["Books"]),
    s = b => { o.includes(b) ? o.splice(o.indexOf(b), 1) : o.push(b), a([...o]) },
    [u, d] = m.useState(["Movie 1"]),
    p = b => {
      const N = b.target.value;
      b.target.checked ? u.push(N) : u.splice(u.indexOf(N), 1), d([...u])
    },
    v = () => { u.length === 1 || u.length === 0 ? d(["Movie 1", "Movie 2"]) : u.length === 2 && d([]) },
    [g, k] = m.useState(["Item 1"]),
    C = b => { g.includes(b) ? g.splice(g.indexOf(b), 1) : g.push(b), k([...g]) };
  return h(Z, { children: [l(K, { title: "Checkbox", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Inline" }), l(D, { strongIos: !0, outlineIos: !0, children: h("p", { children: ["Lorem", " ", l(bt, { name: "checkbox-1", checked: t, onChange: b => n(b.target.checked) }), " ", "ipsum dolor sit amet, consectetur adipisicing elit. Alias beatae illo nihil aut eius commodi sint eveniet aliquid eligendi", " ", l(bt, { name: "checkbox-2", checked: r, onChange: b => i(b.target.checked) }), " ", "ad delectus impedit tempore nemo, enim vel praesentium consequatur nulla mollitia!"] }) }), l(z, { children: "Checkbox Group" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { label: !0, title: "Books", media: l(bt, { component: "div", name: "demo-checkbox", checked: o.includes("Books"), onChange: () => s("Books") }) }), l(P, { label: !0, title: "Movies", media: l(bt, { component: "div", name: "demo-checkbox", checked: o.includes("Movies"), onChange: () => s("Movies") }) }), l(P, { label: !0, title: "Food", media: l(bt, { component: "div", name: "demo-checkbox", checked: o.includes("Food"), onChange: () => s("Food") }) }), l(P, { label: !0, title: "Drinks", media: l(bt, { component: "div", name: "demo-checkbox", checked: o.includes("Drinks"), onChange: () => s("Drinks") }) })] }), l(z, { children: "Indeterminate State" }), l(U, { strongIos: !0, outlineIos: !0, children: l(P, { label: !0, title: "Movies", name: "demo-checkbox", media: l(bt, { checked: u.length === 2, indeterminate: u.length === 1, onChange: v }), children: h("ul", { className: "ps-12", children: [l(P, { label: !0, title: "Movie 1", media: l(bt, { name: "demo-checkbox", value: "Movie 1", checked: u.indexOf("Movie 1") >= 0, onChange: p }) }), l(P, { label: !0, title: "Movie 2", media: l(bt, { name: "demo-checkbox", value: "Movie 2", checked: u.indexOf("Movie 2") >= 0, onChange: p }) })] }) }) }), l(z, { children: "With Media Lists" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { label: !0, title: "Facebook", after: "17:14", subtitle: "New messages from John Doe", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l(bt, { component: "div", name: "demo-media-checkbox", checked: g.includes("Item 1"), onChange: () => C("Item 1") }) }), l(P, { label: !0, title: "John Doe (via Twitter)", after: "17:11", subtitle: "John Doe (@_johndoe) mentioned you on Twitter!", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l(bt, { component: "div", name: "demo-media-checkbox", checked: g.includes("Item 2"), onChange: () => C("Item 2") }) })] })] })
}
af.displayName = "CheckboxPage";

function sf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Chips", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Chips With Text" }), h(D, { strongIos: !0, outlineIos: !0, children: [l(pe, { className: "m-0.5", children: "Example Chip" }), l(pe, { className: "m-0.5", children: "Another Chip" }), l(pe, { className: "m-0.5", children: "One More Chip" }), l(pe, { className: "m-0.5", children: "Fourth Chip" }), l(pe, { className: "m-0.5", children: "Last One" })] }), l(z, { children: "Outline Chips" }), h(D, { strongIos: !0, outlineIos: !0, children: [l(pe, { outline: !0, className: "m-0.5", children: "Example Chip" }), l(pe, { outline: !0, className: "m-0.5", children: "Another Chip" }), l(pe, { outline: !0, className: "m-0.5", children: "One More Chip" }), l(pe, { outline: !0, className: "m-0.5", children: "Fourth Chip" }), l(pe, { outline: !0, className: "m-0.5", children: "Last One" })] }), l(z, { children: "Contact Chips" }), h(D, { strongIos: !0, outlineIos: !0, children: [l(pe, { className: "m-0.5", media: l("img", { alt: "avatar", className: "ios:h-7 material:h-6 rounded-full", src: "https://cdn.framework7.io/placeholder/people-100x100-9.jpg" }), children: "Jane Doe" }), l(pe, { className: "m-0.5", media: l("img", { alt: "avatar", className: "ios:h-7 material:h-6 rounded-full", src: "https://cdn.framework7.io/placeholder/people-100x100-3.jpg" }), children: "John Doe" }), l(pe, { className: "m-0.5", media: l("img", { alt: "avatar", className: "ios:h-7 material:h-6 rounded-full", src: "https://cdn.framework7.io/placeholder/people-100x100-7.jpg" }), children: "Adam Smith" })] }), l(z, { children: "Deletable Chips / Tags" }), h(D, { strongIos: !0, outlineIos: !0, children: [l(pe, { className: "m-0.5", deleteButton: !0, onDelete: () => console.log("Delete Chip"), children: "Example Chip" }), l(pe, { className: "m-0.5", deleteButton: !0, onDelete: () => console.log("Delete Chip"), media: l("img", { alt: "avatar", className: "ios:h-7 material:h-6 rounded-full", src: "https://cdn.framework7.io/placeholder/people-100x100-7.jpg" }), children: "Adam Smith" })] }), l(z, { children: "Color Chips" }), h(D, { strongIos: !0, outlineIos: !0, children: [l(pe, { className: "m-0.5", colors: { fillBg: "bg-red-500", fillText: "text-white" }, children: "Red Chip" }), l(pe, { className: "m-0.5", colors: { fillBg: "bg-green-500", fillText: "text-white" }, children: "Green Chip" }), l(pe, { className: "m-0.5", colors: { fillBg: "bg-blue-500", fillText: "text-white" }, children: "Blue Chip" }), l(pe, { className: "m-0.5", colors: { fillBg: "bg-yellow-500", fillText: "text-white" }, children: "Yellow Chip" }), l(pe, { className: "m-0.5", colors: { fillBg: "bg-pink-500", fillText: "text-white" }, children: "Pink Chip" }), l(pe, { className: "m-0.5", outline: !0, colors: { outlineBorder: "border-red-500", outlineText: "text-red-500" }, children: "Red Chip" }), l(pe, { className: "m-0.5", outline: !0, colors: { outlineBorder: "border-green-500", outlineText: "text-green-500" }, children: "Green Chip" }), l(pe, { className: "m-0.5", outline: !0, colors: { outlineBorder: "border-blue-500", outlineText: "text-blue-500" }, children: "Blue Chip" }), l(pe, { className: "m-0.5", outline: !0, colors: { outlineBorder: "border-yellow-500", outlineText: "text-yellow-500" }, children: "Yellow Chip" }), l(pe, { className: "m-0.5", outline: !0, colors: { outlineBorder: "border-pink-500", outlineText: "text-pink-500" }, children: "Pink Chip" })] })] }) } sf.displayName = "ChipsPage";

function uf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Contacts List", left: !e && l(re, { onClick: () => history.back() }) }), h(U, { strongIos: !0, children: [h(xn, { dividers: !1, children: [l(P, { title: "A", groupTitle: !0, contacts: !0 }), l(P, { title: "Aaron", contacts: !0 }), l(P, { title: "Abbie", contacts: !0 }), l(P, { title: "Adam", contacts: !0 }), l(P, { title: "Adele", contacts: !0 }), l(P, { title: "Agatha", contacts: !0 }), l(P, { title: "Agnes", contacts: !0 }), l(P, { title: "Albert", contacts: !0 }), l(P, { title: "Alexander", contacts: !0 })] }), h(xn, { dividers: !1, children: [l(P, { title: "B", groupTitle: !0, contacts: !0 }), l(P, { title: "Bailey", contacts: !0 }), l(P, { title: "Barclay", contacts: !0 }), l(P, { title: "Bartolo", contacts: !0 }), l(P, { title: "Bellamy", contacts: !0 }), l(P, { title: "Belle", contacts: !0 }), l(P, { title: "Benjamin", contacts: !0 })] }), h(xn, { dividers: !1, children: [l(P, { title: "C", groupTitle: !0, contacts: !0 }), l(P, { title: "Caiden", contacts: !0 }), l(P, { title: "Calvin", contacts: !0 }), l(P, { title: "Candy", contacts: !0 }), l(P, { title: "Carl", contacts: !0 }), l(P, { title: "Cherilyn", contacts: !0 }), l(P, { title: "Chester", contacts: !0 }), l(P, { title: "Chloe", contacts: !0 })] }), h(xn, { dividers: !1, children: [l(P, { title: "V", groupTitle: !0, contacts: !0 }), l(P, { title: "Vladimir", contacts: !0 })] })] })] }) } uf.displayName = "ContactsListPage";

function cf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Content Block", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Block Title" }), l(D, { children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(z, { children: "Strong Block" }), l(D, { strong: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(z, { children: "Strong Outline Block" }), l(D, { strong: !0, outline: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(z, { children: "Strong Inset Block" }), l(D, { strong: !0, inset: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(z, { children: "Strong Inset Outline Block" }), l(D, { strong: !0, inset: !0, outline: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(z, { children: "With Header & Footer" }), l(Jn, { children: "Header" }), l(D, { strong: !0, outline: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(Tm, { children: "Footer" }), l(z, { medium: !0, children: "Medium Title" }), l(D, { strong: !0, outline: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) }), l(z, { large: !0, children: "Large Title" }), l(D, { strong: !0, outline: !0, children: l("p", { children: "Donec et nulla auctor massa pharetra adipiscing ut sit amet sem. Suspendisse molestie velit vitae mattis tincidunt. Ut sit amet quam mollis, vulputate turpis vel, sagittis felis." }) })] }) } cf.displayName = "ContentBlockPage";

function df() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Data Table", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Plain table" }), l("div", { className: "block overflow-x-auto mt-8", children: h($a, { children: [l(Ha, { children: h(Et, { header: !0, children: [l(W, { header: !0, children: "Dessert (100g serving)" }), l(W, { header: !0, className: "text-right", children: "Calories" }), l(W, { header: !0, className: "text-right", children: "Fat (g)" }), l(W, { header: !0, className: "text-right", children: "Carbs" }), l(W, { header: !0, className: "text-right", children: "Protein (g)" })] }) }), h(Aa, { children: [h(Et, { children: [l(W, { children: "Frozen yogurt" }), l(W, { className: "text-right", children: "159" }), l(W, { className: "text-right", children: "6.0" }), l(W, { className: "text-right", children: "24" }), l(W, { className: "text-right", children: "4.0" })] }), h(Et, { children: [l(W, { children: "Ice cream sandwich" }), l(W, { className: "text-right", children: "237" }), l(W, { className: "text-right", children: "9.0" }), l(W, { className: "text-right", children: "37" }), l(W, { className: "text-right", children: "4.4" })] }), h(Et, { children: [l(W, { children: "Eclair" }), l(W, { className: "text-right", children: "262" }), l(W, { className: "text-right", children: "16.0" }), l(W, { className: "text-right", children: "24" }), l(W, { className: "text-right", children: "6.0" })] }), h(Et, { children: [l(W, { children: "Cupcake" }), l(W, { className: "text-right", children: "305" }), l(W, { className: "text-right", children: "3.7" }), l(W, { className: "text-right", children: "67" }), l(W, { className: "text-right", children: "4.3" })] })] })] }) }), l(z, { children: "Within card" }), l(Je, { className: "block overflow-x-auto mt-8", contentWrap: !1, children: h($a, { children: [l(Ha, { children: h(Et, { header: !0, children: [l(W, { header: !0, children: "Dessert (100g serving)" }), l(W, { header: !0, className: "text-right", children: "Calories" }), l(W, { header: !0, className: "text-right", children: "Fat (g)" }), l(W, { header: !0, className: "text-right", children: "Carbs" }), l(W, { header: !0, className: "text-right", children: "Protein (g)" })] }) }), h(Aa, { children: [h(Et, { children: [l(W, { children: "Frozen yogurt" }), l(W, { className: "text-right", children: "159" }), l(W, { className: "text-right", children: "6.0" }), l(W, { className: "text-right", children: "24" }), l(W, { className: "text-right", children: "4.0" })] }), h(Et, { children: [l(W, { children: "Ice cream sandwich" }), l(W, { className: "text-right", children: "237" }), l(W, { className: "text-right", children: "9.0" }), l(W, { className: "text-right", children: "37" }), l(W, { className: "text-right", children: "4.4" })] }), h(Et, { children: [l(W, { children: "Eclair" }), l(W, { className: "text-right", children: "262" }), l(W, { className: "text-right", children: "16.0" }), l(W, { className: "text-right", children: "24" }), l(W, { className: "text-right", children: "6.0" })] }), h(Et, { children: [l(W, { children: "Cupcake" }), l(W, { className: "text-right", children: "305" }), l(W, { className: "text-right", children: "3.7" }), l(W, { className: "text-right", children: "67" }), l(W, { className: "text-right", children: "4.3" })] })] })] }) })] }) } df.displayName = "DataTablePage";

function mf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    [r, i] = m.useState(!1),
    [o, a] = m.useState(!1),
    [s, u] = m.useState(!1),
    [d, p] = m.useState("batman");
  return h(Z, { children: [l(K, { title: "Dialog", left: !e && l(re, { onClick: () => history.back() }) }), l(D, { strong: !0, inset: !0, className: "space-y-4", children: l("p", { children: "Dialog is a type of modal window that appears in front of app content to provide critical information, or prompt for a decision to be made." }) }), l(D, { strong: !0, inset: !0, children: h("p", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [l(O, { rounded: !0, onClick: () => n(!0), children: "Basic" }), l(O, { rounded: !0, onClick: () => i(!0), children: "Alert" }), l(O, { rounded: !0, onClick: () => a(!0), children: "Confirm" }), l(O, { rounded: !0, onClick: () => u(!0), children: "List" })] }) }), l(yr, { opened: t, onBackdropClick: () => n(!1), title: "Dialog Title", content: "Dialog is a type of modal window that appears in front of app content to provide critical information, or prompt for a decision to be made.", buttons: h(ut, { children: [l(fn, { onClick: () => n(!1), children: "Action 2" }), l(fn, { onClick: () => n(!1), children: "Action 1" })] }) }), l(yr, { opened: r, onBackdropClick: () => i(!1), title: "SmoothX", content: "Hello world!", buttons: l(fn, { onClick: () => i(!1), children: "Ok" }) }), l(yr, { opened: o, onBackdropClick: () => a(!1), title: "SmoothX", content: "All good today?", buttons: h(ut, { children: [l(fn, { onClick: () => a(!1), children: "No" }), l(fn, { strong: !0, onClick: () => a(!1), children: "Yes" })] }) }), l(yr, { opened: s, onBackdropClick: () => u(!1), title: "Your super hero", content: h(U, { nested: !0, className: "-mx-4", children: [l(P, { label: !0, title: "Batman", after: l(Ee, { component: "div", value: "batman", checked: d === "batman", onChange: () => p("batman") }) }), l(P, { label: !0, title: "Spider-man", after: l(Ee, { component: "div", value: "spiderman", checked: d === "spiderman", onChange: () => p("spiderman") }) }), l(P, { label: !0, title: "Hulk", after: l(Ee, { component: "div", value: "hulk", checked: d === "hulk", onChange: () => p("hulk") }) })] }), buttons: l(fn, { onClick: () => u(!1), children: "Confirm" }) })] })
}
mf.displayName = "DialogPage";

function Vs() {
  const e = document.location.href.includes("examplePreview"),
    n = fe() === "ios" ? Tv : _v;
  return h(Z, { children: [l(K, { title: "FAB", left: !e && l(re, { onClick: () => history.back() }) }), l(Fn, { className: "fixed right-4-safe ios:top-15-safe material:top-18-safe z-20 k-color-brand-red", icon: l(n, {}) }), l(Fn, { className: "fixed right-4-safe bottom-4-safe z-20", icon: l(n, {}) }), l(Fn, { className: "fixed left-4-safe bottom-4-safe z-20 k-color-brand-green", icon: l(n, {}) }), l(Fn, { className: "fixed left-4-safe ios:top-15-safe material:top-18-safe z-20 k-color-brand-yellow", icon: l(n, {}) }), l(Fn, { className: "fixed left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20", icon: l(n, {}) }), l(Fn, { className: "fixed left-1/2 bottom-4-safe transform -translate-x-1/2 z-20", icon: l(n, {}), text: "Create", textPosition: "after" }), h(D, { className: "space-y-4", children: [l("p", { children: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quia, quo rem beatae, delectus eligendi est saepe molestias perferendis suscipit, commodi labore ipsa non quasi eum magnam neque ducimus! Quasi, numquam." }), l("p", { children: "Maiores culpa, itaque! Eaque natus ab cum ipsam numquam blanditiis a, quia, molestiae aut laudantium recusandae ipsa. Ad iste ex asperiores ipsa, mollitia perferendis consectetur quam eaque, voluptate laboriosam unde." }), l("p", { children: "Sed odit quis aperiam temporibus vitae necessitatibus, laboriosam, exercitationem dolores odio sapiente provident. Accusantium id, itaque aliquam libero ipsum eos fugiat distinctio laboriosam exercitationem sequi facere quas quidem magnam reprehenderit." }), l("p", { children: "Pariatur corporis illo, amet doloremque. Ab veritatis sunt nisi consectetur error modi, nam illo et nostrum quia aliquam ipsam vitae facere voluptates atque similique odit mollitia, rerum placeat nobis est." }), l("p", { children: "Et impedit soluta minus a autem adipisci cupiditate eius dignissimos nihil officia dolore voluptatibus aperiam reprehenderit esse facilis labore qui, officiis consectetur. Ipsa obcaecati aspernatur odio assumenda veniam, ipsum alias." })] }), h(D, { className: "space-y-4", children: [l("p", { children: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa ipsa debitis sed nihil eaque dolore cum iste quibusdam, accusamus doloribus, tempora quia quos voluptatibus corporis officia at quas dolorem earum!" }), l("p", { children: "Quod soluta eos inventore magnam suscipit enim at hic in maiores temporibus pariatur tempora minima blanditiis vero autem est perspiciatis totam dolorum, itaque repellat? Nobis necessitatibus aut odit aliquam adipisci." }), l("p", { children: "Tenetur delectus perspiciatis ex numquam, unde corrupti velit! Quam aperiam, animi fuga veritatis consectetur, voluptatibus atque consequuntur dignissimos itaque, sint impedit cum cumque at. Adipisci sint, iusto blanditiis ullam? Vel?" }), l("p", { children: "Dignissimos velit officia quibusdam! Eveniet beatae, aut, omnis temporibus consequatur expedita eaque aliquid quos accusamus fugiat id iusto autem obcaecati repellat fugit cupiditate suscipit natus quas doloribus? Temporibus necessitatibus, libero." }), l("p", { children: "Architecto quisquam ipsa fugit facere, repudiandae asperiores vitae obcaecati possimus, labore excepturi reprehenderit consectetur perferendis, ullam quidem hic, repellat fugiat eaque fuga. Consectetur in eveniet, deleniti recusandae omnis eum quas?" }), l("p", { children: "Quos nulla consequatur quo, officia quaerat. Nulla voluptatum, assumenda quibusdam, placeat cum aut illo deleniti dolores commodi odio ipsam, recusandae est pariatur veniam repudiandae blanditiis. Voluptas unde deleniti quisquam, nobis?" }), l("p", { children: "Atque qui quaerat quasi officia molestiae, molestias totam incidunt reprehenderit laboriosam facilis veritatis, non iusto! Dolore ipsam obcaecati voluptates minima maxime minus qui mollitia facere. Nostrum esse recusandae voluptatibus eligendi." })] })] })
}
Vs.title = "FAB (Floating Action Button)";
Vs.displayName = "FabPage";

function ff() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState({ value: "", changed: !1 }),
    [r, i] = m.useState(""),
    o = u => { n({ value: u.target.value, changed: !0 }) },
    a = u => { i(u.target.value) },
    s = () => { i("") };
  return h(Z, { children: [l(K, { title: "Form Inputs", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Default" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { label: "Name", type: "text", placeholder: "Your name", media: l(A, {}) }), l(Q, { label: "Password", type: "password", placeholder: "Your password", media: l(A, {}) }), l(Q, { label: "E-mail", type: "email", placeholder: "Your e-mail", media: l(A, {}) }), l(Q, { label: "URL", type: "url", placeholder: "URL", media: l(A, {}) }), l(Q, { label: "Phone", type: "tel", placeholder: "Your phone number", media: l(A, {}) }), h(Q, { label: "Gender", type: "select", dropdown: !0, defaultValue: "Male", placeholder: "Please choose...", media: l(A, {}), children: [l("option", { value: "Male", children: "Male" }), l("option", { value: "Female", children: "Female" })] }), l(Q, { label: "Birthday", type: "date", defaultValue: "2014-04-30", placeholder: "Please choose...", media: l(A, {}) }), l(Q, { label: "Date time", type: "datetime-local", placeholder: "Please choose...", media: l(A, {}) }), l(Q, { label: "Textarea", type: "textarea", placeholder: "Bio", media: l(A, {}), inputClassName: "!h-20 resize-none" })] }), l(z, { children: "Outline" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { outline: !0, label: "Name", type: "text", placeholder: "Your name", media: l(A, {}) }), l(Q, { outline: !0, label: "Password", type: "password", placeholder: "Your password", media: l(A, {}) }), l(Q, { outline: !0, label: "E-mail", type: "email", placeholder: "Your e-mail", media: l(A, {}) }), l(Q, { outline: !0, label: "URL", type: "url", placeholder: "URL", media: l(A, {}) }), l(Q, { outline: !0, label: "Phone", type: "tel", placeholder: "Your phone number", media: l(A, {}) }), h(Q, { outline: !0, label: "Gender", type: "select", dropdown: !0, defaultValue: "Male", placeholder: "Please choose...", media: l(A, {}), children: [l("option", { value: "Male", children: "Male" }), l("option", { value: "Female", children: "Female" })] }), l(Q, { outline: !0, label: "Birthday", type: "date", defaultValue: "2014-04-30", placeholder: "Please choose...", media: l(A, {}) }), l(Q, { outline: !0, label: "Date time", type: "datetime-local", placeholder: "Please choose...", media: l(A, {}) }), l(Q, { outline: !0, label: "Textarea", type: "textarea", placeholder: "Bio", media: l(A, {}), inputClassName: "!h-20 resize-none" })] }), l(z, { children: "Floating Labels" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { label: "Name", floatingLabel: !0, type: "text", placeholder: "Your name", media: l(A, {}) }), l(Q, { label: "Password", floatingLabel: !0, type: "password", placeholder: "Your password", media: l(A, {}) }), l(Q, { label: "E-mail", floatingLabel: !0, type: "email", placeholder: "Your e-mail", media: l(A, {}) }), l(Q, { label: "URL", floatingLabel: !0, type: "url", placeholder: "URL", media: l(A, {}) }), l(Q, { label: "Phone", floatingLabel: !0, type: "tel", placeholder: "Your phone number", media: l(A, {}) })] }), l(z, { children: "Outline + Floating Labels" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { outline: !0, label: "Name", floatingLabel: !0, type: "text", placeholder: "Your name", media: l(A, {}) }), l(Q, { outline: !0, label: "Password", floatingLabel: !0, type: "password", placeholder: "Your password", media: l(A, {}) }), l(Q, { outline: !0, label: "E-mail", floatingLabel: !0, type: "email", placeholder: "Your e-mail", media: l(A, {}) }), l(Q, { outline: !0, label: "URL", floatingLabel: !0, type: "url", placeholder: "URL", media: l(A, {}) }), l(Q, { outline: !0, label: "Phone", floatingLabel: !0, type: "tel", placeholder: "Your phone number", media: l(A, {}) })] }), l(z, { children: "Validation + Additional Info" }), l(U, { strongIos: !0, insetIos: !0, children: l(Q, { label: "Name", type: "text", placeholder: "Your name", info: "Basic string checking", value: t.value, error: t.changed && !t.value.trim() ? "Please specify your name" : "", media: l(A, {}), onChange: o }) }), l(z, { children: "Clear Button" }), l(U, { strongIos: !0, insetIos: !0, children: l(Q, { label: "TV Show", type: "text", placeholder: "Your favorite TV show", info: "Type something to see clear button", value: r, clearButton: r.length > 0, media: l(A, {}), onChange: a, onClear: s }) }), l(z, { children: "Icon + Input" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { type: "text", placeholder: "Your name", media: l(A, {}) }), l(Q, { type: "password", placeholder: "Your password", media: l(A, {}) }), l(Q, { type: "email", placeholder: "Your e-mail", media: l(A, {}) }), l(Q, { type: "url", placeholder: "URL", media: l(A, {}) })] }), l(z, { children: "Label + Input" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { label: "Name", type: "text", placeholder: "Your name" }), l(Q, { label: "Password", type: "password", placeholder: "Your password" }), l(Q, { label: "E-mail", type: "email", placeholder: "Your e-mail" }), l(Q, { label: "URL", type: "url", placeholder: "URL" })] }), l(z, { children: "Only Inputs" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { type: "text", placeholder: "Your name" }), l(Q, { type: "password", placeholder: "Your password" }), l(Q, { type: "email", placeholder: "Your e-mail" }), l(Q, { type: "url", placeholder: "URL" })] }), l(z, { children: "Inputs + Additional Info" }), h(U, { strongIos: !0, insetIos: !0, children: [l(Q, { type: "text", placeholder: "Your name", info: "Full name please" }), l(Q, { type: "password", placeholder: "Your password", info: "8 characters minimum" }), l(Q, { type: "email", placeholder: "Your e-mail", info: "Your work e-mail address" }), l(Q, { type: "url", placeholder: "URL", info: "Your website URL" })] })] })
}
ff.displayName = "FormInputsPage";

function pf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "List", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Simple List" }), h(U, { children: [l(P, { title: "Item 1" }), l(P, { title: "Item 2" }), l(P, { title: "Item 3" })] }), l(z, { children: "Strong List" }), h(U, { strong: !0, children: [l(P, { title: "Item 1" }), l(P, { title: "Item 2" }), l(P, { title: "Item 3" })] }), l(z, { children: "Strong Outline List" }), h(U, { strong: !0, outline: !0, children: [l(P, { title: "Item 1" }), l(P, { title: "Item 2" }), l(P, { title: "Item 3" })] }), l(z, { children: "Strong Inset List" }), h(U, { strong: !0, inset: !0, children: [l(P, { title: "Item 1" }), l(P, { title: "Item 2" }), l(P, { title: "Item 3" })] }), l(z, { children: "Strong Outline Inset List" }), h(U, { strong: !0, outline: !0, inset: !0, children: [l(P, { title: "Item 1" }), l(P, { title: "Item 2" }), l(P, { title: "Item 3" })] }), l(z, { children: "Simple Links List" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { title: "Link 1", link: !0 }), l(P, { title: "Link 2", link: !0 }), l(P, { title: "Link 3", link: !0 })] }), l(z, { children: "Data list, with icons" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { media: l(A, {}), title: "Ivan Petrov", after: "CEO" }), l(P, { title: "John Doe", media: l(A, {}), after: l(qn, { children: "5" }) }), l(P, { media: l(A, {}), title: "Jenna Smith" })] }), l(z, { children: "Links" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { media: l(A, {}), link: !0, title: "Ivan Petrov", after: "CEO" }), l(P, { media: l(A, {}), link: !0, title: "John Doe", after: "Cleaner" }), l(P, { media: l(A, {}), link: !0, title: "Jenna Smith" })] }), l(z, { children: "Links, Header, Footer" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { media: l(A, {}), link: !0, header: "Name", title: "John Doe", after: "Edit" }), l(P, { media: l(A, {}), link: !0, header: "Phone", title: "+7 90 111-22-3344", after: "Edit" }), l(P, { link: !0, header: "Email", title: "john@doe", footer: "Home", after: "Edit", media: l(A, {}) }), l(P, { link: !0, header: "Email", title: "john@konsta", footer: "Work", after: "Edit", media: l(A, {}) })] }), l(z, { children: "Links, no icons" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { link: !0, title: "Ivan Petrov" }), l(P, { link: !0, title: "John Doe" }), l(P, { groupTitle: !0, title: "Group title here" }), l(P, { link: !0, title: "Ivan Petrov" }), l(P, { link: !0, title: "Jenna Smith" })] }), l(z, { children: "Grouped with sticky titles" }), h(U, { strongIos: !0, outlineIos: !0, children: [h(xn, { children: [l(P, { title: "A", groupTitle: !0, className: "ios:top-11-safe material:top-16-safe sticky" }), l(P, { title: "Aaron " }), l(P, { title: "Abbie" }), l(P, { title: "Adam" })] }), h(xn, { children: [l(P, { title: "B", groupTitle: !0, className: "ios:top-11-safe material:top-16-safe  sticky" }), l(P, { title: "Bailey" }), l(P, { title: "Barclay" }), l(P, { title: "Bartolo" })] }), h(xn, { children: [l(P, { title: "C", groupTitle: !0, className: "ios:top-11-safe material:top-16-safe  sticky" }), l(P, { title: "Caiden" }), l(P, { title: "Calvin" }), l(P, { title: "Candy" })] })] }), l(z, { className: "text-2xl", children: "Media Lists" }), l(D, { children: l("p", { children: "Media Lists are almost the same as Data Lists, but with a more flexible layout for visualization of more complex data, like products, services, user, etc." }) }), l(z, { children: "Songs" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { link: !0, chevronMaterial: !1, title: "Yellow Submarine", after: "$15", subtitle: "Beatles", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l("img", { className: "ios:rounded-lg material:rounded-full ios:w-20 material:w-10", src: "https://cdn.framework7.io/placeholder/people-160x160-1.jpg", width: "80", alt: "demo" }) }), l(P, { link: !0, chevronMaterial: !1, title: "Don't Stop Me Now", after: "$22", subtitle: "Queen", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l("img", { className: "ios:rounded-lg material:rounded-full ios:w-20 material:w-10", src: "https://cdn.framework7.io/placeholder/people-160x160-2.jpg", width: "80", alt: "demo" }) }), l(P, { link: !0, chevronMaterial: !1, title: "Billie Jean", after: "$16", subtitle: "Michael Jackson", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l("img", { className: "ios:rounded-lg material:rounded-full ios:w-20 material:w-10", src: "https://cdn.framework7.io/placeholder/people-160x160-3.jpg", width: "80", alt: "demo" }) })] }), l(z, { children: "Mail App" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { link: !0, chevronMaterial: !1, title: "Facebook", after: "17:14", subtitle: "New messages from John Doe", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus." }), l(P, { link: !0, chevronMaterial: !1, title: "John Doe (via Twitter)", after: "17:11", subtitle: "John Doe (@_johndoe) mentioned you on Twitter!", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus." }), l(P, { link: !0, chevronMaterial: !1, title: "Facebook", after: "16:48", subtitle: "New messages from John Doe", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus." }), l(P, { link: !0, chevronMaterial: !1, title: "John Doe (via Twitter)", after: "15:32", subtitle: "John Doe (@_johndoe) mentioned you on Twitter!", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus." })] })] }) } pf.displayName = "ListPage";

function hf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "List Button", left: !e && l(re, { onClick: () => history.back() }) }), h(U, { strong: !0, outlineIos: !0, children: [l(cn, { children: "Button 1" }), l(cn, { children: "Button 2" }), l(cn, { children: "Button 3" })] }), h(U, { inset: !0, strong: !0, children: [l(cn, { children: "Button 1" }), l(cn, { children: "Button 2" }), l(cn, { children: "Button 3" })] }), l(U, { inset: !0, strong: !0, children: l(cn, { className: "k-color-brand-red", children: "Red Button" }) })] }) } hf.displayName = "ListButtonPage";

function gf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState("home"),
    [r, i] = m.useState("home");
  return h(Z, { children: [l(K, { title: "Menu List", left: !e && l(re, { onClick: () => history.back() }) }), l(D, { strong: !0, inset: !0, children: l("p", { children: "Menu list unlike usual links list is designed to indicate currently active screen (or section) of your app. Think about it like a Tabbar but in a form of a list." }) }), h(ja, { strongIos: !0, outlineIos: !0, children: [l(jn, { title: "Home", active: t === "home", onClick: () => n("home"), media: l(A, {}) }), l(jn, { title: "Profile", active: t === "profile", onClick: () => n("profile"), media: l(A, {}) }), l(jn, { title: "Settings", active: t === "settings", onClick: () => n("settings"), media: l(A, {}) })] }), h(ja, { strongIos: !0, outlineIos: !0, children: [l(jn, { title: "Home", subtitle: "Home subtitle", active: r === "home", onClick: () => i("home"), media: l(A, {}) }), l(jn, { title: "Profile", subtitle: "Profile subtitle", active: r === "profile", onClick: () => i("profile"), media: l(A, {}) }), l(jn, { title: "Settings", subtitle: "Settings subtitle", active: r === "settings", onClick: () => i("settings"), media: l(A, {}) })] })] })
}
gf.displayName = "MenuListPage";

function vf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(""),
    [r, i] = m.useState([{ type: "sent", text: "Hi, Kate" }, { type: "sent", text: "How are you?" }, { name: "Kate", type: "received", text: "Hi, I am good!", avatar: "https://cdn.framework7.io/placeholder/people-100x100-9.jpg" }, { name: "Blue Ninja", type: "received", text: "Hi there, I am also fine, thanks! And how are you?", avatar: "https://cdn.framework7.io/placeholder/people-100x100-7.jpg" }, { type: "sent", text: "Hey, Blue Ninja! Glad to see you ;)" }, { type: "sent", text: "How do you feel about going to the movies today?" }, { name: "Kate", type: "received", text: " Oh, great idea!", avatar: "https://cdn.framework7.io/placeholder/people-100x100-9.jpg" }, { name: "Kate", type: "received", text: " What cinema are we going to?", avatar: "https://cdn.framework7.io/placeholder/people-100x100-9.jpg" }, { name: "Blue Ninja", type: "received", text: "Great. And what movie?", avatar: "https://cdn.framework7.io/placeholder/people-100x100-7.jpg" }, { name: "Blue Ninja", type: "received", text: "What time?", avatar: "https://cdn.framework7.io/placeholder/people-100x100-7.jpg" }]),
    o = m.useRef(),
    a = m.useRef(!1),
    s = () => {
      const g = o.current.current || o.current.el;
      g.scrollTo({ top: g.scrollHeight - g.offsetHeight, behavior: a.current ? "smooth" : "auto" })
    };
  m.useEffect(() => { s(), a.current = !0 }, [r]);
  const u = () => {
      const g = t.replace(/\n/g, "<br>").trim(),
        k = "sent",
        C = [];
      g.length && C.push({ text: g, type: k }), C.length !== 0 && (i([...r, ...C]), n(""))
    },
    d = t ? 1 : .3,
    p = t.trim().length > 0,
    v = new Intl.DateTimeFormat("en-US", { weekday: "long", month: "short", day: "numeric", hour12: !1, hour: "2-digit", minute: "2-digit" }).formatToParts(new Date).map(g => ["weekday", "month", "day"].includes(g.type) ? l("b", { children: g.value }, g.type) : g.value);
  return h(Z, { className: "ios:bg-white ios:dark:bg-black", ref: o, children: [l(K, { title: "Messages", left: !e && l(re, { onClick: () => history.back() }) }), h(Am, { children: [l(Hm, { children: v }), r.map((g, k) => l(jm, { type: g.type, name: g.name, text: g.text, avatar: g.type === "received" && l("img", { alt: "avatar", src: g.avatar, className: "w-8 h-8 rounded-full" }) }, k))] }), l($m, { placeholder: "Message", value: t, onInput: g => n(g.target.value), left: l(te, { onClick: () => console.log("click"), toolbar: !0, iconOnly: !0, children: l(Vt, { ios: l(Pv, { className: "w-7 h-7" }), material: l(Fv, { className: "w-6 h-6 fill-black dark:fill-md-dark-on-surface" }) }) }), right: l(te, { onClick: p ? u : void 0, toolbar: !0, style: { opacity: d, cursor: p ? "pointer" : "default" }, children: l(Vt, { ios: l(Nv, { className: "w-7 h-7" }), material: l(Dv, { className: "w-6 h-6 fill-black dark:fill-md-dark-on-surface" }) }) }) })] })
}
vf.displayName = "MessagesPage";

function yf() { const [e, t] = m.useState("Default"), [n, r] = m.useState(!1), i = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Navbar", subtitle: "Subtitle", className: "top-0 sticky", medium: e === "Medium", large: e === "Large", transparent: n, left: !i && l(re, { onClick: () => history.back() }), right: l(te, { navbar: !0, children: "Right" }) }), h("div", { className: "relative", children: [l(D, { strong: !0, inset: !0, children: l("p", { children: "Navbar is a fixed area at the top of a screen that contains Page title and navigation elements." }) }), l(z, { children: "Size" }), l(Jn, { children: "Medium and Large will collapse to usual size on page scroll" }), l(U, { strong: !0, inset: !0, children: ["Default", "Medium", "Large"].map(o => l(P, { label: !0, title: o, after: l(Ee, { component: "div", value: o, checked: e === o, onChange: () => t(o) }) }, o)) }), l(z, { children: "Transparent" }), l(Jn, { children: "When navbar is transparent, its title and background will become visible on page scroll" }), l(U, { strong: !0, inset: !0, children: l(P, { label: !0, title: "Transparent", after: l(tn, { component: "div", checked: n === !0, onChange: () => r(!n) }) }) }), h(D, { strong: !0, inset: !0, className: "space-y-4", children: [l("p", { children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto tempore ratione unde accusantium distinctio nulla quia numquam earum odio, optio, nisi rem deserunt. Molestiae delectus, ut assumenda numquam magni enim." }), l("p", { children: "Architecto molestias cum dolor dolorem provident consequuntur incidunt sunt fugiat tenetur odio, recusandae placeat rem veniam. Voluptates, repellendus odit, magni nesciunt, optio laborum asperiores repudiandae consectetur suscipit ab cupiditate eum." }), l("p", { children: "Aliquam, iste accusamus deleniti temporibus exercitationem neque perferendis optio, blanditiis quisquam molestias perspiciatis cumque harum tenetur veniam. Dolorum fugit doloribus est, deserunt, eligendi, quaerat quidem itaque tempore laborum non illum?" }), l("p", { children: "Rerum magni sunt quis veniam, dolor ratione saepe ducimus tempore voluptatum porro quod commodi? Aperiam laudantium deleniti totam dolorum qui accusantium iste saepe facere optio, soluta maxime mollitia deserunt cumque." }), l("p", { children: "Iusto tempore quis provident, saepe illum ex ipsum cupiditate explicabo ratione unde facere nemo delectus harum, blanditiis eius sit asperiores nam. Aut cupiditate est tempore officia, perspiciatis esse asperiores repudiandae?" }), l("p", { children: "Consequuntur itaque harum eos vero, reiciendis dolorum iure non earum molestias tenetur sint enim, maxime recusandae ad perferendis repudiandae! Sit, quos exercitationem beatae numquam laborum nobis natus. Obcaecati, ea inventore." }), l("p", { children: "Fugit culpa labore sapiente excepturi reiciendis, nulla, nihil neque ut veritatis quis quibusdam dolorum? Voluptatibus animi officia perspiciatis doloremque cum voluptatem, quia ratione modi vero, consequatur ipsum, praesentium quibusdam amet?" }), l("p", { children: "Laudantium nihil sint nam placeat, nemo rerum ipsam explicabo iusto dolores molestiae expedita eos consequuntur ut architecto consequatur soluta ad maiores voluptatem tenetur in velit. Minima quia molestiae nobis voluptatibus." }), l("p", { children: "Expedita soluta quia inventore et placeat id exercitationem quisquam eligendi est eius sapiente quo, cum nesciunt mollitia, sit veniam ducimus tempora culpa adipisci commodi in autem nihil voluptatem corporis? Perspiciatis." }), l("p", { children: "Molestias, est? Eligendi vero distinctio voluptatem cumque id voluptatibus, officia minima repellendus sit illo tempora labore provident? Eum tenetur consectetur quae, in facilis autem ipsam doloribus voluptate vitae suscipit nobis." }), l("p", { children: "Obcaecati optio iste hic, soluta minus ullam, perferendis pariatur non possimus autem nostrum libero sapiente. Corporis quo cum iusto exercitationem velit. Non beatae eveniet asperiores ipsa consequuntur temporibus sapiente earum!" }), l("p", { children: "Temporibus, omnis. Excepturi dolorum expedita laudantium quasi quod id adipisci, esse, nam atque in, incidunt ex ab distinctio repellendus beatae voluptatem alias odit illum quis. Illo numquam voluptatibus error voluptatum!" })] })] })] }) } yf.displayName = "NavbarPage";

function xf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    [r, i] = m.useState(!1),
    [o, a] = m.useState(!1),
    [s, u] = m.useState(!1),
    [d, p] = m.useState(!1),
    v = g => { n(!1), i(!1), a(!1), u(!1), g(!0) };

  return m.useEffect(() => { let g; return t && (g = setTimeout(() => { n(!1) }, 3e3)), () => clearTimeout(g) }, [t]), h(Z, { children: [l(K, { title: "Notification", left: !e && l(re, { onClick: () => history.back() }) }), l(Yr, { opened: t, icon: l(A, {}), title: "SmoothX", titleRightText: "now", subtitle: "This is a subtitle", text: "This is a simple notification message" }), l(Yr, { opened: r, icon: l(A, {}), title: "SmoothX", button: !0, onClick: () => i(!1), subtitle: "Notification with close button", text: "Click (x) button to close me" }), l(Yr, { opened: o, icon: l(A, {}), title: "SmoothX", titleRightText: "now", subtitle: "Notification with close on click", text: "Click me to close", onClick: () => a(!1) }), l(Yr, { opened: s, icon: l(A, {}), title: "SmoothX", titleRightText: "now", subtitle: "Notification with close on click", text: "Click me to close", onClick: () => { u(!1), p(!0) } }), l(yr, { opened: d, onBackdropClick: () => p(!1), title: "SmoothX", content: "Notification closed", buttons: l(fn, { onClick: () => p(!1), children: "Ok" }) }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [l("p", { children: "SmoothX comes with simple Notifications component that allows you to show some useful messages to user and request basic actions." }), l("p", { children: l(O, { onClick: () => v(n), children: "Full layout notification" }) }), l("p", { children: l(O, { onClick: () => v(i), children: "With Close Button" }) }), l("p", { children: l(O, { onClick: () => v(a), children: "Click to Close" }) }), l("p", { children: l(O, { onClick: () => v(u), children: "Callback on Close" }) })] })] })
}
xf.displayName = "NotificationPage";

function Qs() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    [r, i] = m.useState(!1),
    [o, a] = m.useState(!1),
    [s, u] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Panel / Side Panel", left: !e && l(re, { onClick: () => history.back() }) }), l(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: l("p", { children: "SmoothX comes with 2 panels (on left and on right), both are optional. You can put absolutely anything inside: data lists, forms, custom content, etc." }) }), h(D, { strongIos: !0, outlineIos: !0, className: "flex space-x-4 rtl:space-x-reverse", children: [l(O, { rounded: !0, onClick: () => n(!0), children: "Left Panel" }), l(O, { rounded: !0, onClick: () => i(!0), children: "Right Panel" })] }), l(z, { children: "Floating Panels" }), h(D, { strongIos: !0, outlineIos: !0, className: "flex space-x-4 rtl:space-x-reverse", children: [l(O, { rounded: !0, onClick: () => a(!0), children: "Left Panel" }), l(O, { rounded: !0, onClick: () => u(!0), children: "Right Panel" })] }), l(Kr, { side: "left", opened: t, onBackdropClick: () => n(!1), children: h(Z, { children: [l(K, { title: "Left Panel", right: l(te, { navbar: !0, onClick: () => n(!1), children: "Close" }) }), h(D, { className: "space-y-4", children: [l("p", { children: "Here comes left panel." }), l("p", { children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse faucibus mauris leo, eu bibendum neque congue non. Ut leo mauris, eleifend eu commodo a, egestas ac urna. Maecenas in lacus faucibus, viverra ipsum pulvinar, molestie arcu. Etiam lacinia venenatis dignissim. Suspendisse non nisl semper tellus malesuada suscipit eu et eros. Nulla eu enim quis quam elementum vulputate. Mauris ornare consequat nunc viverra pellentesque. Aenean semper eu massa sit amet aliquam. Integer et neque sed libero mollis elementum at vitae ligula. Vestibulum pharetra sed libero sed porttitor. Suspendisse a faucibus lectus." })] })] }) }), l(Kr, { side: "right", opened: r, onBackdropClick: () => i(!1), children: h(Z, { children: [l(K, { title: "Right Panel", right: l(te, { navbar: !0, onClick: () => i(!1), children: "Close" }) }), h(D, { className: "space-y-4", children: [l("p", { children: "Here comes right panel." }), l("p", { children: "Duis ut mauris sollicitudin, venenatis nisi sed, luctus ligula. Phasellus blandit nisl ut lorem semper pharetra. Nullam tortor nibh, suscipit in consequat vel, feugiat sed quam. Nam risus libero, auctor vel tristique ac, malesuada ut ante. Sed molestie, est in eleifend sagittis, leo tortor ullamcorper erat, at vulputate eros sapien nec libero. Mauris dapibus laoreet nibh quis bibendum. Fusce dolor sem, suscipit in iaculis id, pharetra at urna. Pellentesque tempor congue massa quis faucibus. Vestibulum nunc eros, convallis blandit dui sit amet, gravida adipiscing libero." })] })] }) }), l(Kr, { side: "left", floating: !0, opened: o, onBackdropClick: () => a(!1), children: h(Z, { className: "no-safe-areas-top no-safe-areas-bottom", children: [l(K, { title: "Left Panel", right: l(te, { navbar: !0, onClick: () => a(!1), children: "Close" }) }), h(D, { className: "space-y-4", children: [l("p", { children: "Here comes left panel." }), l("p", { children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse faucibus mauris leo, eu bibendum neque congue non. Ut leo mauris, eleifend eu commodo a, egestas ac urna. Maecenas in lacus faucibus, viverra ipsum pulvinar, molestie arcu. Etiam lacinia venenatis dignissim. Suspendisse non nisl semper tellus malesuada suscipit eu et eros. Nulla eu enim quis quam elementum vulputate. Mauris ornare consequat nunc viverra pellentesque. Aenean semper eu massa sit amet aliquam. Integer et neque sed libero mollis elementum at vitae ligula. Vestibulum pharetra sed libero sed porttitor. Suspendisse a faucibus lectus." })] })] }) }), l(Kr, { side: "right", floating: !0, opened: s, onBackdropClick: () => u(!1), children: h(Z, { className: "no-safe-areas-top no-safe-areas-bottom", children: [l(K, { title: "Right Panel", right: l(te, { navbar: !0, onClick: () => u(!1), children: "Close" }) }), h(D, { className: "space-y-4", children: [l("p", { children: "Here comes right panel." }), l("p", { children: "Duis ut mauris sollicitudin, venenatis nisi sed, luctus ligula. Phasellus blandit nisl ut lorem semper pharetra. Nullam tortor nibh, suscipit in consequat vel, feugiat sed quam. Nam risus libero, auctor vel tristique ac, malesuada ut ante. Sed molestie, est in eleifend sagittis, leo tortor ullamcorper erat, at vulputate eros sapien nec libero. Mauris dapibus laoreet nibh quis bibendum. Fusce dolor sem, suscipit in iaculis id, pharetra at urna. Pellentesque tempor congue massa quis faucibus. Vestibulum nunc eros, convallis blandit dui sit amet, gravida adipiscing libero." })] })] }) })] })
}
Qs.displayName = "SidePanelsPage";
Qs.title = "Panel / Side Panels";

function kf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    r = m.useRef(null),
    i = o => { r.current = o, n(!0) };
  return h(Z, { children: [l(K, { title: "Popover", left: !e && l(re, { onClick: () => history.back() }), right: l(te, { className: "popover-navbar-link", navbar: !0, onClick: () => i(".popover-navbar-link"), children: "Popover" }) }), h(D, { className: "space-y-4", children: [l("p", { children: l(O, { className: "popover-button", onClick: () => i(".popover-button"), children: "Open popover on me" }) }), h("p", { children: ["Mauris fermentum neque et luctus venenatis. Vivamus a sem rhoncus, ornare tellus eu, euismod mauris. In porta turpis at semper convallis. Duis adipiscing leo eu nulla lacinia, quis rhoncus metus condimentum. Etiam nec malesuada nibh. Maecenas quis lacinia nisl, vel posuere dolor. Vestibulum condimentum, nisl ac vulputate egestas, neque enim dignissim elit, rhoncus volutpat magna enim a est. Aenean sit amet ligula neque. Cras suscipit rutrum enim. Nam a odio facilisis, elementum tellus non,", " ", l(te, { className: "popover-link-1", onClick: () => i(".popover-link-1"), children: "popover" }), " ", "tortor. Pellentesque felis eros, dictum vitae lacinia quis, lobortis vitae ipsum. Cras vehicula bibendum lorem quis imperdiet."] }), h("p", { children: ["In hac habitasse platea dictumst. Etiam varius, ante vel ornare facilisis, velit massa rutrum dolor, ac porta magna magna lacinia nunc. Curabitur", " ", l(te, { className: "popover-link-2", onClick: () => i(".popover-link-2"), children: "popover!" }), " ", "cursus laoreet. Aenean vel tempus augue. Pellentesque in imperdiet nibh. Mauris rhoncus nulla id sem suscipit volutpat. Pellentesque ac arcu in nisi viverra pulvinar. Nullam nulla orci, bibendum sed ligula non, ullamcorper iaculis mi. In hac habitasse platea dictumst. Praesent varius at nisl eu luctus. Cras aliquet porta est. Quisque elementum quis dui et consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed sed laoreet purus. Pellentesque eget ante ante."] }), h("p", { children: ["Duis et ultricies nibh. Sed facilisis turpis urna, ac imperdiet erat venenatis eu. Proin sit amet faucibus tortor, et varius sem. Etiam vitae lacinia neque. Aliquam nisi purus, interdum in arcu sed, ultrices rutrum arcu. Nulla mi turpis, consectetur vel enim quis, facilisis viverra dui. Aliquam quis convallis tortor, quis semper ligula. Morbi ullamcorper", " ", l(te, { className: "popover-link-3", onClick: () => i(".popover-link-3"), children: "one more popover" }), " ", "massa at accumsan. Etiam purus odio, posuere in ligula vitae, viverra ultricies justo. Vestibulum nec interdum nisi. Aenean ac consectetur velit, non malesuada magna. Sed pharetra vehicula augue, vel venenatis lectus gravida eget. Curabitur lacus tellus, venenatis eu arcu in, interdum auctor nunc. Nunc non metus neque. Suspendisse viverra lectus sed risus aliquet, vel accumsan dolor feugiat."] })] }), l(ro, { opened: t, target: r.current, onBackdropClick: () => n(!1), children: h(U, { nested: !0, children: [l(P, { title: "Item 1", link: !0, onClick: () => n(!1) }), l(P, { title: "List Item 2", link: !0, onClick: () => n(!1) }), l(P, { title: "Item 3", link: !0, onClick: () => n(!1) }), l(P, { title: "List Item 4", link: !0, onClick: () => n(!1) }), l(P, { title: "Item 5", link: !0, onClick: () => n(!1) })] }) })] })
}
kf.displayName = "PopoverPage";

function bf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Popup", left: !e && l(re, { onClick: () => history.back() }) }), h(D, { strong: !0, className: "space-y-4", children: [l("p", { children: `Popup is a modal window with any HTML content that pops up over App's main content. Popup as all other overlays is part of so called "Temporary Views".` }), l("p", { children: l(O, { onClick: () => n(!0), children: "Open Popup" }) })] }), l(Um, { opened: t, onBackdropClick: () => n(!1), children: h(Z, { children: [l(K, { title: "Popup", right: l(te, { navbar: !0, onClick: () => n(!1), children: "Close" }) }), h(D, { className: "space-y-4", children: [l("p", { children: "Here comes popup. You can put here anything, even independent view with its own navigation. Also not, that by default popup looks a bit different on iPhone/iPod and iPad, on iPhone it is fullscreen." }), l("p", { children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse faucibus mauris leo, eu bibendum neque congue non. Ut leo mauris, eleifend eu commodo a, egestas ac urna. Maecenas in lacus faucibus, viverra ipsum pulvinar, molestie arcu. Etiam lacinia venenatis dignissim. Suspendisse non nisl semper tellus malesuada suscipit eu et eros. Nulla eu enim quis quam elementum vulputate. Mauris ornare consequat nunc viverra pellentesque. Aenean semper eu massa sit amet aliquam. Integer et neque sed libero mollis elementum at vitae ligula. Vestibulum pharetra sed libero sed porttitor. Suspendisse a faucibus lectus." }), l("p", { children: "Duis ut mauris sollicitudin, venenatis nisi sed, luctus ligula. Phasellus blandit nisl ut lorem semper pharetra. Nullam tortor nibh, suscipit in consequat vel, feugiat sed quam. Nam risus libero, auctor vel tristique ac, malesuada ut ante. Sed molestie, est in eleifend sagittis, leo tortor ullamcorper erat, at vulputate eros sapien nec libero. Mauris dapibus laoreet nibh quis bibendum. Fusce dolor sem, suscipit in iaculis id, pharetra at urna. Pellentesque tempor congue massa quis faucibus. Vestibulum nunc eros, convallis blandit dui sit amet, gravida adipiscing libero." })] })] }) })] })
}
bf.displayName = "PopupPage";

function Cf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Preloader", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Default" }), l(D, { strong: !0, insetMaterial: !0, outlineIos: !0, className: "text-center", children: l(qt, {}) }), l(z, { children: "Colors" }), h(D, { strong: !0, insetMaterial: !0, outlineIos: !0, className: "grid grid-cols-4", children: [l("div", { className: "text-center", children: l(qt, { className: "k-color-brand-red" }) }), l("div", { className: "text-center", children: l(qt, { className: "k-color-brand-green" }) }), l("div", { className: "text-center", children: l(qt, { className: "k-color-brand-purple" }) }), l("div", { className: "text-center", children: l(qt, { className: "k-color-brand-yellow" }) })] }), l(z, { children: "Sizes" }), h(D, { strong: !0, insetMaterial: !0, outlineIos: !0, className: "grid grid-cols-4 items-center", children: [l("div", { className: "text-center", children: l(qt, { size: "w-4 h-4" }) }), l("div", { className: "text-center", children: l(qt, { size: "w-8 h-8" }) }), l("div", { className: "text-center", children: l(qt, { size: "w-12 h-12" }) }), l("div", { className: "text-center", children: l(qt, { size: "w-16 h-16" }) })] })] }) } Cf.displayName = "PreloaderPage";

function wf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(.1);
  return h(Z, { children: [l(K, { title: "Progressbar", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Determinate Progress Bar" }), h(D, { strong: !0, insetMaterial: !0, outlineIos: !0, children: [l("div", { className: "my-4", children: l(ir, { progress: t }) }), h(zt, { raised: !0, children: [l(se, { active: t === .1, onClick: () => n(.1), children: "10%" }), l(se, { active: t === .3, onClick: () => n(.3), children: "30%" }), l(se, { active: t === .5, onClick: () => n(.5), children: "50%" }), l(se, { active: t === 1, onClick: () => n(1), children: "100%" })] })] }), l(z, { children: "Colors" }), h(D, { strong: !0, insetMaterial: !0, outlineIos: !0, className: "space-y-4", children: [l(ir, { className: "k-color-brand-red", progress: .25 }), l(ir, { className: "k-color-brand-green", progress: .5 }), l(ir, { className: "k-color-brand-yellow", progress: .75 }), l(ir, { className: "k-color-brand-purple", progress: 1 })] })] })
}
wf.displayName = "ProgressbarPage";

function Nf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState("inline-1"),
    [r, i] = m.useState("Books"),
    [o, a] = m.useState("Item 1");
  return h(Z, { children: [l(K, { title: "Radio", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Inline" }), l(D, { strongIos: !0, outlineIos: !0, children: h("p", { children: ["Lorem", " ", l(Ee, { name: "demo-radio-inline", value: "inline-1", checked: t === "inline-1", onChange: () => n("inline-1") }), " ", "ipsum dolor sit amet, consectetur adipisicing elit. Alias beatae illo nihil aut eius commodi sint eveniet aliquid eligendi", " ", l(Ee, { name: "demo-radio-inline", value: "inline-2", checked: t === "inline-2", onChange: () => n("inline-2") }), " ", "ad delectus impedit tempore nemo, enim vel praesentium consequatur nulla mollitia!"] }) }), l(z, { children: "Radio Group" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { label: !0, title: "Books", media: l(Ee, { component: "div", value: "Books", checked: r === "Books", onChange: () => i("Books") }) }), l(P, { label: !0, title: "Movies", media: l(Ee, { component: "div", value: "Movies", checked: r === "Movies", onChange: () => i("Movies") }) }), l(P, { label: !0, title: "Food", media: l(Ee, { component: "div", value: "Food", checked: r === "Food", onChange: () => i("Food") }) }), l(P, { label: !0, title: "Drinks", media: l(Ee, { component: "div", value: "Drinks", checked: r === "Drinks", onChange: () => i("Drinks") }) })] }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { label: !0, title: "Books", after: l(Ee, { component: "div", value: "Books", checked: r === "Books", onChange: () => i("Books") }) }), l(P, { label: !0, title: "Movies", after: l(Ee, { component: "div", value: "Movies", checked: r === "Movies", onChange: () => i("Movies") }) }), l(P, { label: !0, title: "Food", after: l(Ee, { component: "div", value: "Food", checked: r === "Food", onChange: () => i("Food") }) }), l(P, { label: !0, title: "Drinks", after: l(Ee, { component: "div", value: "Drinks", checked: r === "Drinks", onChange: () => i("Drinks") }) })] }), l(z, { children: "With Media Lists" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { label: !0, title: "Facebook", after: "17:14", subtitle: "New messages from John Doe", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l(Ee, { component: "div", checked: o === "Item 1", onChange: () => a("Item 1") }) }), l(P, { label: !0, title: "John Doe (via Twitter)", after: "17:11", subtitle: "John Doe (@_johndoe) mentioned you on Twitter!", text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sagittis tellus ut turpis condimentum, ut dignissim lacus tincidunt. Cras dolor metus, ultrices condimentum sodales sit amet, pharetra sodales eros. Phasellus vel felis tellus. Mauris rutrum ligula nec dapibus feugiat. In vel dui laoreet, commodo augue id, pulvinar lacus.", media: l(Ee, { component: "div", checked: o === "Item 2", onChange: () => a("Item 2") }) })] })] })
}
Nf.displayName = "RadioPage";

function If() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(50),
    [r, i] = m.useState(150),
    [o, a] = m.useState(100),
    [s, u] = m.useState(50),
    [d, p] = m.useState(75);
  return h(Z, { children: [l(K, { title: "Range Slider", left: !e && l(re, { onClick: () => history.back() }) }), h(z, { children: ["Volume: ", t] }), l(Jn, { children: "From 0 to 100 with step 10" }), l(U, { strong: !0, insetMaterial: !0, outlineIos: !0, children: l(P, { innerClassName: "flex space-x-4 rtl:space-x-reverse", innerChildren: h(ut, { children: [l("span", { children: "0" }), l(lr, { value: t, step: 10, onChange: v => n(v.target.value) }), l("span", { children: "100" })] }) }) }), h(z, { children: ["Price: $", r] }), l(Jn, { children: "From 0 to 1000 with step 1" }), l(U, { strong: !0, insetMaterial: !0, outlineIos: !0, children: l(P, { innerClassName: "flex space-x-4 rtl:space-x-reverse", innerChildren: h(ut, { children: [l("span", { children: "$0" }), l(lr, { value: r, step: 1, min: 0, max: 1e3, onChange: v => i(v.target.value) }), l("span", { children: "$1000" })] }) }) }), h(z, { children: ["Color: rgb(", o, ", ", s, ", ", d, ")"] }), h(U, { strong: !0, insetMaterial: !0, outlineIos: !0, children: [l(P, { innerChildren: l(lr, { className: "k-color-brand-red", value: o, step: 1, min: 0, max: 255, onChange: v => a(v.target.value) }) }), l(P, { innerChildren: l(lr, { className: "k-color-brand-green", value: s, step: 1, min: 0, max: 255, onChange: v => u(v.target.value) }) }), l(P, { innerChildren: l(lr, { className: "k-color-brand-blue", value: d, step: 1, min: 0, max: 255, onChange: v => p(v.target.value) }) })] })] })
}
If.displayName = "RangeSliderPage";
const fc = [{ title: "FC Ajax" }, { title: "FC Arsenal" }, { title: "FC Athletic" }, { title: "FC Barcelona" }, { title: "FC Bayern München" }, { title: "FC Bordeaux" }, { title: "FC Borussia Dortmund" }, { title: "FC Chelsea" }, { title: "FC Galatasaray" }, { title: "FC Juventus" }, { title: "FC Liverpool" }, { title: "FC Manchester City" }, { title: "FC Manchester United" }, { title: "FC Paris Saint-Germain" }, { title: "FC Real Madrid" }, { title: "FC Tottenham Hotspur" }, { title: "FC Valencia" }, { title: "FC West Ham United" }];

function Sf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(""),
    r = s => { n(s.target.value) },
    i = () => { n("") },
    o = () => { console.log("Disable") },
    a = t ? fc.filter(s => s.title.toLowerCase().includes(t.toLowerCase())) : fc;
  return h(Z, { children: [l(K, { title: "Searchbar", left: !e && l(re, { onClick: () => history.back() }), subnavbar: l(Wm, { onInput: r, value: t, onClear: i, disableButton: !0, disableButtonText: "Cancel", onDisable: o }) }), l(U, { strong: !0, insetMaterial: !0, outlineIos: !0, children: a.length === 0 ? l(P, { title: "Nothing found", className: "text-center" }) : a.map(s => l(P, { title: s.title }, s.title)) })] })
}
Sf.displayName = "SearchbarPage";

function Pf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(1);
  return h(Z, { children: [l(K, { title: "Segmented Control", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Default Segmented" }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [h(zt, { children: [l(se, { active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { active: t === 3, onClick: () => n(3), children: "Button" })] }), h(zt, { rounded: !0, children: [l(se, { active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { active: t === 3, onClick: () => n(3), children: "Button" })] })] }), l(z, { children: "Raised Segmented" }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [h(zt, { raised: !0, children: [l(se, { active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { active: t === 3, onClick: () => n(3), children: "Button" })] }), h(zt, { raised: !0, rounded: !0, children: [l(se, { active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { active: t === 3, onClick: () => n(3), children: "Button" })] })] }), l(z, { children: "Outline" }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [h(zt, { outline: !0, children: [l(se, { active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { active: t === 3, onClick: () => n(3), children: "Button" })] }), h(zt, { rounded: !0, outline: !0, children: [l(se, { active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { active: t === 3, onClick: () => n(3), children: "Button" })] })] }), l(z, { children: "Strong Segmented" }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [h(zt, { strong: !0, children: [l(se, { strong: !0, active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { strong: !0, active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { strong: !0, active: t === 3, onClick: () => n(3), children: "Button" })] }), h(zt, { strong: !0, rounded: !0, children: [l(se, { strong: !0, rounded: !0, active: t === 1, onClick: () => n(1), children: "Button" }), l(se, { strong: !0, rounded: !0, active: t === 2, onClick: () => n(2), children: "Button" }), l(se, { strong: !0, rounded: !0, active: t === 3, onClick: () => n(3), children: "Button" })] })] })] })
}
Pf.displayName = "SegmentedControlPage";

function Mf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Sheet Modal", left: !e && l(re, { onClick: () => history.back() }) }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [l("p", { children: "Sheet Modals slide up from the bottom of the screen to reveal more content. Such modals allow to create custom overlays with custom content." }), l("p", { children: l(O, { onClick: () => n(!0), children: "Open Sheet" }) })] }), h(Vm, { className: "pb-safe", opened: t, onBackdropClick: () => n(!1), children: [h(Ti, { top: !0, children: [l("div", { className: "left" }), l("div", { className: "right", children: l(te, { toolbar: !0, onClick: () => n(!1), children: "Done" }) })] }), h(D, { children: [l("p", { children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Harum ad excepturi nesciunt nobis aliquam. Quibusdam ducimus neque necessitatibus, molestias cupiditate velit nihil alias incidunt, excepturi voluptatem dolore itaque sapiente dolores!" }), l("div", { className: "mt-4", children: l(O, { onClick: () => n(!1), children: "Action" }) })] })] })] })
}
Mf.displayName = "SheetModalPage";

function Lf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(1),
    r = () => { n(t + 1) },
    i = () => { n(t - 1 < 0 ? 0 : t - 1) },
    [o, a] = m.useState(1),
    s = () => {
      const v = parseInt(o, 10);
      isNaN(v) ? a(0) : a(v + 1)
    },
    u = () => {
      const v = parseInt(o, 10);
      isNaN(v) && a(0), a(v - 1 < 0 ? 0 : v - 1)
    },
    d = v => { a(v.target.value) },
    p = () => { isNaN(parseInt(o, 10)) && a(0) };
  return h(Z, { children: [l(K, { title: "Stepper", left: !e && l(re, { onClick: () => history.back() }) }), l(z, { children: "Shape and size" }), h(D, { strongIos: !0, outlineIos: !0, className: "text-center space-y-4", children: [h("div", { className: "grid grid-cols-2 gap-4", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Default" }), l(le, { value: t, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Round" }), l(le, { value: t, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Outline" }), l(le, { value: t, outline: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Rounded Outline" }), l(le, { value: t, outline: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small" }), l(le, { value: t, onPlus: r, onMinus: i, small: !0 })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small Round" }), l(le, { value: t, small: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small Outline" }), l(le, { value: t, small: !0, outline: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small Rounded Outline" }), l(le, { value: t, small: !0, rounded: !0, outline: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large" }), l(le, { value: t, onPlus: r, onMinus: i, large: !0 })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large Round" }), l(le, { value: t, large: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large Outline" }), l(le, { value: t, large: !0, outline: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large Rounded Outline" }), l(le, { value: t, large: !0, rounded: !0, outline: !0, onPlus: r, onMinus: i })] })] })] }), l(z, { children: "Raised" }), h(D, { strongIos: !0, outlineIos: !0, className: "text-center space-y-4", children: [h("div", { className: "grid grid-cols-2 gap-4", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Default" }), l(le, { value: t, raised: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Round" }), l(le, { value: t, raised: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Outline" }), l(le, { value: t, raised: !0, outline: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Round Outline" }), l(le, { value: t, raised: !0, outline: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small" }), l(le, { value: t, raised: !0, small: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small Round" }), l(le, { value: t, raised: !0, small: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small Outline" }), l(le, { value: t, raised: !0, small: !0, outline: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Small Rounded Outline" }), l(le, { value: t, raised: !0, small: !0, rounded: !0, outline: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large" }), l(le, { value: t, raised: !0, large: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large Round" }), l(le, { value: t, raised: !0, large: !0, rounded: !0, onPlus: r, onMinus: i })] })] }), h("div", { className: "grid grid-cols-2 gap-4 margin-top", children: [h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large Outline" }), l(le, { value: t, raised: !0, large: !0, outline: !0, onPlus: r, onMinus: i })] }), h("div", { children: [l("div", { className: "block text-xs mb-1", children: "Large Rounded Outline" }), l(le, { value: t, raised: !0, large: !0, rounded: !0, outline: !0, onPlus: r, onMinus: i })] })] })] }), l(z, { children: "With Text Input" }), h(D, { strongIos: !0, outlineIos: !0, className: "text-center space-y-4", children: [l("div", { children: l(le, { value: o, input: !0, onChange: d, onBlur: p, onPlus: s, onMinus: u }) }), l("div", { children: l(le, { value: o, outline: !0, input: !0, onChange: d, onBlur: p, onPlus: s, onMinus: u }) })] }), l(z, { children: "Only Buttons" }), h(U, { strongIos: !0, outlineIos: !0, children: [l(P, { title: `Value is ${t}`, after: l(le, { value: t, buttonsOnly: !0, onPlus: r, onMinus: i }) }), l(P, { title: `Value is ${t}`, after: l(le, { value: t, outline: !0, buttonsOnly: !0, onPlus: r, onMinus: i }) }), l(P, { title: `Value is ${t}`, after: l(le, { value: t, raised: !0, outline: !0, buttonsOnly: !0, onPlus: r, onMinus: i }) })] }), l(z, { children: "Colors" }), h(D, { strongIos: !0, outlineIos: !0, className: "text-center space-y-4", children: [h("div", { className: "grid grid-cols-2 gap-4", children: [l("div", { children: l(le, { value: t, className: "k-color-brand-red", onPlus: r, onMinus: i }) }), l("div", { children: l(le, { value: t, rounded: !0, className: "k-color-brand-green", onPlus: r, onMinus: i }) })] }), h("div", { className: "grid grid-cols-2 gap-4", children: [l("div", { children: l(le, { value: t, className: "k-color-brand-yellow", onPlus: r, onMinus: i }) }), l("div", { children: l(le, { value: t, rounded: !0, className: "k-color-brand-purple", onPlus: r, onMinus: i }) })] })] })] })
}
Lf.displayName = "StepperPage";

function Bf() { const e = document.location.href.includes("examplePreview"); return h(Z, { children: [l(K, { title: "Subnavbar", left: !e && l(re, { onClick: () => history.back() }), subnavbar: h(zt, { strong: !0, children: [l(se, { small: !0, strong: !0, active: !0, children: "Button" }), l(se, { small: !0, strong: !0, children: "Button" }), l(se, { small: !0, strong: !0, children: "Button" })] }) }), l("div", { className: "relative", children: l(D, { strongIos: !0, outlineIos: !0, children: l("p", { children: "Subnavbar is useful when you need to put any additional elements into Navbar, like Tab Links or Search Bar. It also remains visible when Navbar hidden." }) }) })] }) } Bf.displayName = "SubnavbarPage";

function Rf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState("tab-1"),
    [r, i] = m.useState(!0),
    [o, a] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Tabbar", left: !e && l(re, { onClick: () => history.back() }) }), h(Ws, { labels: r, icons: o, className: "left-0 bottom-0 fixed", children: [l(Vn, { active: t === "tab-1", onClick: () => n("tab-1"), icon: o && l(Vt, { ios: l(Zm, { className: "w-7 h-7" }), material: l(ef, { className: "w-6 h-6" }) }), label: r && "Tab 1" }), l(Vn, { active: t === "tab-2", onClick: () => n("tab-2"), icon: o && l(Vt, { ios: l(Ym, { className: "w-7 h-7" }), material: l(Xm, { className: "w-6 h-6" }) }), label: r && "Tab 2" }), l(Vn, { active: t === "tab-3", onClick: () => n("tab-3"), icon: o && l(Vt, { ios: l(Km, { className: "w-7 h-7" }), material: l(tf, { className: "w-6 h-6" }) }), label: r && "Tab 3" })] }), h(U, { strong: !0, inset: !0, children: [l(P, { title: "Tabbar Labels", after: l(tn, { checked: r, onChange: () => i(!r) }) }), l(P, { title: "Tabbar Icons", after: l(tn, { checked: o, onChange: () => a(!o) }) })] }), t === "tab-1" && h(D, { strong: !0, inset: !0, className: "space-y-4", children: [l("p", { children: l("b", { children: "Tab 1" }) }), h("p", { children: [l("span", { children: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias accusantium necessitatibus, nihil quas praesentium at quibusdam cupiditate possimus et repudiandae dolorum delectus quo, similique voluptatem magni explicabo adipisci magnam ratione!" }), l("span", { children: "Quod praesentium consequatur autem veritatis, magni alias consectetur ut quo, voluptatum earum in repellat! Id, autem! Minus suscipit, ad possimus non voluptatem aliquam praesentium earum corrupti optio velit tenetur numquam?" }), l("span", { children: "Illo id ipsa natus quidem dignissimos odio dolore veniam, accusamus vel assumenda nulla aliquam amet distinctio! Debitis deserunt, et, cum voluptate similique culpa assumenda inventore, facilis eveniet iure optio velit." }), l("span", { children: "Maiores minus laborum placeat harum impedit, saepe veniam iusto voluptates delectus omnis consectetur tenetur ex ipsa error debitis aspernatur amet et alias! Sit odit cum voluptas quae? Est, omnis eos?" })] })] }), t === "tab-2" && h(D, { strong: !0, inset: !0, className: "space-y-4", children: [l("p", { children: l("b", { children: "Tab 2" }) }), h("p", { children: [l("span", { children: "Dicta beatae repudiandae ab pariatur mollitia praesentium fuga ipsum adipisci, quia nam expedita, est dolore eveniet, dolorum obcaecati? Veniam repellendus mollitia sapiente minus saepe voluptatibus necessitatibus laboriosam incidunt nihil autem." }), l("span", { children: "Officia pariatur qui, deleniti eum, et minus nisi aliquam nobis hic provident quisquam quidem voluptatem eveniet ducimus. Commodi ea dolorem, impedit eaque dolor, sint blanditiis magni accusantium natus reprehenderit minima?" }), l("span", { children: "Dicta reiciendis ut vitae laborum aut repellendus quasi beatae nulla sapiente et. Quod distinctio velit, modi ipsam exercitationem iste quia eaque blanditiis neque rerum optio, nulla tenetur pariatur ex officiis." }), l("span", { children: "Consectetur accusamus delectus sit voluptatem at esse! Aperiam unde maxime est nemo dicta minus autem esse nobis quibusdam iusto, reprehenderit harum, perferendis quae. Ipsum sit fugit similique recusandae quas inventore?" })] })] }), t === "tab-3" && h(D, { strong: !0, inset: !0, className: "space-y-4", children: [l("p", { children: l("b", { children: "Tab 3" }) }), h("p", { children: [l("span", { children: "Vero esse ab natus neque commodi aut quidem nobis. Unde, quam asperiores. A labore quod commodi autem explicabo distinctio saepe ex amet iste recusandae porro consectetur, sed dolorum sapiente voluptatibus?" }), l("span", { children: "Commodi ipsum, voluptatem obcaecati voluptatibus illum hic aliquam veritatis modi natus unde, assumenda expedita, esse eum fugit? Saepe aliquam ipsam illum nihil facilis, laborum quia, eius ea dolores molestias dicta." }), l("span", { children: "Consequatur quam laudantium, magnam facere ducimus tempora temporibus omnis cupiditate obcaecati tempore? Odit qui a, voluptas eveniet similique, doloribus eum dolorum ad, enim ea itaque voluptates porro minima. Omnis, magnam." }), l("span", { children: "Debitis, delectus! Eligendi excepturi rem veritatis, ad exercitationem tempore eveniet voluptates aut labore harum dolorem nemo repellendus accusantium quibusdam neque? Itaque iusto quisquam reprehenderit aperiam maiores dicta iure necessitatibus est." })] })] })] })
}
Rf.displayName = "TabbarPage";

function Ef() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1),
    [r, i] = m.useState(!1),
    [o, a] = m.useState(!1),
    s = u => { n(!1), i(!1), a(!1), u(!0) };
  return h(Z, { children: [l(K, { title: "Toast", left: !e && l(re, { onClick: () => history.back() }) }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [l(dl, { position: "left", opened: t, button: l(O, { rounded: !0, clear: !0, small: !0, inline: !0, onClick: () => n(!1), children: "Close" }), children: l("div", { className: "shrink", children: "Hello this is left toast!" }) }), l(dl, { position: "center", opened: r, button: l(O, { rounded: !0, clear: !0, small: !0, inline: !0, onClick: () => i(!1), children: "Close" }), children: l("div", { className: "shrink", children: "Hello this is center toast!" }) }), l(dl, { position: "right", opened: o, button: l(O, { rounded: !0, clear: !0, small: !0, inline: !0, onClick: () => a(!1), children: "Close" }), children: l("div", { className: "shrink", children: "Hello this is right toast!" }) }), l("p", { children: "Toasts provide brief feedback about an operation through a message on the screen." }), l("p", { children: l(O, { onClick: () => s(n), children: "Toast on Left" }) }), l("p", { children: l(O, { onClick: () => s(i), children: "Toast on Center" }) }), l("p", { children: l(O, { onClick: () => s(a), children: "Toast on Right" }) })] })] })
}
Ef.displayName = "ToastPage";

function Tf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!0),
    [r, i] = m.useState(!0),
    [o, a] = m.useState(!0),
    [s, u] = m.useState(!0);
  return h(Z, { children: [l(K, { title: "Toggle", left: !e && l(re, { onClick: () => history.back() }) }), h(U, { strong: !0, inset: !0, children: [l(P, { label: !0, title: "Item 1", after: l(tn, { component: "div", className: "-my-1", checked: t, onChange: () => n(!t) }) }), l(P, { label: !0, title: "Item 2", after: l(tn, { component: "div", className: "-my-1 k-color-brand-red", checked: r, onChange: () => i(!r) }) }), l(P, { label: !0, title: "Item 3", after: l(tn, { component: "div", className: "-my-1 k-color-brand-green", checked: o, onChange: () => a(!o) }) }), l(P, { label: !0, title: "Item 4", after: l(tn, { component: "div", className: "-my-1 k-color-brand-yellow", checked: s, onChange: () => u(!s) }) })] })] })
}
Tf.displayName = "TogglePage";

function zf() {
  const e = document.location.href.includes("examplePreview"),
    [t, n] = m.useState(!1);
  return h(Z, { children: [l(K, { title: "Toolbar", left: !e && l(re, { onClick: () => history.back() }) }), h(Ti, { top: t, className: `left-0 ${t?"ios:top-11-safe material:top-14-safe sticky":"bottom-0 fixed"} w-full`, children: [l(te, { toolbar: !0, children: "Link 1" }), l(te, { toolbar: !0, children: "Link 2" }), l(te, { toolbar: !0, children: "Link 3" })] }), h(D, { strongIos: !0, outlineIos: !0, className: "space-y-4", children: [l("p", { children: "Toolbar supports both top and bottom positions. Click the following button to change its position." }), l("p", { children: l(O, { onClick: () => { n(!t) }, children: "Toggle Toolbar Position" }) })] })] })
}
zf.displayName = "ToolbarPage";
const Ys = [Qm, nf, rf, lf, of, af, sf, uf, cf, df, mf, Vs, ff, pf, hf, gf, vf, yf, xf, Qs, kf, bf, Cf, wf, Nf, If, Sf, Pf, Mf, Lf, Bf, Rf, Ef, Tf, zf].map(e => {
  const t = e.displayName || e.name,
    n = `/${t.split("Page")[0].split("").map((i,o)=>i.match(/[A-Z]/)&&o!==0?`-${i}`:i).join("").toLowerCase()}`,
    r = e.title || t.split("Page")[0].split("").map((i, o) => i.match(/[A-Z]/) && o !== 0 ? ` ${i}` : i).join("");
  return { component: e, path: n, title: r }
});
Ys.sort((e, t) => e.title > t.title ? 1 : -1);

function Of({ theme: e, setTheme: t, setColorTheme: n }) { const [r, i] = m.useState(!1), [o, a] = m.useState(!1), s = () => { i(!r), document.documentElement.classList.toggle("dark") }; return m.useLayoutEffect(() => { i(document.documentElement.classList.contains("dark")) }), h(Z, { children: [l(K, { title: "SmoothX", large: !0, transparent: !0, centerTitle: !0 }), l(z, { children: "Theme" }), h(U, { strong: !0, inset: !0, children: [l(P, { label: !0, title: "iOS Theme", media: l(Ee, { onChange: () => t("ios"), component: "div", checked: e === "ios" }) }), l(P, { label: !0, title: "Material Theme", media: l(Ee, { onChange: () => t("material"), component: "div", checked: e === "material" }) })] }), h(U, { strong: !0, inset: !0, children: [l(P, { title: "Dark Mode", label: !0, after: l(tn, { component: "div", onChange: () => s(), checked: r }) }), l(P, { title: "Color Theme", link: !0, onClick: () => a(!0), after: l("div", { className: "w-6 h-6 rounded-full bg-primary home-color-picker" }) })] }), l(ro, { opened: o, onBackdropClick: () => a(!1), size: "w-36", target: ".home-color-picker", children: h("div", { className: "grid grid-cols-3 py-2", children: [l(te, { touchRipple: !0, className: "overflow-hidden h-12", onClick: () => n(""), children: l("span", { className: "bg-brand-primary w-6 h-6 rounded-full" }) }), l(te, { touchRipple: !0, className: "overflow-hidden h-12", onClick: () => n("k-color-brand-red"), children: l("span", { className: "bg-brand-red w-6 h-6 rounded-full" }) }), l(te, { touchRipple: !0, className: "overflow-hidden h-12", onClick: () => n("k-color-brand-green"), children: l("span", { className: "bg-brand-green w-6 h-6 rounded-full" }) }), l(te, { touchRipple: !0, className: "overflow-hidden h-12", onClick: () => n("k-color-brand-yellow"), children: l("span", { className: "bg-brand-yellow w-6 h-6 rounded-full" }) }), l(te, { touchRipple: !0, className: "overflow-hidden h-12", onClick: () => n("k-color-brand-purple"), children: l("span", { className: "bg-brand-purple w-6 h-6 rounded-full" }) })] }) }), l(z, { children: "Components" }), l(U, { strong: !0, inset: !0, children: Ys.map(u => l(P, { link: !0, title: u.title, linkComponent: b1, linkProps: { to: u.path }, media: l(A, {}) }, u.path)) })] }) } Of.displayName = "HomePage";

function Av() {
  const [e, t] = m.useState("ios"), [n, r] = m.useState(""), i = a => {
    const s = document.documentElement;
    s.classList.forEach(u => { u.includes("k-color") && s.classList.remove(u) }), a && s.classList.add(a), r(a)
  };
  m.useEffect(() => { window.setTheme = a => t(a), window.setMode = a => { a === "dark" ? document.documentElement.classList.add("dark") : document.documentElement.classList.remove("dark") } }, []);
  const o = window.parent !== window;
  return m.useLayoutEffect(() => {
    if (window.location.href.includes("safe-areas")) {
      const a = document.documentElement;
      a && (a.style.setProperty("--k-safe-area-top", e === "ios" ? "44px" : "24px"), a.style.setProperty("--k-safe-area-bottom", "34px"))
    }
  }, [e]), l(Em, { theme: e, safeAreas: !o, children: l(y1, { children: h(f1, { children: [Ys.map(a => l(za, { path: a.path, element: l(a.component, {}) }, a.path)), l(za, { path: "/", element: l(Of, { theme: e, setTheme: t, colorTheme: n, setColorTheme: i }) })] }) }) })
}
const Hv = bm(document.getElementById("app"));
Hv.render(ke.createElement(Av));